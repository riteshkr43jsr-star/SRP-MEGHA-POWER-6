import React, { useState } from 'react';
import { 
  Calculator, 
  Droplet, 
  Wind, 
  ArrowRight, 
  CheckCircle2, 
  FileText, 
  Sparkles, 
  X,
  Gauge,
  Info,
  Sliders
} from 'lucide-react';

interface CapacityCalculatorProps {
  onOpenQuoteWithDetails: (details: string) => void;
}

export const CapacityCalculator: React.FC<CapacityCalculatorProps> = ({ onOpenQuoteWithDetails }) => {
  const [calcType, setCalcType] = useState<'transformer' | 'blower'>('transformer');

  // Step 1 — Transformer Oil Quantity
  const [oilVolume, setOilVolume] = useState<number>(10000);
  const [isCustomVolume, setIsCustomVolume] = useState<boolean>(false);

  // Step 2 — Transformer Type
  const [transformerType, setTransformerType] = useState<string>('Power Transformer');

  // Step 3 — Oil Condition
  const [oilCondition, setOilCondition] = useState<string>('High Moisture + Low BDV');

  // Step 4 — Required Treatment
  const [requiredTreatment, setRequiredTreatment] = useState<string>('Complete High Vacuum Purification');

  // Modal State for Transformer Technical Recommendation
  const [showTechRecModal, setShowTechRecModal] = useState<boolean>(false);

  // ==========================================
  // BLOWER SELECTION TOOL STATE
  // ==========================================
  const [blowerAirflow, setBlowerAirflow] = useState<number>(5000);
  const [isCustomBlowerAirflow, setIsCustomBlowerAirflow] = useState<boolean>(false);

  const [blowerPressure, setBlowerPressure] = useState<number | 'dont_know'>(150);

  const [blowerApplication, setBlowerApplication] = useState<string>('Industrial Ventilation');
  const [blowerEnvironment, setBlowerEnvironment] = useState<string>('Normal Industrial Air');
  const [blowerMaterial, setBlowerMaterial] = useState<string>('Application Based Recommendation');
  const [blowerDrive, setBlowerDrive] = useState<string>('Technical Team Recommendation');

  const [showBlowerTechRecModal, setShowBlowerTechRecModal] = useState<boolean>(false);

  // Presets for Transformer Step 1 (Max 10,000 L / 10,000 LPH)
  const presetQuantities = [
    { label: '500 L', value: 500 },
    { label: '1,000 L', value: 1000 },
    { label: '2,000 L', value: 2000 },
    { label: '3,000 L', value: 3000 },
    { label: '5,000 L', value: 5000 },
    { label: '6,000 L', value: 6000 },
    { label: '10,000 L (Max)', value: 10000 },
  ];

  // Options for Transformer Step 2
  const transformerTypeOptions = [
    'Distribution Transformer',
    'Power Transformer',
    'Furnace Transformer',
    'EHV Transformer',
    'OLTC / Transformer Oil',
    'Other'
  ];

  // Options for Transformer Step 3
  const oilConditionOptions = [
    'Moisture Problem',
    'Low BDV',
    'High Moisture + Low BDV',
    'Degassing Required',
    'General Filtration',
    'Complete Oil Purification'
  ];

  // Options for Transformer Step 4
  const requiredTreatmentOptions = [
    'Filtration Only',
    'Filtration + Dehydration',
    'Dehydration + Degassing',
    'Complete High Vacuum Purification'
  ];

  // Blower Airflow Quick-Selection Values (1,000 - 25,000 CMH)
  const blowerAirflowPresets = [
    { label: '1,000 CMH', value: 1000 },
    { label: '2,500 CMH', value: 2500 },
    { label: '5,000 CMH', value: 5000 },
    { label: '7,500 CMH', value: 7500 },
    { label: '10,000 CMH', value: 10000 },
    { label: '15,000 CMH', value: 15000 },
    { label: '20,000 CMH', value: 20000 },
    { label: '25,000 CMH', value: 25000 },
  ];

  // Blower Static Pressure Quick-Selection Values (50 - 500 mmWG)
  const blowerPressurePresets = [
    { label: '50 mmWG', value: 50 },
    { label: '100 mmWG', value: 100 },
    { label: '150 mmWG', value: 150 },
    { label: '200 mmWG', value: 200 },
    { label: '300 mmWG', value: 300 },
    { label: '400 mmWG', value: 400 },
    { label: '500 mmWG', value: 500 },
    { label: "I Don't Know", value: 'dont_know' as const },
  ];

  // Blower Application Options
  const blowerApplicationOptions = [
    'Industrial Ventilation',
    'Heat Exchanger Cooling',
    'Fume Extraction',
    'Dust Collection',
    'Scrubber System',
    'Process Air',
    'Boiler / Furnace Air',
    'General Industrial Air',
    'Other'
  ];

  // Blower Operating Environment Options
  const blowerEnvironmentOptions = [
    'Normal Industrial Air',
    'Hot Air',
    'Dusty Environment',
    'Corrosive Environment',
    'Chemical Fumes',
    'Outdoor Installation'
  ];

  // Blower Preferred Material Options
  const blowerMaterialOptions = [
    'MS',
    'SS304',
    'SS316',
    'FRP',
    'Application Based Recommendation'
  ];

  // Blower Drive Arrangement Options
  const blowerDriveOptions = [
    'Direct Drive',
    'Belt Drive',
    'Coupling Drive',
    'Technical Team Recommendation'
  ];

  // Recommendation Engine Calculation for Transformer Oil Filtration
  const getFiltrationRecommendation = () => {
    let nominalLph = 10000;
    
    if (oilVolume <= 1000) {
      nominalLph = 1000;
    } else if (oilVolume <= 3000) {
      nominalLph = 3000;
    } else if (oilVolume <= 5000) {
      nominalLph = 5000;
    } else if (oilVolume <= 6000) {
      nominalLph = 6000;
    } else {
      nominalLph = 10000; // Max Filtration Capacity: 10,000 LPH
    }

    const isDoubleStage = 
      requiredTreatment === 'Complete High Vacuum Purification' ||
      requiredTreatment === 'Dehydration + Degassing' ||
      transformerType === 'EHV Transformer' ||
      transformerType === 'Power Transformer' ||
      oilCondition === 'Degassing Required' ||
      oilCondition === 'High Moisture + Low BDV';

    const stageName = isDoubleStage ? 'Double-Stage High Vacuum' : 'Single-Stage High Vacuum';
    
    let machineTitle = `${nominalLph.toLocaleString()} LPH ${stageName} Oil Purification Machine`;
    if (requiredTreatment === 'Filtration Only') {
      machineTitle = `${nominalLph.toLocaleString()} LPH Precision Transformer Oil Filtration Unit`;
    }

    const passHours = (oilVolume / nominalLph).toFixed(1);

    let recFor = 'Power & EHV Transformers';
    if (transformerType === 'Distribution Transformer') {
      recFor = 'Distribution & Medium Industrial Transformers';
    } else if (transformerType === 'Furnace Transformer') {
      recFor = 'Heavy Industrial & Furnace Transformers';
    } else if (transformerType === 'OLTC / Transformer Oil') {
      recFor = 'OLTC & On-Load Tap Changer Compartments';
    } else if (transformerType === 'EHV Transformer') {
      recFor = 'EHV & Substation Power Transformers up to 400kV';
    }

    return {
      machineTitle,
      nominalCapacity: `${nominalLph.toLocaleString()} LPH`,
      application: 'Transformer Oil Purification',
      recommendedFor: recFor,
      estimatedProcessing: `~${passHours} Hours per pass (Total Volume: ${oilVolume.toLocaleString()} Litres) — Based on entered oil volume and operating conditions.`,
      passHours,
      nominalLph,
      isDoubleStage
    };
  };

  // Derive Blower Material Recommendation
  const getDerivedBlowerMaterial = () => {
    if (blowerMaterial !== 'Application Based Recommendation') {
      return blowerMaterial;
    }
    if (
      blowerEnvironment === 'Corrosive Environment' || 
      blowerEnvironment === 'Chemical Fumes' || 
      blowerApplication === 'Scrubber System' || 
      blowerApplication === 'Fume Extraction'
    ) {
      return 'FRP / SS316 (Corrosion Resistant)';
    }
    if (
      blowerEnvironment === 'Hot Air' || 
      blowerApplication === 'Boiler / Furnace Air'
    ) {
      return 'SS304 / Heavy Duty MS (Thermal Resistant)';
    }
    if (
      blowerEnvironment === 'Dusty Environment' || 
      blowerApplication === 'Dust Collection'
    ) {
      return 'Heavy Duty MS with Wear-Resistant Liners';
    }
    return 'MS / SS / FRP – Application Dependent';
  };

  const recResult = getFiltrationRecommendation();

  // Trigger Quote for Transformer
  const handleGetQuote = () => {
    const detailString = `Quote for ${recResult.machineTitle} | Volume: ${oilVolume.toLocaleString()} L | Transformer: ${transformerType} | Condition: ${oilCondition} | Treatment: ${requiredTreatment}`;
    onOpenQuoteWithDetails(detailString);
  };

  const handleGetTechRecommendation = () => {
    setShowTechRecModal(true);
  };

  // Trigger Quote for Blower
  const handleBlowerQuote = () => {
    const pressureStr = blowerPressure === 'dont_know' ? 'To be finalized' : `${blowerPressure} mmWG`;
    const detailString = `Quote for Centrifugal Blower – Airflow: ${blowerAirflow.toLocaleString()} CMH | Pressure: ${pressureStr} | Application: ${blowerApplication} | Environment: ${blowerEnvironment} | Material: ${getDerivedBlowerMaterial()} | Drive: ${blowerDrive}`;
    onOpenQuoteWithDetails(detailString);
  };

  // Trigger Technical Recommendation for Blower
  const handleBlowerTechRec = () => {
    setShowBlowerTechRecModal(true);
  };

  return (
    <section id="capacity-selector" className="py-16 bg-gradient-to-b from-[#F5F2FC] via-[#FAF8F5] to-[#F2F7FA] border-b border-purple-100/80 relative overflow-hidden">
      {/* Soft multi-color ambient glow blobs */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-purple-300/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-orange-300/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-rose-200/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Selector Card Container */}
        <div className="bg-white/95 backdrop-blur-xs rounded-3xl border border-purple-200/60 p-6 sm:p-10 shadow-2xl">
          
          {/* Header & Mode Switch */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-10 pb-6 border-b border-purple-100">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-600 via-purple-600 to-orange-500 text-white flex items-center justify-center shadow-lg shrink-0">
                <Calculator className="w-6 h-6 text-amber-300" />
              </div>
              <div>
                <h3 className="text-xl sm:text-2xl font-black tracking-tight uppercase text-transparent bg-clip-text bg-gradient-to-r from-violet-950 via-purple-900 to-amber-900">
                  {calcType === 'transformer' ? 'EQUIPMENT & CAPACITY SELECTOR TOOL' : 'CENTRIFUGAL BLOWER SELECTION TOOL'}
                </h3>
                <p className="text-xs sm:text-sm text-gray-600 font-medium mt-0.5">
                  {calcType === 'transformer' 
                    ? 'Select your transformer or oil parameters to generate instant technical equipment recommendations.'
                    : 'Select your airflow, pressure and application requirements to get a preliminary blower recommendation.'}
                </p>
              </div>
            </div>

            {/* Selector Mode Toggle */}
            <div className="flex rounded-2xl bg-purple-50/80 p-1.5 border border-purple-200/80 shrink-0 w-full md:w-auto gap-1">
              <button 
                onClick={() => setCalcType('transformer')}
                className={`flex-1 md:flex-none px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${
                  calcType === 'transformer' 
                    ? 'bg-gradient-to-r from-violet-700 via-purple-700 to-indigo-700 text-white shadow-lg ring-2 ring-violet-400/40 scale-102' 
                    : 'text-gray-700 hover:text-purple-700 hover:bg-purple-100/50'
                }`}
              >
                <Droplet className={`w-4 h-4 ${calcType === 'transformer' ? 'text-amber-300' : 'text-purple-600'}`} />
                <span>TRANSFORMER OIL FILTRATION CAPACITY</span>
              </button>
              <button 
                onClick={() => setCalcType('blower')}
                className={`flex-1 md:flex-none px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${
                  calcType === 'blower' 
                    ? 'bg-gradient-to-r from-orange-600 via-amber-600 to-rose-600 text-white shadow-lg ring-2 ring-orange-400/40 scale-102' 
                    : 'text-gray-700 hover:text-orange-700 hover:bg-orange-100/50'
                }`}
              >
                <Wind className={`w-4 h-4 ${calcType === 'blower' ? 'text-amber-200' : 'text-orange-600'}`} />
                <span>CENTRIFUGAL BLOWER SELECTION TOOL</span>
              </button>
            </div>
          </div>

          {calcType === 'transformer' ? (
            /* TRANSFORMER OCF TOOL MODE */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
              
              {/* Left Column: 4-Step Input Form */}
              <div className="lg:col-span-7 space-y-8">
                
                {/* STEP 1: Transformer Oil Quantity */}
                <div className="bg-gradient-to-br from-violet-50/90 via-white to-purple-50/60 rounded-2xl p-5 border border-violet-200 border-l-4 border-l-violet-600 space-y-3 shadow-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-gradient-to-r from-violet-600 to-purple-600 text-white text-xs font-black flex items-center justify-center shadow-xs">
                        1
                      </span>
                      <h4 className="text-sm font-black text-violet-950 uppercase tracking-wide">
                        Step 1 — Transformer Oil Quantity
                      </h4>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="hidden sm:inline-flex text-[10px] font-black text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        Max Capacity: 10,000 LPH
                      </span>
                      <span className="text-xs font-black text-violet-900 bg-violet-100/90 border border-violet-300 px-3 py-1 rounded-full shadow-2xs">
                        Selected: {oilVolume.toLocaleString()} Litres
                      </span>
                    </div>
                  </div>

                  {/* Preset Volume Buttons */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                    {presetQuantities.map((preset, pIdx) => {
                      const isSelected = !isCustomVolume && oilVolume === preset.value;
                      return (
                        <button
                          key={pIdx}
                          onClick={() => {
                            setOilVolume(preset.value);
                            setIsCustomVolume(false);
                          }}
                          className={`py-2.5 px-3 rounded-xl text-xs transition-all duration-200 border text-center flex items-center justify-center gap-1.5 ${
                            isSelected
                              ? 'bg-gradient-to-r from-violet-600 to-purple-600 text-white font-black border-violet-600 shadow-md ring-2 ring-violet-500/30 scale-102'
                              : 'bg-white text-gray-700 font-bold border-gray-300 hover:border-violet-600 hover:bg-violet-50/50'
                          }`}
                        >
                          {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-amber-300 shrink-0" />}
                          <span>{preset.label}</span>
                        </button>
                      );
                    })}

                    {/* Custom / Slider Toggle */}
                    <button
                      onClick={() => setIsCustomVolume(true)}
                      className={`py-2.5 px-3 rounded-xl text-xs transition-all duration-200 border text-center flex items-center justify-center gap-1.5 ${
                        isCustomVolume
                          ? 'bg-gradient-to-r from-orange-500 to-amber-600 text-white font-black border-orange-500 shadow-md ring-2 ring-orange-400/30 scale-102'
                          : 'bg-white text-gray-700 font-bold border-gray-300 hover:border-orange-500 hover:bg-orange-50/50'
                      }`}
                    >
                      {isCustomVolume && <CheckCircle2 className="w-3.5 h-3.5 text-yellow-300 shrink-0" />}
                      <span>Slider / Custom</span>
                    </button>
                  </div>

                  {/* Range Slider & Custom Input (Max 10,000) */}
                  <div className="pt-2 space-y-2">
                    <div className="flex items-center gap-3">
                      <input 
                        type="range" 
                        min="500" 
                        max="10000" 
                        step="500"
                        value={oilVolume} 
                        onChange={(e) => {
                          setOilVolume(Math.min(10000, Number(e.target.value)));
                          setIsCustomVolume(true);
                        }}
                        className="w-full accent-violet-600 h-2 bg-gray-200 rounded-lg cursor-pointer"
                      />
                      <div className="shrink-0 w-28">
                        <input
                          type="number"
                          min="500"
                          max="10000"
                          value={oilVolume}
                          onChange={(e) => {
                            const val = Math.min(10000, Number(e.target.value) || 0);
                            setOilVolume(val);
                            setIsCustomVolume(true);
                          }}
                          className="w-full bg-white border border-violet-300 rounded-lg px-2.5 py-1 text-xs font-bold text-violet-950 text-right focus:outline-none focus:border-violet-600"
                          placeholder="Max 10000"
                        />
                      </div>
                    </div>
                    <div className="flex justify-between text-[10px] text-gray-500 font-semibold px-1">
                      <span>500 L</span>
                      <span>3,000 L</span>
                      <span>5,000 L</span>
                      <span>10,000 L (Max)</span>
                    </div>
                  </div>
                </div>

                {/* STEP 2: Transformer Type */}
                <div className="bg-gradient-to-br from-amber-50/90 via-white to-orange-50/60 rounded-2xl p-5 border border-amber-200 border-l-4 border-l-amber-500 space-y-3 shadow-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-gradient-to-r from-amber-500 to-orange-600 text-white text-xs font-black flex items-center justify-center shadow-xs">
                      2
                    </span>
                    <h4 className="text-sm font-black text-amber-950 uppercase tracking-wide">
                      Step 2 — Transformer Type
                    </h4>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
                    {transformerTypeOptions.map((typeOpt, tIdx) => {
                      const isSelected = transformerType === typeOpt;

                      let activeGradient = 'bg-gradient-to-r from-violet-600 to-purple-600 text-white border-violet-600 ring-2 ring-violet-400/40';
                      if (typeOpt === 'Distribution Transformer') {
                        activeGradient = 'bg-gradient-to-r from-amber-500 to-orange-600 text-white border-amber-500 ring-2 ring-amber-400/40';
                      } else if (typeOpt === 'Furnace Transformer') {
                        activeGradient = 'bg-gradient-to-r from-rose-600 to-red-600 text-white border-rose-600 ring-2 ring-rose-400/40';
                      } else if (typeOpt === 'EHV Transformer') {
                        activeGradient = 'bg-gradient-to-r from-indigo-600 to-purple-700 text-white border-indigo-600 ring-2 ring-indigo-400/40';
                      } else if (typeOpt === 'OLTC / Transformer Oil') {
                        activeGradient = 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white border-cyan-600 ring-2 ring-cyan-400/40';
                      }

                      return (
                        <button
                          key={tIdx}
                          onClick={() => setTransformerType(typeOpt)}
                          className={`p-3 rounded-xl text-xs font-extrabold transition-all duration-200 border text-left leading-snug flex flex-col justify-between ${
                            isSelected
                              ? `${activeGradient} shadow-md scale-102`
                              : 'bg-white text-gray-700 border-gray-300 hover:border-amber-500 hover:bg-amber-50/50'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full mb-1">
                            <span className="text-[10px] uppercase font-black opacity-80">
                              {isSelected ? 'ACTIVE MATCH' : `Type 0${tIdx+1}`}
                            </span>
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-amber-300 shrink-0" />}
                          </div>
                          <span>{typeOpt}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* STEP 3: Oil Condition */}
                <div className="bg-gradient-to-br from-rose-50/90 via-white to-red-50/60 rounded-2xl p-5 border border-rose-200 border-l-4 border-l-rose-600 space-y-3 shadow-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-gradient-to-r from-rose-600 to-red-600 text-white text-xs font-black flex items-center justify-center shadow-xs">
                      3
                    </span>
                    <h4 className="text-sm font-black text-rose-950 uppercase tracking-wide">
                      Step 3 — Oil Condition
                    </h4>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
                    {oilConditionOptions.map((condOpt, cIdx) => {
                      const isSelected = oilCondition === condOpt;

                      let activeGradient = 'bg-gradient-to-r from-rose-600 to-red-700 text-white border-rose-600 ring-2 ring-rose-500/40';
                      if (condOpt === 'High Moisture + Low BDV') {
                        activeGradient = 'bg-gradient-to-r from-rose-600 to-red-700 text-white border-rose-600 ring-2 ring-rose-500/40';
                      } else if (condOpt === 'Degassing Required') {
                        activeGradient = 'bg-gradient-to-r from-amber-500 to-orange-600 text-white border-amber-500 ring-2 ring-amber-400/40';
                      } else if (condOpt === 'High Sludge & Acidity') {
                        activeGradient = 'bg-gradient-to-r from-purple-600 to-indigo-700 text-white border-purple-600 ring-2 ring-purple-400/40';
                      } else if (condOpt === 'New Transformer Oil Filling') {
                        activeGradient = 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white border-blue-600 ring-2 ring-blue-400/40';
                      }

                      return (
                        <button
                          key={cIdx}
                          onClick={() => setOilCondition(condOpt)}
                          className={`p-3 rounded-xl text-xs font-extrabold transition-all duration-200 border text-left leading-snug flex flex-col justify-between ${
                            isSelected
                              ? `${activeGradient} shadow-md scale-102`
                              : 'bg-white text-gray-700 border-gray-300 hover:border-rose-500 hover:bg-rose-50/50'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full mb-1">
                            <span className="text-[10px] uppercase font-black opacity-80">
                              {isSelected ? 'SELECTED' : `State 0${cIdx+1}`}
                            </span>
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-amber-300 shrink-0" />}
                          </div>
                          <span>{condOpt}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* STEP 4: Required Treatment */}
                <div className="bg-gradient-to-br from-blue-50/90 via-white to-indigo-50/60 rounded-2xl p-5 border border-blue-200 border-l-4 border-l-indigo-600 space-y-3 shadow-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-gradient-to-r from-indigo-600 to-cyan-600 text-white text-xs font-black flex items-center justify-center shadow-xs">
                      4
                    </span>
                    <h4 className="text-sm font-black text-indigo-950 uppercase tracking-wide">
                      Step 4 — Required Treatment
                    </h4>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                    {requiredTreatmentOptions.map((treatOpt, trIdx) => {
                      const isSelected = requiredTreatment === treatOpt;
                      return (
                        <button
                          key={trIdx}
                          onClick={() => setRequiredTreatment(treatOpt)}
                          className={`p-3.5 rounded-xl text-xs font-extrabold transition-all duration-200 border text-left leading-snug flex items-center gap-2.5 ${
                            isSelected
                              ? 'bg-gradient-to-r from-indigo-600 to-purple-700 text-white border-indigo-600 shadow-md ring-2 ring-indigo-500/30 scale-102'
                              : 'bg-white text-gray-700 border-gray-300 hover:border-indigo-600 hover:bg-indigo-50/50'
                          }`}
                        >
                          <CheckCircle2 className={`w-4 h-4 shrink-0 ${isSelected ? 'text-amber-300' : 'text-gray-400'}`} />
                          <span>{treatOpt}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

              </div>

              {/* Right Column: Transformer Result Output Box */}
              <div className="lg:col-span-5 bg-gradient-to-b from-slate-950 via-violet-950 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-violet-500/40 space-y-6 sticky top-24">
                
                {/* Result Title Header */}
                <div className="flex items-center justify-between border-b border-violet-500/30 pb-4">
                  <div className="flex items-center gap-2 text-amber-300 text-xs font-black uppercase tracking-widest">
                    <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                    <span>RECOMMENDED EQUIPMENT</span>
                  </div>
                  <span className="text-[10px] font-black uppercase px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40">
                    Calculated Result
                  </span>
                </div>

                {/* Primary Machine Title */}
                <div>
                  <h4 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-amber-200 to-orange-300 leading-snug tracking-tight mb-2">
                    {recResult.machineTitle}
                  </h4>
                  <p className="text-xs text-purple-200/90 leading-relaxed font-medium">
                    Precision high-vacuum oil dehydration, degasification, and particulate filtration machine optimized for plant parameters.
                  </p>
                </div>

                {/* Specs List */}
                <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-4 border border-white/15 space-y-3 text-xs">
                  <div className="flex justify-between items-center border-b border-white/10 pb-2">
                    <span className="text-purple-200 font-medium">Nominal Capacity:</span>
                    <span className="font-black text-amber-300 text-sm">{recResult.nominalCapacity}</span>
                  </div>

                  <div className="flex justify-between items-center border-b border-white/10 pb-2">
                    <span className="text-purple-200 font-medium">Application:</span>
                    <span className="font-bold text-white">{recResult.application}</span>
                  </div>

                  <div className="flex justify-between items-center border-b border-white/10 pb-2">
                    <span className="text-purple-200 font-medium">Recommended For:</span>
                    <span className="font-bold text-emerald-300 text-right">{recResult.recommendedFor}</span>
                  </div>

                  <div className="pt-1">
                    <span className="text-purple-200 font-medium block mb-1">Estimated Processing:</span>
                    <p className="text-[11px] text-amber-100 leading-relaxed bg-black/40 p-2.5 rounded-xl border border-amber-400/30 font-mono">
                      {recResult.estimatedProcessing}
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-3 pt-2">
                  <button
                    onClick={handleGetTechRecommendation}
                    className="w-full bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 hover:from-amber-500 hover:to-rose-600 text-black py-3.5 px-4 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl transition-all hover:scale-102"
                  >
                    <FileText className="w-4 h-4 text-black shrink-0" />
                    <span>GET TECHNICAL RECOMMENDATION</span>
                  </button>

                  <button
                    onClick={handleGetQuote}
                    className="w-full bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white py-3.5 px-4 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all hover:scale-102"
                  >
                    <span>GET A QUOTE</span>
                    <ArrowRight className="w-4 h-4 text-amber-300" />
                  </button>
                </div>

              </div>

            </div>
          ) : (
            /* REDESIGNED CENTRIFUGAL BLOWER SELECTION TOOL */
            <div className="space-y-8">
              
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                
                {/* Left Column: Blower Selection Form Controls */}
                <div className="lg:col-span-7 space-y-6">
                  
                  {/* 1. REQUIRED AIRFLOW */}
                  <div className="bg-gradient-to-br from-indigo-50/90 via-white to-purple-50/60 rounded-2xl p-5 border border-indigo-200 border-l-4 border-l-indigo-600 space-y-4 shadow-xs">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-black text-indigo-950 uppercase tracking-wide flex items-center gap-2">
                        <Wind className="w-4 h-4 text-indigo-600" />
                        <span>Required Airflow</span>
                      </label>
                      <span className="text-xs font-black text-indigo-900 bg-indigo-100/90 px-3 py-1 rounded-full border border-indigo-300 shadow-2xs">
                        Required Airflow: {blowerAirflow.toLocaleString()} CMH
                      </span>
                    </div>

                    {/* Quick Selection Values */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {blowerAirflowPresets.map((preset, idx) => {
                        const isSelected = !isCustomBlowerAirflow && blowerAirflow === preset.value;
                        return (
                          <button
                            key={idx}
                            onClick={() => {
                              setBlowerAirflow(preset.value);
                              setIsCustomBlowerAirflow(false);
                            }}
                            className={`py-2.5 px-3 rounded-xl text-xs transition-all duration-200 border text-center flex items-center justify-center gap-1.5 ${
                              isSelected
                                ? 'bg-gradient-to-r from-indigo-600 to-purple-700 text-white font-black border-indigo-600 shadow-md ring-2 ring-indigo-500/30 scale-102'
                                : 'bg-white text-gray-700 font-bold border-gray-300 hover:border-indigo-600 hover:bg-indigo-50/50'
                            }`}
                          >
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-amber-300 shrink-0" />}
                            <span>{preset.label}</span>
                          </button>
                        );
                      })}

                      {/* Custom Requirement Toggle */}
                      <button
                        onClick={() => setIsCustomBlowerAirflow(true)}
                        className={`py-2.5 px-3 rounded-xl text-xs transition-all duration-200 border text-center flex items-center justify-center gap-1.5 ${
                          isCustomBlowerAirflow
                            ? 'bg-gradient-to-r from-violet-600 to-indigo-700 text-white font-black border-violet-600 shadow-md ring-2 ring-violet-500/30 scale-102'
                            : 'bg-white text-gray-700 font-bold border-gray-300 hover:border-violet-600 hover:bg-violet-50/50'
                        }`}
                      >
                        {isCustomBlowerAirflow && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-300 shrink-0" />}
                        <span>Custom Requirement</span>
                      </button>
                    </div>

                    {/* Range Slider & Numeric Input (Range: 1,000 – 25,000 CMH) */}
                    <div className="pt-2 space-y-2">
                      <div className="flex items-center gap-3">
                        <input 
                          type="range" 
                          min="1000" 
                          max="25000" 
                          step="500"
                          value={blowerAirflow} 
                          onChange={(e) => {
                            setBlowerAirflow(Number(e.target.value));
                            setIsCustomBlowerAirflow(true);
                          }}
                          className="w-full accent-indigo-600 h-2 bg-gray-200 rounded-lg cursor-pointer"
                        />
                        <div className="shrink-0 w-32">
                          <input
                            type="number"
                            min="1000"
                            max="25000"
                            value={blowerAirflow}
                            onChange={(e) => {
                              setBlowerAirflow(Number(e.target.value) || 1000);
                              setIsCustomBlowerAirflow(true);
                            }}
                            className="w-full bg-white border border-indigo-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-indigo-950 text-right focus:outline-none focus:border-indigo-600"
                            placeholder="CMH"
                          />
                        </div>
                      </div>
                      <div className="flex justify-between text-[10px] text-gray-500 font-bold px-1">
                        <span>1,000 CMH</span>
                        <span>5,000 CMH</span>
                        <span>15,000 CMH</span>
                        <span>25,000 CMH</span>
                      </div>
                    </div>
                  </div>

                  {/* 2. REQUIRED STATIC PRESSURE */}
                  <div className="bg-gradient-to-br from-amber-50/90 via-white to-orange-50/60 rounded-2xl p-5 border border-amber-200 border-l-4 border-l-amber-500 space-y-4 shadow-xs">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-black text-amber-950 uppercase tracking-wide flex items-center gap-2">
                        <Gauge className="w-4 h-4 text-amber-600" />
                        <span>Required Static Pressure</span>
                      </label>
                      <span className="text-xs font-black text-amber-900 bg-amber-100/90 px-3 py-1 rounded-full border border-amber-300 shadow-2xs">
                        {blowerPressure === 'dont_know' ? 'To be finalized' : `${blowerPressure} mmWG`}
                      </span>
                    </div>

                    {/* Quick Selection Values */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {blowerPressurePresets.map((preset, idx) => {
                        const isSelected = blowerPressure === preset.value;
                        return (
                          <button
                            key={idx}
                            onClick={() => setBlowerPressure(preset.value)}
                            className={`py-2.5 px-3 rounded-xl text-xs transition-all duration-200 border text-center flex items-center justify-center gap-1.5 ${
                              isSelected
                                ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white font-black border-amber-500 shadow-md ring-2 ring-amber-400/40 scale-102'
                                : 'bg-white text-gray-700 font-bold border-gray-300 hover:border-amber-500 hover:bg-amber-50/50'
                            }`}
                          >
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-black shrink-0" />}
                            <span>{preset.label}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Slider when numeric value selected or info when "I Don't Know" */}
                    {blowerPressure === 'dont_know' ? (
                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs font-bold text-amber-900 flex items-center gap-2">
                        <Info className="w-4 h-4 shrink-0 text-amber-600" />
                        <span>Pressure requirement can be finalized by our technical team.</span>
                      </div>
                    ) : (
                      <div className="pt-2 space-y-2">
                        <div className="flex items-center gap-3">
                          <input 
                            type="range" 
                            min="50" 
                            max="500" 
                            step="25"
                            value={blowerPressure} 
                            onChange={(e) => setBlowerPressure(Number(e.target.value))}
                            className="w-full accent-amber-600 h-2 bg-gray-200 rounded-lg cursor-pointer"
                          />
                          <div className="shrink-0 w-28 text-right font-black text-xs text-amber-900 bg-white border border-amber-300 rounded-lg px-2.5 py-1.5">
                            {blowerPressure} mmWG
                          </div>
                        </div>
                        <div className="flex justify-between text-[10px] text-gray-500 font-bold px-1">
                          <span>50 mmWG</span>
                          <span>200 mmWG</span>
                          <span>350 mmWG</span>
                          <span>500 mmWG</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* 3. APPLICATION & OPERATING ENVIRONMENT */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Application Dropdown */}
                    <div className="bg-gradient-to-br from-rose-50/90 via-white to-pink-50/60 rounded-2xl p-4 border border-rose-200 border-l-4 border-l-rose-500 space-y-2">
                      <label className="block text-xs font-black text-rose-950 uppercase tracking-wide">
                        Select Application
                      </label>
                      <select 
                        value={blowerApplication}
                        onChange={(e) => setBlowerApplication(e.target.value)}
                        className="w-full bg-white border border-rose-200 rounded-xl p-3 text-xs font-bold text-rose-950 focus:outline-none focus:border-rose-500"
                      >
                        {blowerApplicationOptions.map((appOpt, aIdx) => (
                          <option key={aIdx} value={appOpt}>{appOpt}</option>
                        ))}
                      </select>
                    </div>

                    {/* Operating Environment Dropdown */}
                    <div className="bg-gradient-to-br from-rose-50/90 via-white to-pink-50/60 rounded-2xl p-4 border border-rose-200 border-l-4 border-l-rose-500 space-y-2">
                      <label className="block text-xs font-black text-rose-950 uppercase tracking-wide">
                        Operating Environment
                      </label>
                      <select 
                        value={blowerEnvironment}
                        onChange={(e) => setBlowerEnvironment(e.target.value)}
                        className="w-full bg-white border border-rose-200 rounded-xl p-3 text-xs font-bold text-rose-950 focus:outline-none focus:border-rose-500"
                      >
                        {blowerEnvironmentOptions.map((envOpt, eIdx) => (
                          <option key={eIdx} value={envOpt}>{envOpt}</option>
                        ))}
                      </select>
                    </div>

                  </div>

                  {/* 4. MATERIAL & DRIVE ARRANGEMENT */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Preferred Material Dropdown */}
                    <div className="bg-gradient-to-br from-teal-50/90 via-white to-cyan-50/60 rounded-2xl p-4 border border-teal-200 border-l-4 border-l-teal-600 space-y-2">
                      <label className="block text-xs font-black text-teal-950 uppercase tracking-wide">
                        Preferred Material
                      </label>
                      <select 
                        value={blowerMaterial}
                        onChange={(e) => setBlowerMaterial(e.target.value)}
                        className="w-full bg-white border border-teal-200 rounded-xl p-3 text-xs font-bold text-teal-950 focus:outline-none focus:border-teal-600"
                      >
                        {blowerMaterialOptions.map((matOpt, mIdx) => (
                          <option key={mIdx} value={matOpt}>{matOpt}</option>
                        ))}
                      </select>
                    </div>

                    {/* Drive Arrangement Dropdown */}
                    <div className="bg-gradient-to-br from-teal-50/90 via-white to-cyan-50/60 rounded-2xl p-4 border border-teal-200 border-l-4 border-l-teal-600 space-y-2">
                      <label className="block text-xs font-black text-teal-950 uppercase tracking-wide">
                        Drive Arrangement
                      </label>
                      <select 
                        value={blowerDrive}
                        onChange={(e) => setBlowerDrive(e.target.value)}
                        className="w-full bg-white border border-teal-200 rounded-xl p-3 text-xs font-bold text-teal-950 focus:outline-none focus:border-teal-600"
                      >
                        {blowerDriveOptions.map((driveOpt, dIdx) => (
                          <option key={dIdx} value={driveOpt}>{driveOpt}</option>
                        ))}
                      </select>
                    </div>

                  </div>

                  {/* RPM Note Indicator */}
                  <div className="bg-gradient-to-r from-violet-100 via-purple-100 to-indigo-100 p-3.5 rounded-2xl border border-purple-200 flex items-center justify-between text-xs">
                    <span className="font-extrabold text-purple-950">Fan Shaft Speed (RPM):</span>
                    <span className="font-black text-purple-900 bg-white px-3 py-1 rounded-lg border border-purple-300 shadow-2xs">
                      RPM: As per blower design
                    </span>
                  </div>

                </div>

                {/* Right Column: Smart Recommendation Result Card */}
                <div className="lg:col-span-5 bg-gradient-to-br from-amber-50/95 via-orange-50/70 to-emerald-50/80 text-gray-900 rounded-3xl p-6 sm:p-8 shadow-xl border-2 border-orange-400/80 space-y-6 sticky top-24">
                  
                  {/* Header */}
                  <div className="flex items-center justify-between border-b border-orange-300 pb-4">
                    <div className="flex items-center gap-2 text-orange-900 text-xs font-black uppercase tracking-widest">
                      <Sparkles className="w-4 h-4 text-orange-600 animate-pulse" />
                      <span>RECOMMENDED BLOWER CONFIGURATION</span>
                    </div>
                    <span className="text-[10px] font-black uppercase px-3 py-1 rounded-full bg-orange-100 text-orange-900 border border-orange-300 shadow-2xs">
                      Preliminary Match
                    </span>
                  </div>

                  {/* Blower Title */}
                  <div>
                    <h4 className="text-xl sm:text-2xl font-black text-[#101820] leading-snug tracking-tight mb-2">
                      Centrifugal Blower – {blowerAirflow.toLocaleString()} CMH
                    </h4>
                    <p className="text-xs text-gray-700 leading-relaxed font-medium">
                      Heavy-duty industrial centrifugal air fan configured for continuous plant operating duty.
                    </p>
                  </div>

                  {/* Specification Breakdown */}
                  <div className="bg-white/90 backdrop-blur-xs rounded-2xl p-4 border border-orange-200/80 space-y-2.5 text-xs shadow-xs">
                    <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                      <span className="text-gray-600 font-semibold">Airflow:</span>
                      <span className="font-black text-[#185C20]">{blowerAirflow.toLocaleString()} CMH</span>
                    </div>

                    <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                      <span className="text-gray-600 font-semibold">Static Pressure:</span>
                      <span className="font-bold text-gray-900">
                        {blowerPressure === 'dont_know' ? 'To be finalized by technical team' : `${blowerPressure} mmWG`}
                      </span>
                    </div>

                    <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                      <span className="text-gray-600 font-semibold">Application:</span>
                      <span className="font-bold text-gray-900 text-right">{blowerApplication}</span>
                    </div>

                    <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                      <span className="text-gray-600 font-semibold">Operating Environment:</span>
                      <span className="font-bold text-[#185C20] text-right">{blowerEnvironment}</span>
                    </div>

                    <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                      <span className="text-gray-600 font-semibold">Drive Arrangement:</span>
                      <span className="font-bold text-gray-900">{blowerDrive}</span>
                    </div>

                    <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                      <span className="text-gray-600 font-semibold">RPM:</span>
                      <span className="font-bold text-amber-900">As per blower design</span>
                    </div>

                    <div className="flex justify-between items-center pt-1">
                      <span className="text-gray-600 font-semibold">Construction (MOC):</span>
                      <span className="font-extrabold text-[#185C20] text-right">{getDerivedBlowerMaterial()}</span>
                    </div>
                  </div>

                  {/* Preliminary Technical Recommendation Note */}
                  <div className="p-3.5 bg-amber-100/80 rounded-2xl border border-amber-300 space-y-1">
                    <div className="text-[11px] font-black text-amber-950 uppercase tracking-wider">
                      Preliminary Technical Recommendation
                    </div>
                    <p className="text-[11px] text-amber-900 leading-relaxed font-medium italic">
                      “Final blower selection will be confirmed based on system resistance, operating temperature, application, motor requirement and site conditions.”
                    </p>
                  </div>

                  {/* Buttons */}
                  <div className="space-y-3 pt-1">
                    <button
                      onClick={handleBlowerTechRec}
                      className="w-full bg-gradient-to-r from-orange-600 to-rose-600 hover:from-orange-500 hover:to-rose-500 text-white py-3.5 px-4 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all hover:scale-102 cursor-pointer"
                    >
                      <FileText className="w-4 h-4 text-white shrink-0" />
                      <span>GET TECHNICAL RECOMMENDATION →</span>
                    </button>

                    <button
                      onClick={handleBlowerQuote}
                      className="w-full bg-[#185C20] hover:bg-emerald-800 text-white py-3.5 px-4 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all hover:scale-102 cursor-pointer"
                    >
                      <span>GET A QUOTE →</span>
                    </button>
                  </div>

                </div>

              </div>

              {/* Bottom Technical Disclaimer Note */}
              <div className="mt-8 pt-4 border-t border-gray-200 text-center">
                <p className="text-xs text-gray-500 max-w-3xl mx-auto leading-relaxed italic">
                  “The selection shown is a preliminary recommendation. Final blower capacity, pressure, motor power, RPM and construction will be confirmed by SRP Megha Power based on actual system and site requirements.”
                </p>
              </div>

            </div>
          )}

        </div>

      </div>

      {/* Transformer Technical Recommendation Modal */}
      {showTechRecModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 border border-emerald-600 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            
            {/* Close Button */}
            <button
              onClick={() => setShowTechRecModal(false)}
              className="absolute top-5 right-5 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-200">
              <div className="w-10 h-10 rounded-xl bg-[#185C20] text-white flex items-center justify-center font-bold">
                <FileText className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h3 className="text-lg font-black text-[#101820] uppercase tracking-wide">
                  TECHNICAL EQUIPMENT RECOMMENDATION
                </h3>
                <p className="text-xs text-gray-500 font-medium">
                  SRP Megha Power Engineering Specification Report
                </p>
              </div>
            </div>

            {/* Content Specifications */}
            <div className="space-y-4 text-xs">
              <div className="bg-[#F8FAF8] p-4 rounded-2xl border border-gray-200 space-y-2">
                <div className="text-[11px] font-black uppercase text-[#185C20] tracking-wider">
                  System Identification
                </div>
                <div className="text-base font-black text-[#101820]">
                  {recResult.machineTitle}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <span className="text-gray-500 text-[10px] uppercase font-extrabold block">Nominal Capacity</span>
                  <span className="font-extrabold text-[#185C20] text-sm">{recResult.nominalCapacity}</span>
                </div>
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <span className="text-gray-500 text-[10px] uppercase font-extrabold block">Application Duty</span>
                  <span className="font-extrabold text-gray-800 text-sm">{recResult.application}</span>
                </div>
              </div>

              <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200/80 space-y-2">
                <div className="font-extrabold text-[#185C20] text-xs uppercase">
                  Input Parameters Summary:
                </div>
                <ul className="space-y-1 text-gray-700 font-medium list-disc list-inside">
                  <li><strong>Transformer Oil Quantity:</strong> {oilVolume.toLocaleString()} Litres</li>
                  <li><strong>Transformer Type:</strong> {transformerType}</li>
                  <li><strong>Oil Condition:</strong> {oilCondition}</li>
                  <li><strong>Required Treatment:</strong> {requiredTreatment}</li>
                  <li><strong>Estimated Single Pass Time:</strong> {recResult.passHours} Hours</li>
                </ul>
              </div>

              <p className="text-[11px] text-gray-500 leading-relaxed italic">
                * Note: Estimated processing hours are calculated based on nominal machine flow rate under standard ambient operating temperatures. Actual degassing rates may vary based on initial BDV and moisture PPM levels.
              </p>
            </div>

            {/* Modal Actions */}
            <div className="mt-6 pt-4 border-t border-gray-200 flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => {
                  setShowTechRecModal(false);
                  handleGetQuote();
                }}
                className="flex-1 bg-[#185C20] hover:bg-[#0D3F18] text-white py-3 px-4 rounded-xl font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md"
              >
                <span>PROCEED TO REQUEST QUOTE</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setShowTechRecModal(false)}
                className="py-3 px-5 rounded-xl border border-gray-300 font-bold text-xs text-gray-700 hover:bg-gray-100"
              >
                Close Report
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Blower Technical Recommendation Modal */}
      {showBlowerTechRecModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 border border-emerald-600 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            
            {/* Close Button */}
            <button
              onClick={() => setShowBlowerTechRecModal(false)}
              className="absolute top-5 right-5 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-200">
              <div className="w-10 h-10 rounded-xl bg-[#185C20] text-white flex items-center justify-center font-bold">
                <FileText className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h3 className="text-lg font-black text-[#101820] uppercase tracking-wide">
                  CENTRIFUGAL BLOWER TECHNICAL SPECIFICATION
                </h3>
                <p className="text-xs text-gray-500 font-medium">
                  SRP Megha Power Engineering Recommendation Report
                </p>
              </div>
            </div>

            {/* Content Specifications */}
            <div className="space-y-4 text-xs">
              <div className="bg-[#F8FAF8] p-4 rounded-2xl border border-gray-200 space-y-2">
                <div className="text-[11px] font-black uppercase text-[#185C20] tracking-wider">
                  Selected Configuration
                </div>
                <div className="text-base font-black text-[#101820]">
                  Centrifugal Blower – {blowerAirflow.toLocaleString()} CMH
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <span className="text-gray-500 text-[10px] uppercase font-extrabold block">Airflow Capacity</span>
                  <span className="font-extrabold text-[#185C20] text-sm">{blowerAirflow.toLocaleString()} CMH</span>
                </div>
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <span className="text-gray-500 text-[10px] uppercase font-extrabold block">Static Pressure</span>
                  <span className="font-extrabold text-gray-800 text-sm">
                    {blowerPressure === 'dont_know' ? 'To be finalized' : `${blowerPressure} mmWG`}
                  </span>
                </div>
              </div>

              <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200/80 space-y-2">
                <div className="font-extrabold text-[#185C20] text-xs uppercase">
                  Technical Specifications Summary:
                </div>
                <ul className="space-y-1 text-gray-700 font-medium list-disc list-inside">
                  <li><strong>Application:</strong> {blowerApplication}</li>
                  <li><strong>Operating Environment:</strong> {blowerEnvironment}</li>
                  <li><strong>Preferred Material (MOC):</strong> {getDerivedBlowerMaterial()}</li>
                  <li><strong>Drive Arrangement:</strong> {blowerDrive}</li>
                  <li><strong>Speed:</strong> RPM: As per blower design</li>
                </ul>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 leading-relaxed font-medium text-[11px]">
                “The selection shown is a preliminary recommendation. Final blower capacity, pressure, motor power, RPM and construction will be confirmed by SRP Megha Power based on actual system and site requirements.”
              </div>
            </div>

            {/* Modal Actions */}
            <div className="mt-6 pt-4 border-t border-gray-200 flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => {
                  setShowBlowerTechRecModal(false);
                  handleBlowerQuote();
                }}
                className="flex-1 bg-[#185C20] hover:bg-[#0D3F18] text-white py-3 px-4 rounded-xl font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md"
              >
                <span>PROCEED TO REQUEST FORM / QUOTE</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setShowBlowerTechRecModal(false)}
                className="py-3 px-5 rounded-xl border border-gray-300 font-bold text-xs text-gray-700 hover:bg-gray-100"
              >
                Close Report
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
 };


