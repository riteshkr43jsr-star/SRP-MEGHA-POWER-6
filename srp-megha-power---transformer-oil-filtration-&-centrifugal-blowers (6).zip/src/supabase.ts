import { createClient } from '@supabase/supabase-js';

const DEFAULT_SUPABASE_URL = 'https://vmtwaxgkwouqxncxtwej.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable_r5ihGfZJRaYnPvbridEAiw_ztubE4tp';

function resolveSupabaseUrl(rawUrl?: string): string {
  const trimmed = (rawUrl || '').trim();
  if (!trimmed) return DEFAULT_SUPABASE_URL;

  // If the user provided only the Supabase project reference ID (e.g. "vmtwaxgkwouqxncxtwej")
  if (/^[a-z0-9]{15,30}$/i.test(trimmed)) {
    return `https://${trimmed}.supabase.co`;
  }

  // If protocol is missing (e.g. "vmtwaxgkwouqxncxtwej.supabase.co")
  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;

  try {
    const parsed = new URL(withProtocol);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.origin;
    }
  } catch {
    // Fallback to default valid URL below
  }

  return DEFAULT_SUPABASE_URL;
}

const supabaseUrl = resolveSupabaseUrl(import.meta.env.VITE_SUPABASE_URL);
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim() || DEFAULT_SUPABASE_ANON_KEY;

export const supabase = (() => {
  try {
    return createClient(supabaseUrl, supabaseAnonKey);
  } catch {
    return createClient(DEFAULT_SUPABASE_URL, DEFAULT_SUPABASE_ANON_KEY);
  }
})();

