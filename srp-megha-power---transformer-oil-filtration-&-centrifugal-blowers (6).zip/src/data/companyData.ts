import { ProductItem, ServiceItem, BlowerApplication, IndustryItem, FieldProject, ClientLogo, TestimonialItem } from '../types';

import { SITE_IMAGES } from '../config/images';

const heavyDutyBlowerImg = SITE_IMAGES.heavyDutyBlower;
const backwardCurvedImg = SITE_IMAGES.backwardCurvedBlower;
const forwardCurvedImg = SITE_IMAGES.forwardCurvedBlower;
const radialBladeImg = SITE_IMAGES.radialBladeBlower;
const airfoilBladeImg = SITE_IMAGES.airfoilBladeBlower;

export const COMPANY_DETAILS = {
  brandName: 'SRP MEGHA POWER',
  fullName: 'SRP Megha Power',
  slogan: 'Trusted for Power Quality and Reliability',
  location: 'Sakchi, Jamshedpur, Jharkhand, India',
  phonePrimary: '+91 86036 83851',
  phoneSecondary: '+91 91624 84535',
  whatsappNumber: '919162484535',
  email: 'srpmeghapower11@gmail.com',
  salesEmail: 'srpmeghapower11@gmail.com',
  businessHours: 'Mon - Sat: 8:30 AM - 6:30 PM (24/7 Field Emergency Line)',
  address: '1st Floor, New Kalimati Road, Near Chandra Hotel, P.O. & P.S. Sakchi, Jamshedpur, East Singhbhum, Jharkhand – 831001'
};

export const FILTRATION_PRODUCTS: ProductItem[] = [
  {
    id: 'oil-filter-10000',
    name: '10,000 LPH High-Vacuum Transformer Oil Filtration Machine',
    category: 'filtration',
    capacity: '10,000 LPH (Max Capacity)',
    badge: 'Max Plant Capacity • EHV',
    shortDesc: 'Maximum capacity double-stage high-vacuum oil purification plant engineered for EHV power transformers and large substation maintenance.',
    fullDesc: 'Engineered for rapid, high-volume online and offline conditioning of transformer insulating oil up to 10,000 LPH (Maximum Capacity). Equipped with high-vacuum two-stage degassing chambers, Roots booster pump, high-efficiency oil heaters with automatic SCR temperature control, and 1-micron fine cartridge filters to achieve BDV > 70 kV.',
    image: '',
    specs: [
      'Flow Rate: 10,000 Litres Per Hour (Maximum Filtration Capacity)',
      'Vacuum System: High-Vacuum Two-Stage Dehydration & Degassing Chamber',
      'Moisture Removal: High-Efficiency Vacuum Dehydration (< 5 PPM)',
      'Dissolved Gas Removal: Deep Vacuum Degassing (< 0.1% by volume)',
      'Filtration Fineness: Up to 1 Micron fine micro-glass filtration',
      'Breakdown Voltage (BDV): Restores dielectric strength up to 70 - 78+ kV',
      'Heating Power: Low watt-density interlocked electric oil heater',
      'Control System: Automated PLC with Touchscreen HMI & Auto Interlocks',
      'Mounting: Stationary / Skid-Mounted / Trailer-Mounted / Truck-Mounted'
    ],
    applications: [
      'High Voltage Power Substations (132kV / 220kV / 400kV)',
      'Steel Manufacturing Plants & Rolling Mills (Tata Steel, SAIL, JSPL)',
      'Thermal & Hydro Power Generating Stations',
      'Large Industrial Transformer Overhauling & Commissioning'
    ]
  },
  {
    id: 'oil-filter-6000',
    name: '6,000 LPH Transformer Oil Filtration Machine',
    category: 'filtration',
    capacity: '6,000 LPH',
    badge: 'Heavy Industrial Duty',
    shortDesc: 'Heavy-duty double-stage high-vacuum oil dehydration and degassing plant for power utilities and industrial substations.',
    fullDesc: 'Built for continuous heavy-duty substation operation delivering 6,000 LPH flow rate. Rapidly extracts dissolved moisture, gases, carbon particles, and oxidation sludge from power and furnace transformers.',
    image: '',
    specs: [
      'Flow Rate: 6,000 Litres Per Hour',
      'Vacuum System: Double-Stage High-Vacuum Degassing Chamber',
      'Moisture & Gas Removal: High-Efficiency Vacuum Dehydration & Degassing',
      'Particle Retention: 1 Micron precision filter cartridges',
      'Heating System: Thermostatically controlled low watt-density oil heater',
      'Control Panel: Weatherproof PLC / Automatic Control Panel with safety trips',
      'Mounting: Heavy-duty mobile trailer or skid frame'
    ],
    applications: [
      'Power & Furnace Transformers (33kV / 132kV / 220kV)',
      'Captive Power Plants & Steel Melt Shops',
      'Mining & Mineral Processing Substations',
      'Scheduled Shutdown Transformer Conditioning'
    ]
  },
  {
    id: 'oil-filter-5000',
    name: '5,000 LPH Transformer Oil Filtration Machine',
    category: 'filtration',
    capacity: '5,000 LPH',
    badge: 'Most Popular',
    shortDesc: 'Versatile high-vacuum transformer oil purification plant ideal for medium to large power transformers.',
    fullDesc: 'Designed for optimal performance and mobile field utility. Provides thorough removal of dissolved moisture, gases, free carbon, and sludge particles to extend dielectric life and ensure uninterrupted transformer performance.',
    image: '',
    specs: [
      'Flow Rate: 5,000 Litres Per Hour',
      'Vacuum System: High-Vacuum Dehydration & Degassing Chamber',
      'Moisture Removal: High-Efficiency Vacuum Dehydration',
      'Particle Retention: 1 Micron micro-glass filter elements',
      'Oil Heating: Multi-stage interlocked electric heating',
      'Safety Features: Flow switch, Over-pressure relief, Over-temp trip',
      'Frame Type: Heavy duty skid with caster wheels or towable trailer'
    ],
    applications: [
      'Distribution Transformer Maintenance',
      'Mining Operations & Heavy Sub-stations',
      'Cement & Chemical Process Facilities',
      'On-site Preventive Servicing'
    ]
  },
  {
    id: 'oil-filter-3000',
    name: '3,000 LPH Transformer Oil Filtration Machine',
    category: 'filtration',
    capacity: '3,000 LPH',
    shortDesc: 'Compact high-vacuum oil dehydration plant built for factory maintenance and medium distribution substations.',
    fullDesc: 'Delivers reliable oil conditioning with low energy consumption. Perfect for utility service teams requiring fast setup, robust construction, and high filtration reliability.',
    image: '',
    specs: [
      'Flow Rate: 3,000 Litres Per Hour',
      'Vacuum System: High-Vacuum Dehydration Chamber',
      'BDV Improvement: Significant dielectric strength enhancement',
      'Control Panel: Automatic interlocked control scheme',
      'Oil Heater: Low surface watt density elements'
    ],
    applications: [
      'Furnace Transformers',
      'Manufacturing Plants & Industrial Grids',
      'Transformer Manufacturing & Rewinding Facilities'
    ]
  },
  {
    id: 'oil-filter-1000',
    name: '1,000 LPH Transformer Oil Filtration Machine',
    category: 'filtration',
    capacity: '1,000 LPH',
    shortDesc: 'Lightweight, high-precision vacuum oil conditioning unit for smaller distribution transformers and OLTC oil.',
    fullDesc: 'Extremely easy to maneuver around constrained factory spaces or small indoor substations. Ideal for tight spaces without sacrificing vacuum degassing efficiency.',
    image: '',
    specs: [
      'Flow Rate: 1,000 Litres Per Hour',
      'Operation Mode: Continuous / Batch Treatment',
      'Filtration Level: 1 - 3 Micron',
      'Power Input: 3-Phase 415V, 50Hz'
    ],
    applications: [
      'Distribution Transformers (11kV / 33kV)',
      'On-load Tap Changer (OLTC) Oil Purification',
      'Captive Power Generation Units'
    ]
  },
  {
    id: 'oil-filter-portable',
    name: 'Portable Oil Filtration Unit',
    category: 'filtration',
    capacity: '500 - 1,000 LPH',
    badge: 'Compact & Mobile',
    shortDesc: 'Highly mobile trolley-mounted oil filtration and transfer unit for fast emergency field servicing.',
    fullDesc: 'Rugged trolley frame fitted with high-efficiency mechanical oil filters and transfer pump for oil topping, moisture removal, and particulate polishing in hard-to-reach locations.',
    image: '',
    specs: [
      'Flow Rate: 500 to 1,000 LPH customizable',
      'Filter Media: Washable stainless steel strainer + micro cartridge',
      'Weight: Under 180 kg for easy transport',
      'Protection: Thermal overload and dry run protection'
    ],
    applications: [
      'Emergency Oil Top-up & Filtration',
      'Circuit Breakers & Switchgear Maintenance',
      'Small Plant Electrical Workshops'
    ]
  }
];

export const CENTRIFUGAL_BLOWERS: ProductItem[] = [
  {
    id: 'blower-heavy-duty-series',
    name: 'Industrial Heavy Duty Series Centrifugal Blower',
    category: 'blower',
    subcategory: 'Heavy Duty',
    badge: 'Industrial Heavy Duty Series',
    shortDesc: 'Heavy-duty large industrial centrifugal blower engineered for intense air and gas handling across steel and power facilities.',
    fullDesc: 'Specially engineered heavy-duty industrial series featuring reinforced casing and high-torque motor drive for continuous heavy industrial plant duty.',
    image: heavyDutyBlowerImg,
    specs: [
      'Air Flow Volume: Up to 150,000 CMH',
      'Static Pressure: Up to 15,000 Pa',
      'Construction: Heavy plate welded steel with anti-vibration mountings',
      'Drive Type: Direct shaft coupled or heavy V-belt drive'
    ],
    applications: ['Steel Rolling Mills', 'Thermal Power Plants', 'Sinter & Kiln Air Systems']
  },
  {
    id: 'blower-backward-curved',
    name: 'Backward Curved Centrifugal Blower',
    category: 'blower',
    subcategory: 'Heavy Duty',
    badge: 'High Efficiency',
    shortDesc: 'High-efficiency aerodynamic blower for clean air, hot gases, and high-pressure forced draft industrial systems.',
    fullDesc: 'Features self-limiting horsepower characteristics to prevent motor overload. Ideal for high static pressure systems requiring continuous high-volume air movement in steel, power, and cement plants.',
    image: backwardCurvedImg,
    specs: [
      'Air Flow Volume: Up to 120,000 CMH',
      'Static Pressure: Up to 12,000 Pa',
      'Impeller Material: Mild Steel, Stainless Steel (SS304/SS316), Hardox',
      'Efficiency Rating: Up to 85%',
      'Drive Options: Direct Coupled or V-Belt Drive'
    ],
    applications: ['Boiler ID/FD Fans', 'Furnace Blower Systems', 'Kiln Air Supply', 'Dust Extraction']
  },
  {
    id: 'blower-forward-curved',
    name: 'Forward Curved Centrifugal Blower',
    category: 'blower',
    subcategory: 'Process Air',
    shortDesc: 'Compact centrifugal fan delivering high airflow at moderate static pressures with quiet operational acoustic profile.',
    fullDesc: 'Engineered with multi-vane forward curved impellers for HVAC, process ventilation, drying ovens, and industrial air handling where physical footprint is limited.',
    image: forwardCurvedImg,
    specs: [
      'Air Flow Volume: Up to 50,000 CMH',
      'Pressure Range: Up to 3,500 Pa',
      'Noise Level: Low acoustic noise profile',
      'Construct: Heavy gauge sheet steel housing with inlet damper'
    ],
    applications: ['HVAC Ventilation', 'Industrial Air Washers', 'Drying Ovens & Paint Booths']
  },
  {
    id: 'blower-radial-bladed',
    name: 'Radial Blade Centrifugal Blower',
    category: 'blower',
    subcategory: 'Material Handling',
    shortDesc: 'Heavy-duty self-cleaning impeller blower designed for dust, sawdust, pneumatic conveying, and sticky particulate exhaust.',
    fullDesc: 'Rugged radial blade design prevents material build-up on impeller blades. Ideal for abrasive material handling, wood chips, paper trim, and pneumatic conveying lines.',
    image: radialBladeImg,
    specs: [
      'Design Type: Open radial paddle blades',
      'Wear Resistance: Replaceable wear liners available',
      'Pressure Rating: Up to 8,000 Pa',
      'Casing: Heavy plate welded scroll casing'
    ],
    applications: ['Woodworking Dust Systems', 'Pneumatic Conveying', 'Foundry Exhaust', 'Granule Handling']
  },
  {
    id: 'blower-airfoil',
    name: 'Airfoil Blade Centrifugal Blower',
    category: 'blower',
    subcategory: 'High Efficiency',
    badge: 'Premium Energy Saver',
    shortDesc: 'Ultra-quiet aerodynamic airfoil blade fan designed for maximum mechanical efficiency and energy savings.',
    fullDesc: 'Aerodynamically shaped hollow airfoil blades deliver peak mechanical efficiencies above 88%, reducing operational electricity overhead in large-scale industrial ventilation.',
    image: airfoilBladeImg,
    specs: [
      'Mechanical Efficiency: > 88%',
      'Air Volume: Up to 25,000 CMH',
      'Drive: Direct / Belt / Coupled',
      'Application: Custom Process Ventilation'
    ],
    applications: ['Power Plant Ventilation', 'Mine Shaft Air Supply', 'Large Cleanroom HVAC']
  }
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'srv-electrical-services',
    title: 'Electrical Engineering & Equipment Supply',
    description: 'Turnkey electrical supply, switchgear, control panels, and comprehensive plant maintenance support.',
    iconName: 'Zap',
    features: [
      'Switchgear supply (HT / LT breakers & isolators)',
      'Electrical panels (PCC, MCC, APFC & Control Panels)',
      'Plant maintenance and support (Preventive & AMC)',
      'Industrial electrical testing & commissioning'
    ]
  },
  {
    id: 'srv-oil-filtration',
    title: 'Transformer Oil Filtration',
    description: 'On-site filtration to remove moisture, gases, and particulate impurities from transformer insulating oil.',
    iconName: 'Droplets',
    features: [
      'High-vacuum double stage dehydration',
      'On-line and off-line filtration capability',
      'Particle removal down to 1 micron',
      'BDV restoration up to 70+ kV'
    ]
  },
  {
    id: 'srv-oil-drying',
    title: 'Oil Drying & Degassing',
    description: 'Vacuum dehydration and degassing under strict temperature control for superior oil dielectric quality.',
    iconName: 'Flame',
    features: [
      'High-efficiency vacuum degassing',
      'High-efficiency vacuum dehydration',
      'Controlled low watt-density oil heating',
      'Continuous moisture & temperature monitoring'
    ]
  },
  {
    id: 'srv-purification',
    title: 'Oil Purification & Restoration',
    description: 'Restores dielectric strength, reduces acidity, and extends transformer oil active service life.',
    iconName: 'Sparkles',
    features: [
      'Acidity neutralization & sludge removal',
      'Interfacial tension (IFT) improvement',
      'Substantial cost savings vs. full oil replacement',
      'Environmentally friendly oil reclamation'
    ]
  },
  {
    id: 'srv-testing',
    title: 'Oil Testing & Analysis',
    description: 'Complete transformer oil laboratory testing and analysis in accordance with IS/IEC standards.',
    iconName: 'FlaskConical',
    features: [
      'Breakdown Voltage (BDV) testing',
      'Water content (Karl Fischer titration)',
      'Dissolved Gas Analysis (DGA)',
      'Acidity, Flash Point & Tan Delta testing'
    ]
  },
  {
    id: 'srv-maintenance',
    title: 'Transformer & Substation Maintenance',
    description: 'Comprehensive preventive and corrective maintenance for reliable transformer and switchgear operation.',
    iconName: 'Wrench',
    features: [
      'Gasket replacement & leak repair',
      'Switchgear & Bushings inspection & overhaul',
      'OLTC servicing & contact cleaning',
      'Plant maintenance and support'
    ]
  },
  {
    id: 'srv-onsite-support',
    title: 'Onsite Support & Commissioning',
    description: 'Expert field support for equipment installation, commissioning, troubleshooting, and assistance.',
    iconName: 'Headset',
    features: [
      '24/7 Emergency response teams',
      'Site erection and oil filling under vacuum',
      'Pre-commissioning electrical testing',
      'Annual Maintenance Contracts (AMC)'
    ]
  }
];

export const BLOWER_APPLICATIONS: BlowerApplication[] = [
  { 
    id: 'app-steel',
    title: 'Steel Plants', 
    subtitle: 'Primary Steel & Rolling Mills',
    description: 'Blast furnace combustion air supply, sintering plant draft fans, coke oven gas exhaust blowers, and ladle furnace fume extraction.', 
    icon: 'Factory', 
    bgTag: 'Primary Steel Heavy Duty',
    highlightType: 'steel',
    keyEquipment: ['Blast Furnace', 'Sintering Bed', 'Coke Oven Gas', 'Ladle Furnace']
  },
  { 
    id: 'app-mining',
    title: 'Mining Plants & Operations', 
    subtitle: 'Underground & Mineral Processing',
    description: 'Underground mine shaft forced ventilation, dust extraction systems, ore froth flotation aeration, and crusher house suction fans.', 
    icon: 'Pickaxe', 
    bgTag: 'Heavy Mining & Ore',
    highlightType: 'mining',
    keyEquipment: ['Mine Shaft Vent', 'Dust Extraction', 'Froth Flotation', 'Crusher Exhaust']
  },
  { 
    id: 'app-cement',
    title: 'Cement Plants', 
    subtitle: 'Clinker & Kiln Processing',
    description: 'Kiln ID/FD fans, clinker cooler high-pressure blowers, raw mill dust collectors, and pneumatic fly ash conveying.', 
    icon: 'Building2', 
    bgTag: 'Abrasive Dust Duty',
    keyEquipment: ['Kiln Draft Fan', 'Clinker Cooler', 'Raw Mill Exhaust', 'Bag Filter Suction']
  },
  { 
    id: 'app-power',
    title: 'Power Generation', 
    subtitle: 'Thermal & Utility Power Plants',
    description: 'Boiler forced and induced draft fans, primary air fans, flue gas desulfurization (FGD), and turbine hall ventilation.', 
    icon: 'Zap', 
    bgTag: 'Continuous 24/7 Duty',
    keyEquipment: ['Induced Draft Fan', 'Forced Draft Fan', 'FGD Blower', 'Turbine Hall Vent']
  },
  { 
    id: 'app-chemical',
    title: 'Chemical & Petrochemical', 
    subtitle: 'Process Scrubbers & Acid Fumes',
    description: 'Corrosion-resistant FRP/SS316 blowers for toxic chemical fumes, acid vapor scrubbers, and gas recirculation.', 
    icon: 'FlaskRound', 
    bgTag: 'Corrosion Proof FRP/SS',
    keyEquipment: ['Scrubber Blower', 'Acid Fume Exhaust', 'Chlorine Gas Handling', 'Process Vapor']
  },
  { 
    id: 'app-manufacturing',
    title: 'Manufacturing Facilities', 
    subtitle: 'Industrial Shop Floor Utility',
    description: 'HVAC shop floor ventilation, paint spray booth exhaust, cleanroom pressure maintenance, and process cooling.', 
    icon: 'Cog', 
    bgTag: 'Plant HVAC & Air',
    keyEquipment: ['Shop Floor Vent', 'Paint Booth Exhaust', 'Drying Oven Fan', 'Cooling Blower']
  },
  { 
    id: 'app-ovens',
    title: 'Heat Exchangers & Ovens', 
    subtitle: 'High Temperature Process Duty',
    description: 'Hot air recirculation plug fans, tempering furnace blowers, and forced draft furnace burners for thermal processing.', 
    icon: 'Flame', 
    bgTag: 'High Temp Duty',
    keyEquipment: ['Furnace Burner', 'Recirculation Fan', 'Drying Kiln Blower', 'Thermal Oxidizer']
  },
  { 
    id: 'app-scrubbers',
    title: 'Dust Collection & Scrubbers', 
    subtitle: 'Air Quality & Environmental',
    description: 'Pulse-jet baghouse suction blowers, cyclone separator exhaust fans, and wet scrubber environmental air handling.', 
    icon: 'Wind', 
    bgTag: 'Air Filtration Duty',
    keyEquipment: ['Baghouse Fan', 'Cyclone Blower', 'Wet Scrubber Fan', 'Aerosol Extraction']
  }
];

export const INDUSTRIES_SERVED: IndustryItem[] = [
  { 
    id: 'ind-steel', 
    name: 'MANUFACTURING STEEL PLANT', 
    description: 'Supporting steel manufacturing plants with heavy-duty equipment, furnace blowers, and transformer oil filtration.', 
    icon: 'Factory', 
    image: '' 
  },
  { 
    id: 'ind-mining', 
    name: 'MINING PLANT', 
    description: 'Durable ventilation blowers and oil filtration for heavy mining and mineral extraction plants.', 
    icon: 'Pickaxe', 
    image: '' 
  },
  { 
    id: 'ind-manufacturing', 
    name: 'MANUFACTURING PLANT', 
    description: 'Enhancing productivity across industrial manufacturing plants with efficient equipment and maintenance.', 
    icon: 'Cog', 
    image: '' 
  },
  { 
    id: 'ind-power', 
    name: 'POWER GENERATION PLANT', 
    description: 'Reliable filtration and fan maintenance for uninterrupted power generation and thermal utility plants.', 
    icon: 'Zap', 
    image: '' 
  },
  { 
    id: 'ind-cement', 
    name: 'CEMENT MANUFACTURING PLANT', 
    description: 'Improving efficiency and equipment lifespan across heavy cement manufacturing plants.', 
    icon: 'Building', 
    image: '' 
  },
  { 
    id: 'ind-automotive', 
    name: 'AUTOMOTIVE PLANT', 
    description: 'Precision air handling and power utility solutions for smooth automotive plant operations.', 
    icon: 'Car', 
    image: '' 
  },
  { 
    id: 'ind-chemical', 
    name: 'CHEMICAL & PETROCHEMICAL PLANT', 
    description: 'Corrosion-resistant and high-performance solutions for critical chemical processing plants.', 
    icon: 'FlaskConical', 
    image: '' 
  },
  { 
    id: 'ind-infrastructure', 
    name: 'INFRASTRUCTURE PLANT', 
    description: 'Powering heavy infrastructure development and municipal engineering projects with robust equipment.', 
    icon: 'Briefcase', 
    image: '' 
  }
];

export const FIELD_PROJECTS: FieldProject[] = [
  {
    id: 'proj-1',
    title: '220kV Power Transformer Oil Filtration & BDV Enhancement',
    category: 'filtration',
    location: 'Integrated Steel Plant, Jamshedpur',
    image: '',
    description: 'On-site vacuum dehydration of 10,000 Litres transformer oil using 10,000 LPH double-stage filtration unit. Restored BDV from 32 kV to 78 kV.'
  },
  {
    id: 'proj-2',
    title: 'Heavy Duty Boiler ID Fan Supply & Commissioning',
    category: 'blower',
    location: 'Captive Power Plant, Jharkhand',
    image: heavyDutyBlowerImg,
    description: 'Custom manufactured 110,000 CMH high-temperature backward curved ID fan with dynamic balancing and VFD control.'
  },
  {
    id: 'proj-3',
    title: 'Comprehensive Transformer Servicing & Gasket Overhaul',
    category: 'maintenance',
    location: 'Mining Substation, Chaibasa',
    image: '',
    description: 'Complete gasket replacement, nitrogen purging, oil testing, and high-vacuum oil filling for a 20 MVA power transformer.'
  },
  {
    id: 'proj-4',
    title: '10,000 LPH Skid-Mounted Oil Filtration Machine Supply',
    category: 'filtration',
    location: 'Manufacturing Unit, Adityapur Industrial Area',
    image: '',
    description: 'Delivered PLC-controlled weather-proof trailer mounted oil purification machine with integrated digital moisture sensor.'
  },
  {
    id: 'proj-5',
    title: 'Corrosion-Resistant FRP Scrubber Blower System',
    category: 'blower',
    location: 'Chemical Pickling Facility, Jamshedpur',
    image: heavyDutyBlowerImg,
    description: 'Manufactured and installed dual FRP 25,000 CMH acid fume extraction blowers with zero corrosion after 3+ years.'
  },
  {
    id: 'proj-6',
    title: 'Substation Electrical AMC & Annual Oil Testing Program',
    category: 'electrical',
    location: 'Industrial Heavy Engineering Complex',
    image: '',
    description: 'Annual Maintenance Contract covering 18 transformers, DGA oil sampling, contacts overhauling, and 24/7 emergency support.'
  }
];

export const CLIENT_LOGOS: ClientLogo[] = [
  { 
    name: 'Tata Steel', 
    logoText: 'TATA STEEL', 
    subtitle: 'Integrated Steel Giant', 
    color: '#00529C', 
    logoType: 'tata-steel',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8e/Tata_logo.svg'
  },
  { 
    name: 'SAIL', 
    logoText: 'SAIL', 
    subtitle: 'Steel Authority of India', 
    color: '#002B49', 
    logoType: 'sail',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/d/d4/Steel_Authority_of_India_logo.svg'
  },
  { 
    name: 'Tata Motors', 
    logoText: 'TATA MOTORS', 
    subtitle: 'Automobile Manufacturer', 
    color: '#003865', 
    logoType: 'tata-motors',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8e/Tata_logo.svg'
  },
  { 
    name: 'Tata Metaliks', 
    logoText: 'TATA METALIKS', 
    subtitle: 'Pig Iron & Ductile Pipes', 
    color: '#00529C', 
    logoType: 'tata-metaliks',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8e/Tata_logo.svg'
  },
  { 
    name: 'Rungta Mines', 
    logoText: 'RUNGTA MINES', 
    subtitle: 'Steel & Mining Conglomerate', 
    color: '#C8102E', 
    logoType: 'rungta',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8e/Tata_logo.svg'
  },
  { 
    name: 'Timken', 
    logoText: 'TIMKEN', 
    subtitle: 'Roller Bearing Technology', 
    color: '#E31837', 
    logoType: 'timken',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/7/7d/Timken.svg'
  },
  { 
    name: 'Tin Plate Company', 
    logoText: 'TINPLATE', 
    subtitle: 'The Tinplate Co. of India (TCIL)', 
    color: '#003865', 
    logoType: 'tinplate',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8e/Tata_logo.svg'
  },
  { 
    name: 'Tata Growth Shop', 
    logoText: 'TATA GROWTH SHOP', 
    subtitle: 'Heavy Machinery & Fabrication', 
    color: '#00529C', 
    logoType: 'tata-growth',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8e/Tata_logo.svg'
  },
  { 
    name: 'ISWP (Tata Enterprise)', 
    logoText: 'ISWP • TATA STEEL', 
    subtitle: 'Indian Steel & Wire Products Ltd', 
    color: '#00529C', 
    logoType: 'iswp',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8e/Tata_logo.svg'
  },
  { 
    name: 'Usha Martin', 
    logoText: 'USHA MARTIN', 
    subtitle: 'Wire Ropes & Specialty Steel', 
    color: '#FF5B00', 
    logoType: 'usha-martin',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Logo_UshaMartin.png/320px-Logo_UshaMartin.png'
  },
  { 
    name: 'Linde India', 
    logoText: 'LINDE', 
    subtitle: 'Industrial Gases & Engineering', 
    color: '#005596', 
    logoType: 'linde',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/e/e0/TheLindeGroup-Logo.svg'
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'test-1',
    authorName: 'Er. Rajesh Kumar Sharma',
    quote: 'The on-site oil filtration for our 50 MVA furnace transformer was executed within record time during our planned shutdown. BDV levels were restored from 32 kV well above 78 kV.',
    role: 'DGM — Maintenance & Electrical',
    organization: 'Nilachal Iron & Steel',
    rating: 5,
    location: 'Jamshedpur, Jharkhand',
    industryCategory: 'steel',
    date: 'August 2026',
    verifiedContract: 'Verified Steel Plant Contract',
    avatarColor: 'from-blue-600 to-indigo-700'
  },
  {
    id: 'test-2',
    authorName: 'V. K. Agarwal',
    quote: 'We procured backward curved ID fans for our captive boiler plant. The build quality, dynamic balancing, and low vibration levels met our exact specifications.',
    role: 'Chief Engineer — Mechanical Operations',
    organization: 'Damodar Power Utilities',
    rating: 5,
    location: 'West Bengal',
    industryCategory: 'power',
    date: 'July 2026',
    verifiedContract: 'Verified Power Utility Contract',
    avatarColor: 'from-[#185C20] to-emerald-700'
  },
  {
    id: 'test-3',
    authorName: 'Amitabh Roy',
    quote: 'The 5,000 LPH trailer-mounted mobile transformer oil purification machine has been running efficiently across our mine sub-stations. Features a heavy-duty PLC panel and high vacuum pumps.',
    role: 'General Manager — Substation Maintenance',
    organization: 'Eastern Minerals & Mining',
    rating: 5,
    location: 'Bihar',
    industryCategory: 'mining',
    date: 'June 2026',
    verifiedContract: 'Verified Mining & Substation Client',
    avatarColor: 'from-amber-500 to-orange-600'
  },
  {
    id: 'test-4',
    authorName: 'S. P. Singh',
    quote: 'Ordered custom FRP acid fume extraction blowers for our pickling line. The chemical resistance and airflow performance are exactly as designed.',
    role: 'Head of Maintenance & Safety',
    organization: 'Adityapur Speciality Forgings',
    rating: 5,
    location: 'Adityapur Industrial Area',
    industryCategory: 'chemical',
    date: 'May 2026',
    verifiedContract: 'Verified Chemical Fume Contract',
    avatarColor: 'from-purple-600 to-pink-600'
  },
  {
    id: 'test-5',
    authorName: 'Dharmendra Patnaik',
    quote: 'The Annual Maintenance Contract (AMC) covers our 18 plant transformers. Regular DGA sampling and BDV testing are conducted strictly according to our schedule.',
    role: 'Chief Electrical Officer',
    organization: 'Subarnarekha Heavy Engineering',
    rating: 5,
    location: 'Jamshedpur, Jharkhand',
    industryCategory: 'manufacturing',
    date: 'April 2026',
    verifiedContract: 'Verified Electrical AMC Client',
    avatarColor: 'from-teal-600 to-cyan-700'
  },
  {
    id: 'test-6',
    authorName: 'B. K. Mahato',
    quote: 'High pressure combustion blowers delivered for our continuous reheating furnace. The static pressure generation and rugged construction are aligned with our needs.',
    role: 'Plant Manager — Rolling Mill',
    organization: 'Kalinga Metallics Ltd.',
    rating: 5,
    location: 'Kalinganagar, Odisha',
    industryCategory: 'steel',
    date: 'March 2026',
    verifiedContract: 'Verified Industrial Blower Client',
    avatarColor: 'from-rose-600 to-red-700'
  }
];
