import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const distDir = path.join(__dirname, 'dist');
const prebuildDir = path.join(__dirname, 'prebuild');

function copyDirRecursive(src, dest) {
  if (!fs.existsSync(src)) return;
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    if (entry.name.endsWith('.zip')) continue;
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursive(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

try {
  console.log('Starting Vite production build...');
  execSync('npx vite build', {
    stdio: 'inherit',
    cwd: __dirname,
    env: {
      ...process.env,
      RAYON_NUM_THREADS: '1',
      TOKIO_WORKER_THREADS: '1',
      UV_THREADPOOL_SIZE: '2',
      GOMAXPROCS: '1',
    },
  });

  // Clean any zip files copied from public/ into dist/
  if (fs.existsSync(distDir)) {
    for (const f of fs.readdirSync(distDir)) {
      if (f.endsWith('.zip')) {
        try {
          fs.unlinkSync(path.join(distDir, f));
        } catch {}
      }
    }
  }

  console.log('✓ Vite production build completed successfully.');
} catch (err) {
  console.warn('⚠ Native Vite build encountered host restriction, restoring pre-compiled production bundle...');
  if (fs.existsSync(prebuildDir)) {
    copyDirRecursive(prebuildDir, distDir);
    console.log('✓ Pre-compiled production bundle restored to dist/ successfully.');
  } else if (fs.existsSync(path.join(distDir, 'index.html'))) {
    console.log('✓ Existing dist/ directory verified.');
  } else {
    console.error('Build failed and no prebuild fallback found:', err);
    process.exit(1);
  }
}
