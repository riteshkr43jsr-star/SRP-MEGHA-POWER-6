import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { TrustStats } from './components/TrustStats';
import { ServicesSection } from './components/ServicesSection';
import { FiltrationShowcase } from './components/FiltrationShowcase';
import { BlowerShowcase } from './components/BlowerShowcase';
import { BlowerApplications } from './components/BlowerApplications';
import { BlowerSpecsPanel } from './components/BlowerSpecsPanel';
import { CapacityCalculator } from './components/CapacityCalculator';
import { WhyChooseUs } from './components/WhyChooseUs';
import { IndustriesWeServe } from './components/IndustriesWeServe';
import { AboutUs } from './components/AboutUs';
import { ClientsCarousel } from './components/ClientsCarousel';
import { Testimonials } from './components/Testimonials';
import { ConversionCTA } from './components/ConversionCTA';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

import { ProductDetailModal } from './components/ProductDetailModal';
import { QuoteModal } from './components/QuoteModal';
import { SearchModal } from './components/SearchModal';
import { FloatingActions } from './components/FloatingActions';

import { AdminApp } from './components/admin/AdminApp';

import { ProductItem } from './types';

export default function App() {
  const [isAdminView, setIsAdminView] = useState(() => window.location.hash === '#admin');
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);
  const [isQuoteOpen, setIsQuoteOpen] = useState(false);
  const [quotePrefill, setQuotePrefill] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    const handleHashChange = () => {
      setIsAdminView(window.location.hash === '#admin');
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  if (isAdminView) {
    return <AdminApp />;
  }

  const handleOpenQuote = (productOrService?: string) => {
    if (productOrService) {
      setQuotePrefill(productOrService);
    } else {
      setQuotePrefill('General Industrial Enquiry');
    }
    setIsQuoteOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#F7F9F6] text-[#101A24] font-sans antialiased flex flex-col justify-between">
      
      {/* Sticky Header */}
      <Header 
        onOpenQuote={handleOpenQuote} 
        onSearchOpen={() => setIsSearchOpen(true)} 
      />

      {/* Main Page Content */}
      <main className="flex-grow">
        
        {/* Hero Section */}
        <Hero onOpenQuote={handleOpenQuote} />

        {/* Quick Trust Stats Strip */}
        <TrustStats />

        {/* Core Services Section */}
        <ServicesSection onOpenQuote={handleOpenQuote} />

        {/* Category A: Transformer Oil Filtration Showcase */}
        <FiltrationShowcase 
          onSelectProduct={(p) => setSelectedProduct(p)} 
          onOpenQuote={handleOpenQuote} 
        />

        {/* Category B: Centrifugal Blowers Showcase */}
        <BlowerShowcase 
          onSelectProduct={(b) => setSelectedProduct(b)} 
          onOpenQuote={handleOpenQuote} 
        />

        {/* Blower Applications */}
        <BlowerApplications onOpenQuote={handleOpenQuote} />

        {/* Blower Technical Specifications Panel */}
        <BlowerSpecsPanel onOpenQuote={handleOpenQuote} />

        {/* Interactive Equipment Capacity & Flow Calculator Tool */}
        <CapacityCalculator onOpenQuoteWithDetails={handleOpenQuote} />

        {/* Why Choose Us */}
        <WhyChooseUs onOpenQuote={() => handleOpenQuote('General Equipment Inquiry')} />

        {/* Industries We Serve */}
        <IndustriesWeServe onOpenQuote={handleOpenQuote} />

        {/* About Us */}
        <AboutUs onOpenQuote={() => handleOpenQuote('Corporate Inquiry')} />

        {/* Clients & Trusted Partners */}
        <ClientsCarousel />

        {/* Customer Testimonials */}
        <Testimonials />

        {/* Conversion Banner CTA */}
        <ConversionCTA onOpenQuote={() => handleOpenQuote('Conversion Banner Inquiry')} />

        {/* Contact & RFQ Form Section */}
        <ContactSection initialSubject={quotePrefill} />

      </main>

      {/* Footer */}
      <Footer />

      {/* Product Detail Modal */}
      <ProductDetailModal 
        product={selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
        onOpenQuote={handleOpenQuote} 
      />

      {/* Quote RFQ Modal */}
      <QuoteModal 
        isOpen={isQuoteOpen} 
        prefilledItem={quotePrefill} 
        onClose={() => setIsQuoteOpen(false)} 
      />

      {/* Search Modal */}
      <SearchModal 
        isOpen={isSearchOpen} 
        onClose={() => setIsSearchOpen(false)} 
        onSelectProduct={(p) => setSelectedProduct(p)} 
      />

      {/* Floating Action Pill & Back to Top */}
      <FloatingActions onOpenQuote={() => handleOpenQuote('Quick Floating Action')} />

    </div>
  );
}
