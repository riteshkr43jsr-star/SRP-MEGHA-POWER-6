import React, { useState } from 'react';
import { 
  ArrowRight, 
  MapPin, 
  Building2, 
  Droplet, 
  Wind, 
  Zap, 
  ShieldCheck, 
  Cpu, 
  Users, 
  Clock, 
  Trophy,
  CheckCircle2,
  Package,
  Wrench,
  FileSignature
} from 'lucide-react';
import { SITE_IMAGES } from '../config/images';

interface HeroProps {
  onOpenQuote: (productOrService?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenQuote }) => {
  const [activeCard, setActiveCard] = useState<string | null>(null);

  const handleCardClick = (id: string, targetId: string) => {
    setActiveCard(id);
    setTimeout(() => {
      const element = document.getElementById(targetId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 400); // 400ms delay to show the lighting effect
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative bg-[#F8FAF7] pt-6 md:pt-10 pb-0 overflow-hidden border-b border-[#DDE5DC]">
      {/* Background Engineering Pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Main Hero Top Section */}
        <div className="pb-12 lg:grid lg:grid-cols-12 lg:gap-10 lg:items-center">
          
          {/* Headline, Subtitle, Regional Info, CTAs */}
          <div className="lg:col-span-6 space-y-7 text-left">
            
            {/* Top Regional Operational Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-emerald-500/10 via-blue-500/10 to-amber-500/10 border border-slate-300/80 shadow-xs backdrop-blur-xs">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-600"></span>
              </span>
              <span className="text-xs font-black uppercase tracking-wider text-slate-800">
                INDUSTRIAL POWER &amp; BLOWER ENGINEERING SPECIALISTS
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[54px] font-black tracking-tight leading-[1.12] uppercase text-[#0B1E38]">
              POWERING HEAVY INDUSTRIES <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-[#185C20] via-emerald-600 to-teal-600 bg-clip-text text-transparent">
                WITH CERTIFIED ELECTRICAL SUPPLY &amp; SERVICES
              </span>
            </h1>

            {/* Subtext */}
            <p className="text-sm sm:text-base md:text-lg text-slate-600 font-medium leading-relaxed max-w-2xl">
              High-Vacuum Transformer Oil Filtration, Industrial Centrifugal Blowers, Switchgear &amp; Control Panels, and 24/7 Substation Maintenance — serving major manufacturing plants across 5 Eastern states.
            </p>

            {/* Regional 5-States Footprint Box with Vibrant Distinct State Badges */}
            <div className="relative bg-white/95 border-2 border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 max-w-2xl overflow-hidden group">
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-blue-500 via-amber-500 via-purple-500 to-rose-500" />
              
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2 font-black text-xs sm:text-sm text-[#0B1E38] uppercase tracking-wider">
                  <div className="p-2 rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-600/20">
                    <MapPin className="w-4 h-4 text-white animate-bounce" />
                  </div>
                  <span>5-STATE REGIONAL INDUSTRIAL NETWORK</span>
                </div>
                <span className="text-[11px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                  Eastern India Hub
                </span>
              </div>

              {/* 5 Distinct Vibrant State Pills */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wide">
                  Active On-Site Field Services &amp; Equipment Deliveries In:
                </p>
                <div className="flex flex-wrap items-center gap-2.5 pt-1 text-xs font-black">
                  
                  {/* Jharkhand - Sapphire Emerald */}
                  <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-50 to-teal-50 border-2 border-emerald-300 text-emerald-950 shadow-xs hover:scale-105 transition-transform cursor-default">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" />
                    <span>Jharkhand</span>
                    <span className="text-[10px] bg-emerald-600 text-white px-1.5 py-0.5 rounded-md font-extrabold">HQ</span>
                  </div>

                  {/* Odisha - Amber Gold */}
                  <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 text-amber-950 shadow-xs hover:scale-105 transition-transform cursor-default">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-600" />
                    <span>Odisha</span>
                  </div>

                  {/* Bihar - Royal Blue */}
                  <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-300 text-blue-950 shadow-xs hover:scale-105 transition-transform cursor-default">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                    <span>Bihar</span>
                  </div>

                  {/* Chhattisgarh - Crimson Red */}
                  <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-rose-50 to-red-50 border-2 border-rose-300 text-rose-950 shadow-xs hover:scale-105 transition-transform cursor-default">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                    <span>Chhattisgarh</span>
                  </div>

                  {/* West Bengal - Deep Purple */}
                  <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-50 to-fuchsia-50 border-2 border-purple-300 text-purple-950 shadow-xs hover:scale-105 transition-transform cursor-default">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-600" />
                    <span>West Bengal</span>
                  </div>

                </div>
              </div>

              {/* Location Note */}
              <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 pt-3 border-t border-slate-100 font-semibold">
                <div className="flex items-center gap-2 text-slate-800">
                  <Building2 className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>Headquartered in Jamshedpur Industrial Zone, Jharkhand</span>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-800 font-extrabold bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>24/7 Rapid Emergency Response</span>
                </div>
              </div>
            </div>

            {/* CTAs & Trust Metrics */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button 
                onClick={() => onOpenQuote()}
                className="bg-gradient-to-r from-[#185C20] via-emerald-700 to-green-700 hover:from-[#0D3F18] hover:to-emerald-800 text-white px-8 py-4 rounded-xl font-black text-xs sm:text-sm uppercase tracking-wider flex items-center gap-3 shadow-xl shadow-emerald-900/20 hover:shadow-2xl hover:-translate-y-0.5 transition-all duration-200 group border border-emerald-400/30"
              >
                <span>REQUEST IMMEDIATE QUOTE</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>

              <button 
                onClick={() => scrollToSection('services')}
                className="bg-white hover:bg-slate-50 text-[#0B1E38] border-2 border-slate-300 hover:border-[#185C20] px-7 py-3.5 rounded-xl font-extrabold text-xs sm:text-sm uppercase tracking-wider transition-all duration-200 flex items-center gap-2 shadow-xs"
              >
                <span>EXPLORE ALL SERVICES</span>
                <ArrowRight className="w-4 h-4 text-emerald-700" />
              </button>
            </div>

            {/* 4 Quick Stat Highlights */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 max-w-2xl">
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-black text-xs shrink-0">
                  5
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-black text-slate-800 uppercase">States</span>
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Covered</span>
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-black text-xs shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-black text-slate-800 uppercase">ISO</span>
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Certified</span>
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-black text-xs shrink-0">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-black text-slate-800 uppercase">24/7</span>
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Support</span>
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-rose-100 text-rose-800 flex items-center justify-center font-black text-xs shrink-0">
                  <ShieldCheck className="w-5 h-5 text-rose-600" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-black text-slate-800 uppercase">100%</span>
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Reliable</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Side Image Section */}
          <div className="block lg:col-span-6 relative mt-10 lg:mt-0">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-[6px] border-white z-10 group bg-[#185C20]">
              <div className="absolute inset-0 bg-gradient-to-tr from-[#0D3F18]/80 to-transparent z-10 mix-blend-multiply opacity-50 group-hover:opacity-20 transition-opacity duration-500"></div>
              <img 
                src={SITE_IMAGES.premiumFiltrationMachine} 
                alt="State-of-the-art Transformer Oil Filtration System by SRP Megha Power" 
                className="w-full h-[350px] sm:h-[450px] lg:h-[550px] xl:h-[650px] object-cover transform group-hover:scale-105 transition-transform duration-700 ease-in-out"
                referrerPolicy="no-referrer"
              />
              
              {/* Image Badge Overlay */}
              <div className="absolute bottom-6 left-6 z-20 flex flex-col gap-2">
                <div className="bg-white/95 backdrop-blur-sm rounded-lg px-4 py-2 border-l-4 border-emerald-500 shadow-lg inline-flex items-center gap-3">
                  <div className="p-1.5 bg-emerald-100 rounded-md">
                    <Droplet className="w-5 h-5 text-emerald-700" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-extrabold uppercase tracking-widest text-emerald-800">Advanced Series</span>
                    <span className="block text-sm font-black text-slate-900 tracking-tight">Transformer Oil Filtration</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative background blocks behind image */}
            <div className="absolute -top-6 -right-6 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl z-0"></div>
            <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl z-0"></div>
          </div>
        </div>

        {/* 3 Core Offerings Floating Banner (3 Cards Grid) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 pb-12">
          
          {/* Card 1: PRODUCT */}
          <div 
            onClick={() => handleCardClick('product', 'filtration')}
            className={`group relative bg-white rounded-2xl p-6 border-2 transition-all duration-300 flex flex-col justify-between cursor-pointer overflow-hidden
              ${activeCard === 'product' 
                ? 'border-blue-500 shadow-[0_0_40px_rgba(59,130,246,0.6)] scale-105 ring-4 ring-blue-500/30' 
                : 'border-slate-200 shadow-md hover:shadow-2xl hover:-translate-y-1.5 hover:border-blue-400 hover:bg-gradient-to-b hover:from-white hover:to-blue-50/40'
              }`}
          >
            <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-600 via-cyan-400 to-indigo-600 ${activeCard === 'product' ? 'animate-pulse' : ''}`} />
            
            {/* Active Glow Background */}
            <div className={`absolute -inset-1 bg-gradient-to-r from-blue-500 to-cyan-500 opacity-0 blur-2xl transition-opacity duration-300 pointer-events-none z-0 ${activeCard === 'product' ? 'opacity-20' : 'group-hover:opacity-10'}`}></div>

            <div className="space-y-4 relative z-10">
              <div className="flex items-start justify-between gap-3">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-900 to-blue-950 text-cyan-400 flex items-center justify-center shrink-0 shadow-lg shadow-blue-900/20 transition-transform duration-300 border border-cyan-400/30 ${activeCard === 'product' ? 'scale-110' : 'group-hover:scale-110'}`}>
                  <Package className={`w-7 h-7 fill-current text-cyan-400 ${activeCard === 'product' ? 'animate-pulse' : ''}`} />
                </div>
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider border shadow-2xs transition-colors ${activeCard === 'product' ? 'bg-blue-600 text-white border-blue-500' : 'bg-blue-100/80 text-blue-800 border-blue-200 group-hover:bg-blue-600 group-hover:text-white'}`}>
                  Equipment
                </span>
              </div>

              <div className="space-y-2 text-left">
                <h3 className={`font-black text-xl tracking-tight uppercase transition-colors ${activeCard === 'product' ? 'text-blue-700' : 'text-[#0B1E38] group-hover:text-blue-700'}`}>
                  PRODUCT
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  High-vacuum transformer oil purification plants, custom centrifugal blowers, and electrical panels.
                </p>
              </div>
            </div>

            <div className={`relative z-10 pt-4 mt-4 border-t flex items-center justify-between text-xs font-black transition-colors ${activeCard === 'product' ? 'border-blue-200 text-blue-800' : 'border-blue-100 text-blue-700 group-hover:text-blue-900'}`}>
              <span>Explore Products</span>
              <ArrowRight className={`w-4 h-4 transition-transform ${activeCard === 'product' ? 'translate-x-2 text-blue-600' : 'group-hover:translate-x-2 text-blue-600'}`} />
            </div>
          </div>

          {/* Card 2: SERVICE */}
          <div 
            onClick={() => handleCardClick('service', 'services')}
            className={`group relative bg-white rounded-2xl p-6 border-2 transition-all duration-300 flex flex-col justify-between cursor-pointer overflow-hidden
              ${activeCard === 'service' 
                ? 'border-emerald-500 shadow-[0_0_40px_rgba(16,185,129,0.6)] scale-105 ring-4 ring-emerald-500/30' 
                : 'border-slate-200 shadow-md hover:shadow-2xl hover:-translate-y-1.5 hover:border-emerald-400 hover:bg-gradient-to-b hover:from-white hover:to-emerald-50/40'
              }`}
          >
            <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-400 to-indigo-500 ${activeCard === 'service' ? 'animate-pulse' : ''}`} />
            
            {/* Active Glow Background */}
            <div className={`absolute -inset-1 bg-gradient-to-r from-emerald-500 to-teal-500 opacity-0 blur-2xl transition-opacity duration-300 pointer-events-none z-0 ${activeCard === 'service' ? 'opacity-20' : 'group-hover:opacity-10'}`}></div>

            <div className="space-y-4 relative z-10">
              <div className="flex items-start justify-between gap-3">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-900 to-emerald-950 text-emerald-400 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-900/20 transition-transform duration-300 border border-emerald-400/30 ${activeCard === 'service' ? 'scale-110' : 'group-hover:scale-110'}`}>
                  <Wrench className={`w-7 h-7 fill-current text-emerald-400 ${activeCard === 'service' ? 'animate-pulse' : ''}`} />
                </div>
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider border shadow-2xs transition-colors ${activeCard === 'service' ? 'bg-emerald-600 text-white border-emerald-500' : 'bg-emerald-100/80 text-emerald-900 border-emerald-200 group-hover:bg-emerald-600 group-hover:text-white'}`}>
                  On-Site
                </span>
              </div>

              <div className="space-y-2 text-left">
                <h3 className={`font-black text-xl tracking-tight uppercase transition-colors ${activeCard === 'service' ? 'text-emerald-700' : 'text-[#0B1E38] group-hover:text-emerald-700'}`}>
                  SERVICE
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  Comprehensive on-site oil filtration, transformer overhaul, and heavy-duty industrial equipment servicing.
                </p>
              </div>
            </div>

            <div className={`relative z-10 pt-4 mt-4 border-t flex items-center justify-between text-xs font-black transition-colors ${activeCard === 'service' ? 'border-emerald-200 text-emerald-800' : 'border-emerald-100 text-emerald-700 group-hover:text-emerald-900'}`}>
              <span>View Services</span>
              <ArrowRight className={`w-4 h-4 transition-transform ${activeCard === 'service' ? 'translate-x-2 text-emerald-600' : 'group-hover:translate-x-2 text-emerald-600'}`} />
            </div>
          </div>

          {/* Card 3: PLAN */}
          <div 
            onClick={() => handleCardClick('plan', 'contact')}
            className={`group relative bg-white rounded-2xl p-6 border-2 transition-all duration-300 flex flex-col justify-between cursor-pointer overflow-hidden
              ${activeCard === 'plan' 
                ? 'border-amber-500 shadow-[0_0_40px_rgba(245,158,11,0.6)] scale-105 ring-4 ring-amber-500/30' 
                : 'border-slate-200 shadow-md hover:shadow-2xl hover:-translate-y-1.5 hover:border-amber-400 hover:bg-gradient-to-b hover:from-white hover:to-amber-50/40'
              }`}
          >
            <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 ${activeCard === 'plan' ? 'animate-pulse' : ''}`} />
            
            {/* Active Glow Background */}
            <div className={`absolute -inset-1 bg-gradient-to-r from-amber-500 to-orange-500 opacity-0 blur-2xl transition-opacity duration-300 pointer-events-none z-0 ${activeCard === 'plan' ? 'opacity-20' : 'group-hover:opacity-10'}`}></div>

            <div className="space-y-4 relative z-10">
              <div className="flex items-start justify-between gap-3">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-900 to-amber-950 text-amber-400 flex items-center justify-center shrink-0 shadow-lg shadow-amber-900/20 transition-transform duration-300 border border-amber-400/30 ${activeCard === 'plan' ? 'scale-110' : 'group-hover:scale-110'}`}>
                  <FileSignature className={`w-7 h-7 text-amber-400 ${activeCard === 'plan' ? 'animate-pulse' : ''}`} />
                </div>
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider border shadow-2xs transition-colors ${activeCard === 'plan' ? 'bg-amber-600 text-white border-amber-500' : 'bg-amber-100/80 text-amber-900 border-amber-200 group-hover:bg-amber-600 group-hover:text-white'}`}>
                  Contracts
                </span>
              </div>

              <div className="space-y-2 text-left">
                <h3 className={`font-black text-xl tracking-tight uppercase transition-colors ${activeCard === 'plan' ? 'text-amber-700' : 'text-[#0B1E38] group-hover:text-amber-700'}`}>
                  PLAN
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  Annual Maintenance Contracts (AMC) ensuring zero downtime with regular sampling and 24/7 field support.
                </p>
              </div>
            </div>

            <div className={`relative z-10 pt-4 mt-4 border-t flex items-center justify-between text-xs font-black transition-colors ${activeCard === 'plan' ? 'border-amber-200 text-amber-800' : 'border-amber-100 text-amber-700 group-hover:text-amber-900'}`}>
              <span>Request AMC Details</span>
              <ArrowRight className={`w-4 h-4 transition-transform ${activeCard === 'plan' ? 'translate-x-2 text-amber-600' : 'group-hover:translate-x-2 text-amber-600'}`} />
            </div>
          </div>

        </div>

      </div>

      {/* Bottom 5 Value Feature Strip (Full Width Navy Bar) */}
      <div className="bg-[#0B1E38] text-white py-6 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 text-left">
            
            {/* Feature 1 */}
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">
                  QUALITY YOU CAN TRUST
                </h4>
                <p className="text-[11px] text-slate-300 mt-1 font-medium leading-snug">
                  Reliable quality with strict testing &amp; inspection.
                </p>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 shrink-0">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">
                  ADVANCED TECHNOLOGY
                </h4>
                <p className="text-[11px] text-slate-300 mt-1 font-medium leading-snug">
                  Modern equipment and latest technology.
                </p>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">
                  EXPERT TEAM
                </h4>
                <p className="text-[11px] text-slate-300 mt-1 font-medium leading-snug">
                  Experienced engineers &amp; technical professionals.
                </p>
              </div>
            </div>

            {/* Feature 4 */}
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">
                  24/7 SUPPORT
                </h4>
                <p className="text-[11px] text-slate-300 mt-1 font-medium leading-snug">
                  24/7 technical support and quick response.
                </p>
              </div>
            </div>

            {/* Feature 5 */}
            <div className="col-span-2 md:col-span-1 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 shrink-0">
                <Trophy className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-white">
                  CUSTOMER SATISFACTION
                </h4>
                <p className="text-[11px] text-slate-300 mt-1 font-medium leading-snug">
                  Commitment to safety, reliability &amp; excellence.
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>

    </section>
  );
};
