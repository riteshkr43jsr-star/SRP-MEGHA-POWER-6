import React from 'react';
import { Calendar, Award, Gauge, Headphones } from 'lucide-react';

export const TrustStats: React.FC = () => {
  const stats = [
    {
      value: '10+',
      label: 'Years of Experience',
      subtext: 'Serving Industrial Giants',
      icon: Calendar
    },
    {
      value: '500+',
      label: 'Projects Completed',
      subtext: 'Across Steel, Power & Mining',
      icon: Award
    },
    {
      value: '10,000 LPH',
      label: 'Max Filtration Capacity',
      subtext: 'High-Vacuum Double Stage Plant',
      icon: Gauge
    },
    {
      value: '24/7',
      label: 'Industrial Field Support',
      subtext: 'Rapid Emergency Response',
      icon: Headphones
    }
  ];

  return (
    <section className="bg-white py-8 border-b border-[#DDE5DC] shadow-xs relative z-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 divide-y md:divide-y-0 md:divide-x divide-[#DDE5DC]">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div key={idx} className={`flex items-center gap-4 ${idx > 0 ? 'pt-4 md:pt-0 md:pl-6' : ''}`}>
                <div className="w-12 h-12 rounded-xl bg-[#EAF4E6] text-[#185C20] flex items-center justify-center shrink-0 border border-[#4D9B2A]/30">
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black text-[#101A24] tracking-tight leading-none">
                    {stat.value}
                  </div>
                  <div className="text-xs font-bold text-[#185C20] mt-1">
                    {stat.label}
                  </div>
                  <div className="text-[11px] text-gray-500 font-medium hidden sm:block">
                    {stat.subtext}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
