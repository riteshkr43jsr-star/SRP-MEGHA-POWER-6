import React, { useState } from 'react';
import { Search, X, Droplet, Wind, ArrowRight, Eye } from 'lucide-react';
import { FILTRATION_PRODUCTS, CENTRIFUGAL_BLOWERS, SERVICES } from '../data/companyData';
import { ProductItem } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: ProductItem) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onSelectProduct }) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const filteredFiltration = FILTRATION_PRODUCTS.filter(p => 
    p.name.toLowerCase().includes(query.toLowerCase()) || 
    p.shortDesc.toLowerCase().includes(query.toLowerCase())
  );

  const filteredBlowers = CENTRIFUGAL_BLOWERS.filter(b => 
    b.name.toLowerCase().includes(query.toLowerCase()) || 
    b.shortDesc.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-[100] bg-black/75 backdrop-blur-xs flex items-start justify-center pt-20 p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative border border-[#DDE5DC] text-left space-y-4 max-h-[80vh] overflow-y-auto">
        
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div className="flex items-center gap-2 text-[#185C20] font-bold text-sm uppercase">
            <Search className="w-5 h-5 text-[#4D9B2A]" />
            Search Products & Services
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-100">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Input */}
        <div className="relative">
          <input 
            type="text" 
            autoFocus
            placeholder="Type e.g. 10,000 LPH, 6,000 LPH, Backward Curved, Boiler Fan, Portable Oil..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-[#F7F9F6] border-2 border-[#185C20]/30 rounded-xl p-3.5 pl-10 text-sm font-semibold text-[#101A24] focus:outline-none focus:border-[#185C20]"
          />
          <Search className="w-5 h-5 text-gray-400 absolute left-3 top-3.5" />
        </div>

        {/* Results */}
        <div className="max-h-80 overflow-y-auto space-y-4 pr-1">
          {filteredFiltration.length > 0 && (
            <div>
              <span className="text-[10px] font-bold text-[#185C20] uppercase tracking-wider block mb-2">
                Oil Filtration Machines ({filteredFiltration.length})
              </span>
              <div className="space-y-1.5">
                {filteredFiltration.map((item) => (
                  <div 
                    key={item.id}
                    onClick={() => {
                      onClose();
                      onSelectProduct(item);
                    }}
                    className="p-3 bg-[#F7F9F6] hover:bg-[#EAF4E6] rounded-lg border border-[#DDE5DC] cursor-pointer flex justify-between items-center group transition-colors"
                  >
                    <div>
                      <h4 className="font-bold text-xs text-[#101A24] group-hover:text-[#185C20]">
                        {item.name}
                      </h4>
                      <p className="text-[11px] text-gray-500">{item.capacity}</p>
                    </div>
                    <Eye className="w-4 h-4 text-gray-400 group-hover:text-[#185C20]" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {filteredBlowers.length > 0 && (
            <div>
              <span className="text-[10px] font-bold text-[#185C20] uppercase tracking-wider block mb-2">
                Centrifugal Blowers ({filteredBlowers.length})
              </span>
              <div className="space-y-1.5">
                {filteredBlowers.map((blower) => (
                  <div 
                    key={blower.id}
                    onClick={() => {
                      onClose();
                      onSelectProduct(blower);
                    }}
                    className="p-3 bg-[#F7F9F6] hover:bg-[#EAF4E6] rounded-lg border border-[#DDE5DC] cursor-pointer flex justify-between items-center group transition-colors"
                  >
                    <div>
                      <h4 className="font-bold text-xs text-[#101A24] group-hover:text-[#185C20]">
                        {blower.name}
                      </h4>
                      <p className="text-[11px] text-gray-500">{blower.subcategory || 'Centrifugal Blower'}</p>
                    </div>
                    <Eye className="w-4 h-4 text-gray-400 group-hover:text-[#185C20]" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {filteredFiltration.length === 0 && filteredBlowers.length === 0 && (
            <div className="text-center py-8 text-xs text-gray-500">
              No matching products found. Try searching "10,000 LPH", "Blower", or "Oil".
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
