import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  ChevronDown, 
  Menu, 
  X, 
  Search, 
  ArrowRight, 
  Zap, 
  CheckCircle2, 
  Droplet, 
  Wind,
  ShieldCheck
} from 'lucide-react';
import { COMPANY_DETAILS } from '../data/companyData';
import { CompanyLogo } from './CompanyLogo';

interface HeaderProps {
  onOpenQuote: (productOrService?: string) => void;
  onSearchOpen: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenQuote, onSearchOpen }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [productsDropdownOpen, setProductsDropdownOpen] = useState(false);
  const [mobileProductsOpen, setMobileProductsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    setProductsDropdownOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full transition-all duration-300">
      {/* Top Info Bar */}
      <div className="bg-[#0B1E38] text-white text-xs py-2 px-4 border-b border-slate-700/60 hidden md:block">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 font-medium">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-[#4D9B2A]" />
              {COMPANY_DETAILS.location}
            </span>
            <a href={`tel:${COMPANY_DETAILS.phonePrimary}`} className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors">
              <Phone className="w-3.5 h-3.5 text-[#4D9B2A]" />
              {COMPANY_DETAILS.phonePrimary}
            </a>
            <a href={`mailto:${COMPANY_DETAILS.email}`} className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors">
              <Mail className="w-3.5 h-3.5 text-[#4D9B2A]" />
              {COMPANY_DETAILS.email}
            </a>
          </div>

        </div>
      </div>

      {/* Main Navbar */}
      <div className={`bg-white transition-all duration-200 ${isScrolled ? 'shadow-md py-3' : 'py-4 border-b border-[#DDE5DC]'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Logo Section */}
          <a href="#" className="flex items-center gap-3 focus:outline-none">
            <CompanyLogo variant="light" size="md" />
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1.5 text-[13px] font-bold text-[#101A24]">
            <button 
              onClick={() => scrollToSection('home')} 
              className="px-4 py-2 rounded-full hover:bg-gradient-to-r hover:from-blue-50 hover:to-indigo-50 hover:text-blue-700 border border-transparent hover:border-blue-200 hover:shadow-sm transition-all duration-300"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')} 
              className="px-4 py-2 rounded-full hover:bg-gradient-to-r hover:from-teal-50 hover:to-emerald-50 hover:text-emerald-700 border border-transparent hover:border-emerald-200 hover:shadow-sm transition-all duration-300"
            >
              About Us
            </button>
            <button 
              onClick={() => scrollToSection('services')} 
              className="px-4 py-2 rounded-full hover:bg-gradient-to-r hover:from-purple-50 hover:to-fuchsia-50 hover:text-purple-700 border border-transparent hover:border-purple-200 hover:shadow-sm transition-all duration-300"
            >
              Services
            </button>

            {/* Products Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setProductsDropdownOpen(true)}
              onMouseLeave={() => setProductsDropdownOpen(false)}
            >
              <button 
                onClick={() => scrollToSection('products')}
                className={`flex items-center gap-1 px-4 py-2 rounded-full border transition-all duration-300 ${
                  productsDropdownOpen 
                    ? 'bg-gradient-to-r from-orange-50 to-amber-50 text-orange-700 border-orange-200 shadow-sm' 
                    : 'hover:bg-gradient-to-r hover:from-orange-50 hover:to-amber-50 hover:text-orange-700 border-transparent hover:border-orange-200 hover:shadow-sm'
                }`}
              >
                Products
                <ChevronDown className={`w-4 h-4 transition-transform ${productsDropdownOpen ? 'rotate-180 text-orange-600' : 'text-gray-400'}`} />
              </button>

              {/* Mega Dropdown Menu */}
              {productsDropdownOpen && (
                <div className="absolute top-full -left-20 w-[640px] bg-white rounded-xl shadow-2xl border border-[#DDE5DC] p-5 grid grid-cols-2 gap-6 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  
                  {/* Category A: Filtration Machines */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 pb-2 border-b border-[#DDE5DC] text-[#185C20] font-bold text-xs uppercase tracking-wider">
                      <Droplet className="w-4 h-4 text-[#4D9B2A]" />
                      Transformer Oil Filtration
                    </div>
                    <ul className="space-y-1.5 text-xs text-gray-700">
                      <li>
                        <button 
                          onClick={() => scrollToSection('filtration-10000')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition flex justify-between items-center group"
                        >
                          <span className="font-bold text-[#185C20]">10,000 LPH Machine</span>
                          <span className="text-[10px] bg-[#185C20] text-white px-1.5 py-0.5 rounded font-black">Max Cap</span>
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('filtration-6000')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition flex justify-between items-center group"
                        >
                          <span>6,000 LPH Machine</span>
                          <span className="text-[10px] bg-[#185C20]/10 text-[#185C20] px-1.5 py-0.5 rounded font-semibold">High Cap</span>
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('filtration-5000')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition flex justify-between items-center"
                        >
                          <span>5,000 LPH Machine</span>
                          <span className="text-[10px] text-gray-500">Substations</span>
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('filtration-3000')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition"
                        >
                          3,000 LPH Machine
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('filtration-1000')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition"
                        >
                          1,000 LPH Machine
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('filtration-portable')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition flex justify-between items-center"
                        >
                          <span>Portable Oil Units</span>
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1 py-0.5 rounded">Mobile</span>
                        </button>
                      </li>
                    </ul>
                  </div>

                  {/* Category B: Centrifugal Blowers */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 pb-2 border-b border-[#DDE5DC] text-[#185C20] font-bold text-xs uppercase tracking-wider">
                      <Wind className="w-4 h-4 text-[#4D9B2A]" />
                      Centrifugal Blowers Range
                    </div>
                    <ul className="space-y-1.5 text-xs text-gray-700">
                      <li>
                        <button 
                          onClick={() => scrollToSection('blowers')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition"
                        >
                          Backward / Forward Curved Blowers
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('blowers')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition"
                        >
                          High Pressure & Industrial Process Fans
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('blowers')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition"
                        >
                          Boiler ID / FD & Exhaust Blowers
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('blowers')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition"
                        >
                          Corrosion Resistant FRP / SS Fans
                        </button>
                      </li>
                      <li>
                        <button 
                          onClick={() => scrollToSection('blowers')}
                          className="w-full text-left p-1.5 rounded hover:bg-[#EAF4E6] hover:text-[#185C20] font-medium transition font-semibold text-[#185C20] flex items-center gap-1"
                        >
                          <span>View All 16 Blower Types</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </li>
                    </ul>
                  </div>

                </div>
              )}
            </div>

            <button 
              onClick={() => scrollToSection('clients')} 
              className="px-4 py-2 rounded-full hover:bg-gradient-to-r hover:from-rose-50 hover:to-red-50 hover:text-rose-700 border border-transparent hover:border-rose-200 hover:shadow-sm transition-all duration-300"
            >
              Our Clients
            </button>
            <button 
              onClick={() => scrollToSection('industries')} 
              className="px-4 py-2 rounded-full hover:bg-gradient-to-r hover:from-cyan-50 hover:to-sky-50 hover:text-cyan-700 border border-transparent hover:border-cyan-200 hover:shadow-sm transition-all duration-300"
            >
              Industries
            </button>
            <button 
              onClick={() => scrollToSection('contact')} 
              className="px-4 py-2 rounded-full hover:bg-gradient-to-r hover:from-amber-50 hover:to-yellow-50 hover:text-amber-700 border border-transparent hover:border-amber-200 hover:shadow-sm transition-all duration-300"
            >
              Contact Us
            </button>
          </nav>

          {/* Right Action Area */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Quick Search Button */}
            <button 
              onClick={onSearchOpen}
              className="p-2.5 text-gray-600 hover:text-[#185C20] hover:bg-[#EAF4E6] rounded-lg transition-colors border border-transparent hover:border-[#DDE5DC]"
              title="Search products and services"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* GET A QUOTE CTA Button */}
            <button 
              onClick={() => onOpenQuote()}
              className="bg-[#185C20] hover:bg-[#0D3F18] text-white px-5 py-2.5 rounded-lg font-bold text-xs tracking-wider uppercase flex items-center gap-2 transition-all duration-200 shadow-sm hover:shadow-md hover:translate-y-[-1px] group"
            >
              <span>GET A QUOTE</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button 
              onClick={onSearchOpen}
              className="p-2 text-gray-700 hover:text-[#185C20] rounded-md"
            >
              <Search className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-[#EAF4E6] text-[#185C20] hover:bg-[#185C20] hover:text-white transition-colors"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-[#DDE5DC] shadow-xl px-4 pt-3 pb-6 space-y-3 animate-in fade-in slide-in-from-top-3">
          <div className="space-y-1 text-sm font-semibold text-[#101A24]">
            <button 
              onClick={() => scrollToSection('home')} 
              className="w-full text-left px-3 py-2.5 rounded-md hover:bg-[#EAF4E6] hover:text-[#185C20]"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')} 
              className="w-full text-left px-3 py-2.5 rounded-md hover:bg-[#EAF4E6] hover:text-[#185C20]"
            >
              About Us
            </button>
            <button 
              onClick={() => scrollToSection('services')} 
              className="w-full text-left px-3 py-2.5 rounded-md hover:bg-[#EAF4E6] hover:text-[#185C20]"
            >
              Services
            </button>

            {/* Mobile Products Accordion */}
            <div className="border-y border-gray-100 my-1 py-1">
              <button 
                onClick={() => setMobileProductsOpen(!mobileProductsOpen)}
                className="w-full flex justify-between items-center px-3 py-2.5 text-left rounded-md hover:bg-[#EAF4E6] hover:text-[#185C20]"
              >
                <span>Products Catalog</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${mobileProductsOpen ? 'rotate-180' : ''}`} />
              </button>

              {mobileProductsOpen && (
                <div className="pl-4 pr-2 py-2 bg-[#F7F9F6] rounded-lg my-1 space-y-2 text-xs">
                  <div className="font-bold text-[#185C20] uppercase tracking-wider text-[11px] pt-1">
                    Oil Filtration Machines
                  </div>
                  <button onClick={() => scrollToSection('filtration-10000')} className="block w-full text-left py-1 text-[#185C20] font-black flex items-center justify-between">
                    <span>10,000 LPH Filtration Machine</span>
                    <span className="text-[9px] bg-[#185C20] text-white px-1.5 py-0.2 rounded font-black">Max Cap</span>
                  </button>
                  <button onClick={() => scrollToSection('filtration-6000')} className="block w-full text-left py-1 text-gray-700 hover:text-[#185C20]">
                    6,000 LPH Filtration Machine
                  </button>
                  <button onClick={() => scrollToSection('filtration-5000')} className="block w-full text-left py-1 text-gray-700 hover:text-[#185C20]">
                    5,000 LPH Filtration Machine
                  </button>
                  <button onClick={() => scrollToSection('filtration-3000')} className="block w-full text-left py-1 text-gray-700 hover:text-[#185C20]">
                    3,000 LPH & 1,000 LPH Machines
                  </button>
                  <button onClick={() => scrollToSection('filtration-portable')} className="block w-full text-left py-1 text-gray-700 hover:text-[#185C20]">
                    Portable Oil Units
                  </button>

                  <div className="font-bold text-[#185C20] uppercase tracking-wider text-[11px] pt-2 border-t border-gray-200">
                    Centrifugal Blowers
                  </div>
                  <button onClick={() => scrollToSection('blowers')} className="block w-full text-left py-1 text-gray-700 hover:text-[#185C20]">
                    Complete 16 Blower Range
                  </button>
                </div>
              )}
            </div>

            <button 
              onClick={() => scrollToSection('clients')} 
              className="w-full text-left px-3 py-2.5 rounded-md hover:bg-[#EAF4E6] hover:text-[#185C20]"
            >
              Our Clients
            </button>
            <button 
              onClick={() => scrollToSection('industries')} 
              className="w-full text-left px-3 py-2.5 rounded-md hover:bg-[#EAF4E6] hover:text-[#185C20]"
            >
              Industries
            </button>
            <button 
              onClick={() => scrollToSection('contact')} 
              className="w-full text-left px-3 py-2.5 rounded-md hover:bg-[#EAF4E6] hover:text-[#185C20]"
            >
              Contact Us
            </button>
          </div>

          <div className="pt-2 border-t border-gray-100 flex flex-col gap-2">
            <button 
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenQuote();
              }}
              className="w-full bg-[#185C20] hover:bg-[#0D3F18] text-white py-3 rounded-lg font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm"
            >
              <span>GET A QUOTE NOW</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="text-center text-xs text-gray-500 pt-1">
              📞 Emergency Support: <a href={`tel:${COMPANY_DETAILS.phonePrimary}`} className="font-bold text-[#185C20]">{COMPANY_DETAILS.phonePrimary}</a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
