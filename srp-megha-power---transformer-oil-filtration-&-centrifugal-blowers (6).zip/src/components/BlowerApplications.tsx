import React, { useState } from 'react';
import { 
  Factory, 
  Pickaxe, 
  Building2, 
  Zap, 
  FlaskRound, 
  Cog, 
  Flame, 
  Wind,
  ArrowRight,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { BLOWER_APPLICATIONS } from '../data/companyData';
import { BlowerApplication } from '../types';

interface BlowerApplicationsProps {
  onOpenQuote: (applicationTitle: string) => void;
}

interface ApplicationTheme {
  borderHover: string;
  borderActive: string;
  bgGradient: string;
  iconBgActive: string;
  iconColorActive: string;
  tagBg: string;
  tagText: string;
  tagBorder: string;
  pillBg: string;
  pillText: string;
  pillBorder: string;
  btnBgActive: string;
  btnTextActive: string;
  btnHoverActive: string;
  titleColorActive: string;
}

// 8 Unique Color Themes - No two applications share the same color identity!
const THEMES: Record<string, ApplicationTheme> = {
  'app-steel': {
    borderHover: 'hover:border-orange-500 hover:shadow-orange-500/15',
    borderActive: 'border-orange-500 shadow-xl shadow-orange-500/20 ring-2 ring-orange-500/60 -translate-y-2',
    bgGradient: 'bg-gradient-to-br from-orange-50/90 via-amber-50/50 to-orange-100/60',
    iconBgActive: 'bg-orange-500',
    iconColorActive: 'text-white',
    tagBg: 'bg-orange-100',
    tagText: 'text-orange-950 font-extrabold',
    tagBorder: 'border-orange-300',
    pillBg: 'bg-orange-100/80',
    pillText: 'text-orange-900',
    pillBorder: 'border-orange-200',
    btnBgActive: 'bg-gradient-to-r from-orange-600 to-amber-600 border-orange-600',
    btnTextActive: 'text-white',
    btnHoverActive: 'hover:from-orange-500 hover:to-amber-500',
    titleColorActive: 'text-orange-950',
  },
  'app-mining': {
    borderHover: 'hover:border-amber-500 hover:shadow-amber-500/15',
    borderActive: 'border-amber-500 shadow-xl shadow-amber-500/20 ring-2 ring-amber-500/60 -translate-y-2',
    bgGradient: 'bg-gradient-to-br from-amber-50/90 via-yellow-50/50 to-amber-100/60',
    iconBgActive: 'bg-amber-500',
    iconColorActive: 'text-black',
    tagBg: 'bg-amber-100',
    tagText: 'text-amber-950 font-extrabold',
    tagBorder: 'border-amber-300',
    pillBg: 'bg-amber-100/80',
    pillText: 'text-amber-900',
    pillBorder: 'border-amber-200',
    btnBgActive: 'bg-gradient-to-r from-amber-500 to-yellow-500 border-amber-500',
    btnTextActive: 'text-black font-extrabold',
    btnHoverActive: 'hover:from-amber-400 hover:to-yellow-400',
    titleColorActive: 'text-amber-950',
  },
  'app-cement': {
    borderHover: 'hover:border-slate-500 hover:shadow-slate-500/15',
    borderActive: 'border-slate-600 shadow-xl shadow-slate-500/20 ring-2 ring-slate-500/60 -translate-y-2',
    bgGradient: 'bg-gradient-to-br from-slate-100/90 via-gray-50/50 to-slate-200/60',
    iconBgActive: 'bg-slate-700',
    iconColorActive: 'text-white',
    tagBg: 'bg-slate-200',
    tagText: 'text-slate-900 font-extrabold',
    tagBorder: 'border-slate-400',
    pillBg: 'bg-slate-200/80',
    pillText: 'text-slate-900',
    pillBorder: 'border-slate-300',
    btnBgActive: 'bg-gradient-to-r from-slate-700 to-gray-800 border-slate-700',
    btnTextActive: 'text-white',
    btnHoverActive: 'hover:from-slate-600 hover:to-gray-700',
    titleColorActive: 'text-slate-950',
  },
  'app-power': {
    borderHover: 'hover:border-blue-500 hover:shadow-blue-500/15',
    borderActive: 'border-blue-500 shadow-xl shadow-blue-500/20 ring-2 ring-blue-500/60 -translate-y-2',
    bgGradient: 'bg-gradient-to-br from-blue-50/90 via-indigo-50/50 to-blue-100/60',
    iconBgActive: 'bg-blue-600',
    iconColorActive: 'text-white',
    tagBg: 'bg-blue-100',
    tagText: 'text-blue-950 font-extrabold',
    tagBorder: 'border-blue-300',
    pillBg: 'bg-blue-100/80',
    pillText: 'text-blue-900',
    pillBorder: 'border-blue-200',
    btnBgActive: 'bg-gradient-to-r from-blue-600 to-indigo-600 border-blue-600',
    btnTextActive: 'text-white',
    btnHoverActive: 'hover:from-blue-500 hover:to-indigo-500',
    titleColorActive: 'text-blue-950',
  },
  'app-chemical': {
    borderHover: 'hover:border-purple-500 hover:shadow-purple-500/15',
    borderActive: 'border-purple-500 shadow-xl shadow-purple-500/20 ring-2 ring-purple-500/60 -translate-y-2',
    bgGradient: 'bg-gradient-to-br from-purple-50/90 via-fuchsia-50/50 to-purple-100/60',
    iconBgActive: 'bg-purple-600',
    iconColorActive: 'text-white',
    tagBg: 'bg-purple-100',
    tagText: 'text-purple-950 font-extrabold',
    tagBorder: 'border-purple-300',
    pillBg: 'bg-purple-100/80',
    pillText: 'text-purple-900',
    pillBorder: 'border-purple-200',
    btnBgActive: 'bg-gradient-to-r from-purple-600 to-fuchsia-600 border-purple-600',
    btnTextActive: 'text-white',
    btnHoverActive: 'hover:from-purple-500 hover:to-fuchsia-500',
    titleColorActive: 'text-purple-950',
  },
  'app-manufacturing': {
    borderHover: 'hover:border-emerald-500 hover:shadow-emerald-500/15',
    borderActive: 'border-emerald-500 shadow-xl shadow-emerald-500/20 ring-2 ring-emerald-500/60 -translate-y-2',
    bgGradient: 'bg-gradient-to-br from-emerald-50/90 via-teal-50/50 to-emerald-100/60',
    iconBgActive: 'bg-[#185C20]',
    iconColorActive: 'text-white',
    tagBg: 'bg-emerald-100',
    tagText: 'text-emerald-950 font-extrabold',
    tagBorder: 'border-emerald-300',
    pillBg: 'bg-emerald-100/80',
    pillText: 'text-emerald-900',
    pillBorder: 'border-emerald-200',
    btnBgActive: 'bg-gradient-to-r from-[#185C20] to-emerald-700 border-[#185C20]',
    btnTextActive: 'text-white',
    btnHoverActive: 'hover:from-emerald-700 hover:to-teal-700',
    titleColorActive: 'text-[#101820]',
  },
  'app-ovens': {
    borderHover: 'hover:border-rose-500 hover:shadow-rose-500/15',
    borderActive: 'border-rose-500 shadow-xl shadow-rose-500/20 ring-2 ring-rose-500/60 -translate-y-2',
    bgGradient: 'bg-gradient-to-br from-rose-50/90 via-red-50/50 to-orange-100/60',
    iconBgActive: 'bg-rose-600',
    iconColorActive: 'text-white',
    tagBg: 'bg-rose-100',
    tagText: 'text-rose-950 font-extrabold',
    tagBorder: 'border-rose-300',
    pillBg: 'bg-rose-100/80',
    pillText: 'text-rose-900',
    pillBorder: 'border-rose-200',
    btnBgActive: 'bg-gradient-to-r from-rose-600 to-red-600 border-rose-600',
    btnTextActive: 'text-white',
    btnHoverActive: 'hover:from-rose-500 hover:to-red-500',
    titleColorActive: 'text-rose-950',
  },
  'app-scrubbers': {
    borderHover: 'hover:border-teal-500 hover:shadow-teal-500/15',
    borderActive: 'border-teal-500 shadow-xl shadow-teal-500/20 ring-2 ring-teal-500/60 -translate-y-2',
    bgGradient: 'bg-gradient-to-br from-teal-50/90 via-cyan-50/50 to-teal-100/60',
    iconBgActive: 'bg-teal-600',
    iconColorActive: 'text-white',
    tagBg: 'bg-teal-100',
    tagText: 'text-teal-950 font-extrabold',
    tagBorder: 'border-teal-300',
    pillBg: 'bg-teal-100/80',
    pillText: 'text-teal-900',
    pillBorder: 'border-teal-200',
    btnBgActive: 'bg-gradient-to-r from-teal-600 to-cyan-600 border-teal-600',
    btnTextActive: 'text-white',
    btnHoverActive: 'hover:from-teal-500 hover:to-cyan-500',
    titleColorActive: 'text-teal-950',
  }
};

export const BlowerApplications: React.FC<BlowerApplicationsProps> = ({ onOpenQuote }) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'steel' | 'mining'>('all');
  const [hoveredCardId, setHoveredCardId] = useState<string | null>(null);

  const renderApplicationIcon = (iconName: string, theme: ApplicationTheme, isActive: boolean) => {
    const iconClass = `w-5 h-5 transition-colors ${isActive ? theme.iconColorActive : 'text-[#185C20]'}`;
    switch (iconName) {
      case 'Factory':
        return <Factory className={iconClass} />;
      case 'Pickaxe':
      case 'Mountain':
        return <Pickaxe className={iconClass} />;
      case 'Building2':
        return <Building2 className={iconClass} />;
      case 'Zap':
        return <Zap className={iconClass} />;
      case 'FlaskRound':
        return <FlaskRound className={iconClass} />;
      case 'Cog':
        return <Cog className={iconClass} />;
      case 'Flame':
        return <Flame className={iconClass} />;
      case 'Wind':
      default:
        return <Wind className={iconClass} />;
    }
  };

  return (
    <section id="applications" className="py-16 bg-[#F4F7F4] text-gray-900 border-b border-gray-200 relative overflow-hidden">
      {/* Background Subtle Accent Glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-[#185C20] font-black text-xs uppercase tracking-wider border border-emerald-300">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>WHERE OUR BLOWERS OPERATE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-[#101820] uppercase">
            INDUSTRIAL BLOWER APPLICATIONS
          </h2>
          <p className="text-sm sm:text-base text-gray-600 leading-relaxed font-normal">
            Engineered to endure severe continuous duty cycles, high gas temperatures, corrosive atmospheres, and abrasive dust loading in heavy plant environments.
          </p>

          {/* Filter Toggle Bar */}
          <div className="flex items-center justify-center gap-3 pt-2 flex-wrap">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-200 border flex items-center gap-2 cursor-pointer ${
                activeFilter === 'all'
                  ? 'bg-[#185C20] text-white border-[#185C20] shadow-md scale-102'
                  : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400 hover:bg-gray-50'
              }`}
            >
              <span>All 8 Applications</span>
            </button>

            <button
              onClick={() => setActiveFilter('steel')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all duration-300 border flex items-center gap-2 cursor-pointer ${
                activeFilter === 'steel'
                  ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white border-orange-600 shadow-lg shadow-orange-500/25 scale-105 ring-2 ring-orange-400/50'
                  : 'bg-orange-50 text-orange-950 border-orange-300 hover:border-orange-500 hover:bg-orange-100/80'
              }`}
            >
              <Factory className="w-4 h-4 text-orange-600 shrink-0" />
              <span>🔥 Steel Plant Focus</span>
            </button>

            <button
              onClick={() => setActiveFilter('mining')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all duration-300 border flex items-center gap-2 cursor-pointer ${
                activeFilter === 'mining'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-black border-amber-400 shadow-lg shadow-amber-500/25 scale-105 ring-2 ring-amber-400/60'
                  : 'bg-amber-50 text-amber-950 border-amber-300 hover:border-amber-500 hover:bg-amber-100/80'
              }`}
            >
              <Pickaxe className="w-4 h-4 text-amber-700 shrink-0" />
              <span>⛏️ Mining Plant Focus</span>
            </button>
          </div>
        </div>

        {/* 8 Applications Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {BLOWER_APPLICATIONS.map((app: BlowerApplication) => {
            const appId = app.id || 'app-steel';
            const theme = THEMES[appId] || THEMES['app-steel'];

            // STRICT HIGHLIGHT LOGIC:
            // Highlighting happens ONLY if:
            // 1. User is hovering directly on THIS exact card (hoveredCardId === app.id)
            // 2. OR user explicitly selected a filter matching this app ('steel' for steel, 'mining' for mining)
            const isHovered = hoveredCardId === app.id;
            const isFilterActive = (activeFilter === 'steel' && app.highlightType === 'steel') || 
                                   (activeFilter === 'mining' && app.highlightType === 'mining');
            
            // Is ONLY this item highlighted right now?
            const isHighlighted = isHovered || isFilterActive;

            return (
              <div 
                key={appId}
                onMouseEnter={() => setHoveredCardId(app.id || null)}
                onMouseLeave={() => setHoveredCardId(null)}
                className={`rounded-2xl border transition-all duration-300 p-5 flex flex-col justify-between relative group cursor-pointer overflow-hidden ${
                  isHighlighted
                    ? `${theme.bgGradient} ${theme.borderActive}`
                    : `bg-white border-gray-200/90 ${theme.borderHover} hover:-translate-y-1`
                }`}
              >
                <div>
                  {/* Card Top Row: Icon & Tag */}
                  <div className="flex items-center justify-between mb-4 relative z-10">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all duration-300 shadow-xs ${
                      isHighlighted
                        ? `${theme.iconBgActive} shadow-md scale-105`
                        : 'bg-emerald-50 border border-emerald-200 group-hover:bg-[#185C20] group-hover:text-white'
                    }`}>
                      {renderApplicationIcon(app.icon, theme, isHighlighted)}
                    </div>

                    <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full border transition-colors ${
                      isHighlighted
                        ? `${theme.tagBg} ${theme.tagText} ${theme.tagBorder} shadow-2xs`
                        : 'bg-gray-100 text-gray-700 border-gray-200'
                    }`}>
                      {app.bgTag}
                    </span>
                  </div>

                  {/* Title & Subtitle */}
                  <div className="mb-2 relative z-10">
                    <h3 className={`font-black text-base sm:text-lg tracking-tight uppercase transition-colors ${
                      isHighlighted
                        ? theme.titleColorActive
                        : 'text-[#101820] group-hover:text-[#185C20]'
                    }`}>
                      {app.title}
                    </h3>
                    {app.subtitle && (
                      <span className="text-[11px] font-bold text-gray-500 block mt-0.5">
                        {app.subtitle}
                      </span>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-xs text-gray-600 leading-relaxed font-medium mb-4 relative z-10">
                    {app.description}
                  </p>

                  {/* Key Equipment Pills */}
                  {app.keyEquipment && app.keyEquipment.length > 0 && (
                    <div className="space-y-1.5 mb-4 pt-3 border-t border-gray-200/80 relative z-10">
                      <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider block">
                        Key Applications:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {app.keyEquipment.map((eq, eIdx) => (
                          <span 
                            key={eIdx}
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md border transition-colors ${
                              isHighlighted
                                ? `${theme.pillBg} ${theme.pillText} ${theme.pillBorder}`
                                : 'bg-gray-100 text-gray-700 border-gray-200'
                            }`}
                          >
                            {eq}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom CTA Button */}
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenQuote(`Blower Application for ${app.title}`);
                  }}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-between transition-all duration-200 cursor-pointer border relative z-10 ${
                    isHighlighted
                      ? `${theme.btnBgActive} ${theme.btnTextActive} ${theme.btnHoverActive} shadow-md`
                      : 'bg-gray-50 hover:bg-[#185C20] text-[#185C20] hover:text-white border-gray-200 hover:border-[#185C20]'
                  }`}
                >
                  <span>Inquire for {app.title.split(' ')[0]}</span>
                  <ArrowRight className="w-4 h-4 shrink-0 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Highlight Banner Notice */}
        <div className="mt-10 p-4 rounded-2xl bg-amber-50/90 border border-amber-200 flex flex-wrap items-center justify-between gap-4 text-xs text-amber-950 shadow-xs">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0" />
            <p className="font-medium leading-relaxed">
              <strong className="text-amber-900 uppercase font-black">Custom Industrial Engineering: </strong> 
              Blowers are custom-sized for CFM/CMH, gas composition, process temperature, and static pressure for Steel Mills, Mining Facilities, Power Utilities & Heavy Process Lines.
            </p>
          </div>
          <button
            onClick={() => onOpenQuote('Custom Industrial Blower Application Design')}
            className="bg-[#185C20] hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl transition-all shadow-md shrink-0 cursor-pointer"
          >
            GET CUSTOM SELECTION →
          </button>
        </div>

      </div>
    </section>
  );
};

