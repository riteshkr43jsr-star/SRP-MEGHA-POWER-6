import React from 'react';
import { COMPANY_DETAILS } from '../data/companyData';
import { ShieldCheck, CheckCircle2, Award, Zap, ArrowRight, Building, Wrench } from 'lucide-react';

interface AboutUsProps {
  onOpenQuote: () => void;
}

export const AboutUs: React.FC<AboutUsProps> = ({ onOpenQuote }) => {
  return (
    <section id="about" className="py-16 bg-white border-b border-[#DDE5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="bg-[#F7F9F6] rounded-2xl border border-[#DDE5DC] p-6 sm:p-10 lg:p-12 shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-7 space-y-5 text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAF4E6] text-[#185C20] font-bold text-xs uppercase tracking-wider">
                <Building className="w-4 h-4 text-[#4D9B2A]" />
                ABOUT SRP MEGHA POWER
              </div>

              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#101A24] tracking-tight leading-tight">
                ENGINEERING SOLUTIONS BUILT AROUND RELIABILITY
              </h2>

              <p className="text-sm sm:text-base text-gray-600 leading-relaxed font-medium">
                Headquartered in Jamshedpur, Jharkhand, <strong>SRP Megha Power</strong> is a leading engineering enterprise specialized in high-vacuum transformer oil filtration, substation maintenance, electrical equipment servicing, and custom industrial centrifugal blower manufacturing and supply.
              </p>

              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                We partner with major steel manufacturing plants, power generation utilities, mining complexes, and heavy industrial facilities to safeguard critical electrical power infrastructure and optimize industrial air and gas movement systems.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="flex items-start gap-2 text-xs font-bold text-[#101A24]">
                  <CheckCircle2 className="w-4 h-4 text-[#4D9B2A] shrink-0 mt-0.5" />
                  <span>Transformer Oil Filtration &amp; Purification</span>
                </div>
                <div className="flex items-start gap-2 text-xs font-bold text-[#101A24]">
                  <CheckCircle2 className="w-4 h-4 text-[#4D9B2A] shrink-0 mt-0.5" />
                  <span>Centrifugal Blower Manufacturing &amp; Supply</span>
                </div>
                <div className="flex items-start gap-2 text-xs font-bold text-[#101A24]">
                  <CheckCircle2 className="w-4 h-4 text-[#4D9B2A] shrink-0 mt-0.5" />
                  <span>Switchgear Supply &amp; Electrical Panels</span>
                </div>
                <div className="flex items-start gap-2 text-xs font-bold text-[#101A24]">
                  <CheckCircle2 className="w-4 h-4 text-[#4D9B2A] shrink-0 mt-0.5" />
                  <span>Plant Maintenance &amp; 24/7 Support</span>
                </div>
              </div>

              <div className="pt-2">
                <button 
                  onClick={onOpenQuote}
                  className="bg-[#185C20] hover:bg-[#0D3F18] text-white px-6 py-3 rounded-lg font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors"
                >
                  <span>CONNECT WITH OUR TECHNICAL TEAM</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>

            {/* Right Card Column */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-xl p-6 border border-[#DDE5DC] shadow-md space-y-4">
                <div className="border-b border-gray-100 pb-3">
                  <span className="text-xs font-bold text-[#4D9B2A] uppercase tracking-wider">Corporate Hub</span>
                  <h3 className="font-extrabold text-lg text-[#101A24]">{COMPANY_DETAILS.fullName}</h3>
                  <p className="text-xs text-gray-500">{COMPANY_DETAILS.location}</p>
                </div>

                <div className="space-y-2 text-xs text-gray-700">
                  <div className="flex justify-between py-1.5 border-b border-gray-100">
                    <span className="text-gray-500">Core Expertise:</span>
                    <span className="font-bold text-[#101A24]">Oil Filtration & Blower Tech</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-gray-100">
                    <span className="text-gray-500">Field Service Fleet:</span>
                    <span className="font-bold text-[#185C20]">Mobile Truck & Trailer Units</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-gray-100">
                    <span className="text-gray-500">Standards Compliance:</span>
                    <span className="font-bold text-[#101A24]">IS / IEC Substation Standards</span>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-gray-500">Field Operational Radius:</span>
                    <span className="font-bold text-[#101A24]">Pan-India Industrial Coverage</span>
                  </div>
                </div>

                <div className="bg-[#EAF4E6] p-3 rounded-lg text-xs font-bold text-[#185C20] flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#4D9B2A] shrink-0" />
                  <span>Committed to Zero Unplanned Downtime for Clients</span>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
