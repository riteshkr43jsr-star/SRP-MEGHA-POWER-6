import React from 'react';

interface CompanyLogoProps {
  variant?: 'light' | 'dark';
  size?: 'sm' | 'md' | 'lg';
}

export const SrpLeafLogoIcon: React.FC<{ className?: string }> = ({ className = 'w-16 h-14' }) => {
  const uid = React.useId().replace(/:/g, '');
  return (
    <svg
      viewBox="7 7 105 82"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="SRP Megha Power Logo"
    >
      <defs>
        {/* Main vibrant green leaf gradient (bright lime-green on left to rich forest green on right) */}
        <linearGradient id={`leafMain-${uid}`} x1="12" y1="50" x2="108" y2="38" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#5CE646" />
          <stop offset="45%" stopColor="#26B92B" />
          <stop offset="100%" stopColor="#148018" />
        </linearGradient>

        {/* Glossy lighter green highlight overlay on upper-left leaf section */}
        <linearGradient id={`leafGloss-${uid}`} x1="18" y1="32" x2="60" y2="62" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#7CF066" stopOpacity="0.95" />
          <stop offset="60%" stopColor="#52DC42" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#28B82C" stopOpacity="0.0" />
        </linearGradient>

        {/* Deep green gradient for lower-right leaf body */}
        <linearGradient id={`leafLower-${uid}`} x1="10" y1="84" x2="106" y2="18" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#54E040" />
          <stop offset="38%" stopColor="#22B227" />
          <stop offset="75%" stopColor="#168D1B" />
          <stop offset="100%" stopColor="#137A17" />
        </linearGradient>
      </defs>

      {/* Unified Leaf & Lightning Bolt Emblem */}
      {/* 1. Upper-Left Leaf Wing + Body with Curved White Vein Cutout */}
      <path
        d="M 109 10
           C 97 19, 82 18, 63 18
           C 40 18, 25 31, 18.5 54.5
           C 18.1 56, 19.6 56.8, 20.5 55.4
           C 27.5 41, 39 31.5, 51.5 27.2
           C 53.2 26.6, 54.4 28.8, 52.6 29.7
           C 39.5 35.2, 28.5 45.5, 22.2 60
           C 20.2 65, 19.2 71, 19 76.2
           C 19 77.3, 20.1 77.8, 21 77.2
           L 59.5 51.8
           Q 61.5 50.5, 59.8 49
           L 49.8 41.2
           Q 48.2 39.8, 50.4 38.9
           L 98.5 21.8
           Q 100.2 21.2, 99.2 22.8
           L 109 10 Z"
        fill={`url(#leafMain-${uid})`}
      />

      {/* 2. Glossy Highlight Overlay on Left Leaf Body */}
      <path
        d="M 22.2 60
           C 20.2 65, 19.2 71, 19 76.2
           C 19 77.3, 20.1 77.8, 21 77.2
           L 55.5 54.4
           C 44 55.5, 32 51.5, 25.5 44.5
           C 24.2 49.5, 23 55, 22.2 60 Z"
        fill={`url(#leafGloss-${uid})`}
      />

      {/* 3. Lower-Right Leaf Body + Stem + Lightning Lower Edge */}
      <path
        d="M 109 10
           L 98.8 22.2
           L 73.5 40.8
           Q 71.8 42, 73.6 43.3
           L 85.2 51.5
           Q 87 52.8, 84.8 53.8
           L 11.2 82.8
           C 9.2 83.6, 9.5 86.4, 11.8 86
           C 21 84.2, 29 83.8, 41 85.2
           C 58 87.2, 73 84.5, 86.5 71.5
           C 99.5 59, 107.5 35, 109 10 Z"
        fill={`url(#leafLower-${uid})`}
      />

      {/* 4. White Curved Accent Channel on Lower-Right Leaf Edge */}
      <path
        d="M 69.5 73.5
           C 80.5 68.5, 89.5 59.5, 96.5 47.5"
        stroke="#FFFFFF"
        strokeWidth="3.2"
        strokeLinecap="round"
      />

      {/* 5. Outer Lower-Right Green Crescent Accent */}
      <path
        d="M 69.5 76.2
           C 82 71, 92 60.5, 99.2 47"
        stroke="#158419"
        strokeWidth="3.6"
        strokeLinecap="round"
      />
    </svg>
  );
};

export const CompanyLogo: React.FC<CompanyLogoProps> = ({ variant = 'light', size = 'md' }) => {
  const isDark = variant === 'dark';

  const iconSizeClass =
    size === 'sm'
      ? 'w-12 h-10 sm:w-14 sm:h-11'
      : size === 'lg'
      ? 'w-20 h-16 sm:w-24 sm:h-20'
      : 'w-16 h-12 sm:w-20 sm:h-16';

  return (
    <div className="flex items-center gap-3 sm:gap-3.5 text-left cursor-pointer select-none group">
      {/* Official Green Leaf + Lightning Bolt Logo in front of Company Name */}
      <div className={`shrink-0 flex items-center justify-center transition-transform duration-300 group-hover:scale-105 ${
        isDark ? 'bg-white/95 p-1.5 rounded-xl shadow-md' : ''
      }`}>
        <SrpLeafLogoIcon className={iconSizeClass} />
      </div>

      <div className="flex flex-col justify-center">
        {/* Brand Main Title: SRP in Blue, MEGHA in Orange, POWER in Green */}
        <div className="flex items-center gap-1.5">
          <span className={`font-black tracking-tight leading-none uppercase ${
            size === 'sm' ? 'text-base' : size === 'lg' ? 'text-2xl sm:text-3xl' : 'text-xl sm:text-2xl'
          }`}>
            <span className={isDark ? 'text-blue-400' : 'text-[#1D4ED8]'}>SRP </span>
            <span className="text-[#EA580C]">MEGHA </span>
            <span className="text-[#16A34A]">POWER</span>
          </span>
        </div>

        {/* Company Slogan below Company Name */}
        <span className={`font-bold tracking-wider uppercase mt-1 leading-tight ${
          size === 'sm' ? 'text-[8px]' : size === 'lg' ? 'text-[11px] sm:text-xs' : 'text-[9.5px] sm:text-[10.5px]'
        } ${isDark ? 'text-emerald-300/95' : 'text-[#0B1E38]/80'}`}>
          Trusted for Power Quality and Reliability
        </span>
      </div>
    </div>
  );
};



