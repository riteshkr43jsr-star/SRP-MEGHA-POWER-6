import React, { useState, useEffect } from 'react';
import { ArrowUp, Phone, MessageSquare } from 'lucide-react';
import { COMPANY_DETAILS } from '../data/companyData';

interface FloatingActionsProps {
  onOpenQuote: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({ onOpenQuote }) => {
  const [showTopBtn, setShowTopBtn] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowTopBtn(true);
      } else {
        setShowTopBtn(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-none">
      
      {/* Quick WhatsApp & Call Floating Pills */}
      <div className="pointer-events-auto flex items-center gap-2 bg-[#185C20] text-white p-1.5 px-3 rounded-full shadow-2xl border-2 border-white/40">
        <a 
          href={`https://wa.me/${COMPANY_DETAILS.whatsappNumber}?text=Hello%20SRP%20Megha%20Power,%20I%20would%20like%20to%20inquire%20about%20your%20services.`} 
          target="_blank"
          rel="noopener noreferrer"
          className="w-9 h-9 rounded-full bg-[#25D366] flex items-center justify-center text-white shrink-0 hover:scale-110 transition-transform shadow-xs"
          title="Chat on WhatsApp (+91 9162484535)"
        >
          <MessageSquare className="w-4 h-4 fill-current" />
        </a>

        <a 
          href={`tel:${COMPANY_DETAILS.phonePrimary}`} 
          className="w-9 h-9 rounded-full bg-[#4D9B2A] flex items-center justify-center text-white shrink-0 hover:scale-110 transition-transform shadow-xs"
          title="Call Technical Team (+91 8603683851)"
        >
          <Phone className="w-4 h-4" />
        </a>

        <button 
          onClick={onOpenQuote}
          className="text-xs font-extrabold uppercase tracking-wider text-left hover:text-emerald-200 transition-colors pl-1 pr-1"
        >
          <span>QUICK RFQ</span>
        </button>
      </div>

      {/* Scroll to Top Button */}
      {showTopBtn && (
        <button 
          onClick={scrollToTop}
          className="pointer-events-auto w-10 h-10 rounded-full bg-[#101A24] text-white border border-[#DDE5DC] shadow-lg flex items-center justify-center hover:bg-[#185C20] transition-all duration-200"
          title="Back to Top"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

    </div>
  );
};
