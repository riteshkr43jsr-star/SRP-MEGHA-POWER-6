export interface ProductItem {
  id: string;
  name: string;
  category: 'filtration' | 'blower';
  subcategory?: string;
  capacity?: string;
  shortDesc: string;
  fullDesc: string;
  image: string;
  specs: string[];
  applications: string[];
  badge?: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  features: string[];
}

export interface BlowerApplication {
  id?: string;
  title: string;
  subtitle?: string;
  description: string;
  icon: string;
  bgTag: string;
  highlightType?: 'steel' | 'mining' | string;
  keyEquipment?: string[];
}

export interface IndustryItem {
  id: string;
  name: string;
  description: string;
  icon: string;
  image: string;
}

export interface FieldProject {
  id: string;
  title: string;
  category: 'filtration' | 'maintenance' | 'blower' | 'electrical';
  location: string;
  image: string;
  description: string;
}

export interface ClientLogo {
  name: string;
  logoText: string;
  subtitle?: string;
  color?: string;
  logoType?: 'tata-steel' | 'sail' | 'tata-motors' | 'tata-metaliks' | 'rungta' | 'timken' | 'tinplate' | 'tata-growth' | 'iswp' | 'usha-martin' | 'linde' | string;
  logoUrl?: string;
}

export interface TestimonialItem {
  id: string;
  authorName?: string;
  quote: string;
  role: string;
  organization: string;
  rating: number;
  location: string;
  industryCategory?: 'steel' | 'power' | 'mining' | 'manufacturing' | 'chemical' | string;
  date?: string;
  verifiedContract?: string;
  avatarColor?: string;
}

export interface QuoteFormData {
  fullName: string;
  companyName: string;
  phone: string;
  email: string;
  serviceOrProduct: string;
  quantityOrCapacity?: string;
  message: string;
}
