import React, { useState, useEffect, useMemo } from 'react';
import { 
  LogOut, Home, Settings, FileText, Download, Activity, CheckCircle2, 
  Search, Trash2, Eye, Printer, Clock, Briefcase, AlertCircle, 
  Phone, Mail, User, X, BarChart3, Filter, Plus, MessageCircle, MessageSquare, DollarSign,
  TrendingUp, RefreshCw, FileSpreadsheet, Building2, Tag, Check, Layers,
  Send, ExternalLink, Copy, Upload, ShieldCheck
} from 'lucide-react';
import { 
  getQuotes, updateQuoteStatus, updateQuoteDetails, createManualLead, 
  resetQuotesToSeed, exportQuotesToCSV, exportQuotesToJSON, importQuotesFromJSON,
  sendQuoteEmailNotification, SavedQuote, getAdminSettings, 
  updateAdminSettings, deleteQuoteRecord, formatWhatsAppQuoteMessage,
  subscribeToQuotes
} from '../../utils/storage';
import { 
  generateCompleteQuotePDF, 
  downloadQuotePDFFile, 
  getQuotePDFObjects, 
  getQuotePDFFilename, 
  tryNativeFileShare 
} from '../../utils/pdfGenerator';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SrpLeafLogoIcon } from '../CompanyLogo';

interface AdminDashboardProps {
  onLogout: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState<'quotes' | 'analytics' | 'settings'>('quotes');
  const [quotes, setQuotes] = useState<SavedQuote[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'serial-desc' | 'serial-asc' | 'date-desc' | 'value-desc'>('serial-desc');
  
  const [settings, setSettings] = useState(getAdminSettings());
  const [adminWhatsAppInput, setAdminWhatsAppInput] = useState(settings.adminWhatsApp || '919162484535');
  const [settingsSaveSuccess, setSettingsSaveSuccess] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState<SavedQuote | null>(null);
  const [quoteToDelete, setQuoteToDelete] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // WhatsApp Complete PDF Dispatch Modal State
  const [whatsAppPDFModalQuote, setWhatsAppPDFModalQuote] = useState<SavedQuote | null>(null);
  const [whatsAppModalTarget, setWhatsAppModalTarget] = useState<'admin' | 'customer'>('admin');
  const [shareSuccessNotice, setShareSuccessNotice] = useState<string | null>(null);

  // Quick edit inside detail modal
  const [editNotes, setEditNotes] = useState('');
  const [editValue, setEditValue] = useState<number | ''>('');
  const [editPriority, setEditPriority] = useState<'High' | 'Medium' | 'Normal'>('Normal');
  const [isSavingDetails, setIsSavingDetails] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState(false);

  // New Lead Modal State
  const [isAddLeadOpen, setIsAddLeadOpen] = useState(false);
  const [newLead, setNewLead] = useState({
    fullName: '',
    companyName: '',
    phone: '',
    email: '',
    serviceOrProduct: 'Transformer Oil Filtration Machine',
    quantityOrCapacity: '',
    message: '',
    estimatedValue: '',
    priority: 'Normal' as 'High' | 'Medium' | 'Normal',
    source: 'Direct Call' as 'Direct Call' | 'WhatsApp' | 'Walk-in Workshop' | 'Website RFQ',
    status: 'Pending' as SavedQuote['status']
  });

  // Email Forwarding & Dispatch Modal State
  const [emailModalQuote, setEmailModalQuote] = useState<SavedQuote | null>(null);
  const [emailSending, setEmailSending] = useState(false);
  const [emailResult, setEmailResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchQuotes = async () => {
    setIsRefreshing(true);
    try {
      const data = await getQuotes();
      setQuotes(data);
    } catch (err) {
      console.warn('Error fetching quotes in dashboard:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchQuotes();

    // 1. Cross-device Realtime Supabase Live Channel (Mobile, Tablet, Desktop)
    const unsubscribeSupabase = subscribeToQuotes(() => {
      fetchQuotes();
    });

    // 2. Guaranteed background poll every 6 seconds to capture any mobile inquiries
    const pollTimer = setInterval(() => {
      fetchQuotes();
    }, 6000);

    // 3. Local tab and storage events
    const handleUpdate = () => {
      fetchQuotes();
    };

    window.addEventListener('srp_quotes_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      unsubscribeSupabase();
      clearInterval(pollTimer);
      window.removeEventListener('srp_quotes_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  // Sync edit state when modal opens
  useEffect(() => {
    if (selectedQuote) {
      setEditNotes(selectedQuote.notes || '');
      setEditValue(selectedQuote.estimatedValue || '');
      setEditPriority(selectedQuote.priority || 'Normal');
      setSaveSuccessMsg(false);
    }
  }, [selectedQuote]);

  const handleStatusChange = async (id: string, newStatus: SavedQuote['status']) => {
    await updateQuoteStatus(id, newStatus);
    fetchQuotes();
    if (selectedQuote && selectedQuote.id === id) {
      setSelectedQuote({ ...selectedQuote, status: newStatus });
    }
  };

  const handleSaveModalDetails = async () => {
    if (!selectedQuote) return;
    setIsSavingDetails(true);
    await updateQuoteDetails(selectedQuote.id, {
      notes: editNotes,
      estimatedValue: editValue === '' ? undefined : Number(editValue),
      priority: editPriority
    });
    await fetchQuotes();
    setSelectedQuote(prev => prev ? {
      ...prev,
      notes: editNotes,
      estimatedValue: editValue === '' ? undefined : Number(editValue),
      priority: editPriority
    } : null);
    setIsSavingDetails(false);
    setSaveSuccessMsg(true);
    setTimeout(() => setSaveSuccessMsg(false), 3000);
  };

  const handleCreateLead = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLead.fullName || !newLead.phone) return;

    await createManualLead({
      fullName: newLead.fullName,
      companyName: newLead.companyName,
      phone: newLead.phone,
      email: newLead.email,
      serviceOrProduct: newLead.serviceOrProduct,
      quantityOrCapacity: newLead.quantityOrCapacity,
      message: newLead.message || 'Direct offline quotation inquiry recorded via Admin Panel.',
      estimatedValue: newLead.estimatedValue ? Number(newLead.estimatedValue) : undefined,
      priority: newLead.priority,
      source: newLead.source,
      status: newLead.status
    });

    setIsAddLeadOpen(false);
    setNewLead({
      fullName: '',
      companyName: '',
      phone: '',
      email: '',
      serviceOrProduct: 'Transformer Oil Filtration Machine',
      quantityOrCapacity: '',
      message: '',
      estimatedValue: '',
      priority: 'Normal',
      source: 'Direct Call',
      status: 'Pending'
    });
    fetchQuotes();
  };

  const handleToggleSettings = () => {
    const newSettings = { ...settings, allowPublicDownloads: !settings.allowPublicDownloads };
    updateAdminSettings(newSettings);
    setSettings(newSettings);
  };

  const handleResetData = async () => {
    if (window.confirm('Reset all quotes to default sample industrial corporate records?')) {
      await resetQuotesToSeed();
      fetchQuotes();
    }
  };

  const deleteQuote = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setQuoteToDelete(id);
    setDeleteError(null);
  };

  const confirmDelete = async () => {
    if (!quoteToDelete) return;
    setIsDeleting(true);
    setDeleteError(null);
    try {
      const success = await deleteQuoteRecord(quoteToDelete);
      if (success) {
        fetchQuotes();
        if (selectedQuote && selectedQuote.id === quoteToDelete) {
          setSelectedQuote(null);
        }
        setQuoteToDelete(null);
      } else {
        setDeleteError("Failed to delete record.");
      }
    } finally {
      setIsDeleting(false);
    }
  };

  const openWhatsApp = (quote: SavedQuote, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const cleanPhone = quote.phone.replace(/[^0-9]/g, '');
    const phoneWithCountry = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    const msg = formatWhatsAppQuoteMessage(quote, false);
    window.open(`https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  /**
   * Shares the FULL, complete official quotation PDF directly on WhatsApp.
   * On mobile / supported devices, Web Share API sends the ACTUAL .PDF FILE into WhatsApp.
   * On desktop, automatically downloads the PDF and opens the chat with attach instructions.
   */
  const handleSharePDFToWhatsApp = async (quote: SavedQuote, target: 'admin' | 'customer' = 'admin', e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setWhatsAppPDFModalQuote(quote);
    setWhatsAppModalTarget(target);
    setShareSuccessNotice(null);

    // 1. Ensure file is downloaded so user has the actual PDF ready on their device
    downloadQuotePDFFile(quote);

    // 2. Try native OS file share (Level 2 Web Share API)
    // When WhatsApp is chosen on mobile/desktop, it sends the REAL PDF FILE
    const shareRes = await tryNativeFileShare(quote);
    if (shareRes.sharedNative) {
      setShareSuccessNotice('Official PDF document sent to WhatsApp share sheet!');
    }
  };

  const openWhatsAppChatWithInstructions = (quote?: SavedQuote, target?: 'admin' | 'customer') => {
    const q = quote || whatsAppPDFModalQuote;
    if (!q) return;
    const t = target || whatsAppModalTarget;

    const rawTarget = t === 'admin' 
      ? (settings.adminWhatsApp || '919162484535') 
      : q.phone;

    const cleanPhone = rawTarget.replace(/[^0-9]/g, '');
    const phoneWithCountry = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    const msg = formatWhatsAppQuoteMessage(q, t === 'admin');
    window.open(`https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const sendQuoteToAdminWhatsApp = (quote: SavedQuote, e?: React.MouseEvent) => {
    handleSharePDFToWhatsApp(quote, 'admin', e);
  };

  const getEmailContent = (quote: SavedQuote) => {
    const subject = `[SRP RFQ Alert #${quote.id}] ${quote.serviceOrProduct} - ${quote.fullName} (${quote.companyName || 'Industrial Client'})`;
    const body = `SRP MEGHA POWER - QUOTATION INQUIRY NOTIFICATION\n` +
      `==================================================\n` +
      `Reference ID: #${quote.id}\n` +
      `Date Logged: ${new Date(quote.date).toLocaleString()}\n` +
      `Current Status: ${quote.status}\n` +
      `Priority: ${quote.priority || 'Normal'}\n` +
      `Estimated Value: ${quote.estimatedValue ? 'Rs ' + quote.estimatedValue.toLocaleString('en-IN') : 'Not Specified'}\n\n` +
      `CLIENT PROFILE:\n` +
      `Name: ${quote.fullName}\n` +
      `Company / Substation: ${quote.companyName || 'N/A'}\n` +
      `Phone: ${quote.phone}\n` +
      `Email: ${quote.email || 'N/A'}\n\n` +
      `REQUIREMENT:\n` +
      `Product/Service: ${quote.serviceOrProduct}\n` +
      `Quantity/Capacity: ${quote.quantityOrCapacity || 'Standard Industrial'}\n` +
      `Message: ${quote.message || 'No additional note provided.'}\n\n` +
      `INTERNAL NOTES:\n` +
      `${quote.notes || 'None logged yet.'}\n\n` +
      `---\n` +
      `Access your live Admin Portal: ${window.location.origin}/#admin`;
    return { subject, body };
  };

  const openEmailModal = (quote: SavedQuote, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEmailModalQuote(quote);
    setEmailResult(null);
    setCopiedNotification(false);
  };

  const handleSendViaFormSubmit = async () => {
    if (!emailModalQuote) return;
    setEmailSending(true);
    setEmailResult(null);
    try {
      const res = await sendQuoteEmailNotification(emailModalQuote);
      setEmailResult(res);
    } catch (e: any) {
      setEmailResult({ success: false, message: e?.message || 'Failed to dispatch email' });
    } finally {
      setEmailSending(false);
    }
  };

  const handleOpenGmailWeb = () => {
    if (!emailModalQuote) return;
    const { subject, body } = getEmailContent(emailModalQuote);
    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=srpmeghapower11@gmail.com,riteshkr43jsr@gmail.com&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(gmailUrl, '_blank');
  };

  const handleCopyEmailText = () => {
    if (!emailModalQuote) return;
    const { subject, body } = getEmailContent(emailModalQuote);
    const fullText = `Subject: ${subject}\n\n${body}`;
    navigator.clipboard.writeText(fullText);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 3000);
  };

  const handleOpenMailto = () => {
    if (!emailModalQuote) return;
    const { subject, body } = getEmailContent(emailModalQuote);
    window.location.href = `mailto:srpmeghapower11@gmail.com,riteshkr43jsr@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const downloadPDF = (quote: SavedQuote) => {
    downloadQuotePDFFile(quote);
  };

  const downloadAllAsPDF = () => {
    const doc = new jsPDF();
    doc.setFillColor(15, 60, 24);
    doc.rect(0, 0, 210, 26, 'F');
    doc.setFillColor(77, 155, 42);
    doc.rect(0, 26, 210, 2, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('SRP MEGHA POWER - MASTER LEAD & QUOTATION PIPELINE REPORT', 14, 14);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('1st Floor, New Kalimati Road, Near Chandra Hotel, Sakchi, Jamshedpur - 831001 | Call: +91 86036 83851 | Email: srpmeghapower11@gmail.com', 14, 21);

    const tableData = filteredQuotes.map(q => [
      `#${String(q.serialNumber || 1).padStart(3, '0')}`,
      q.id,
      new Date(q.date).toLocaleDateString('en-IN'),
      q.companyName ? `${q.fullName}\n(${q.companyName})` : q.fullName,
      q.phone,
      q.serviceOrProduct,
      q.estimatedValue ? `₹${q.estimatedValue.toLocaleString('en-IN')}` : '-',
      q.status
    ]);

    autoTable(doc, {
      startY: 32,
      head: [['Sr. No.', 'Ref ID', 'Date', 'Client & Organization', 'Phone', 'Requirement Scope', 'Est. Value', 'Status']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [15, 60, 24], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 8 },
      styles: { fontSize: 7.5, cellPadding: 2.5 }
    });

    doc.save(`SRP_Megha_Power_Serial_Leads_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  const goHome = () => {
    window.location.hash = '';
    window.location.reload();
  };

  const printQuote = () => {
    window.print();
  };

  // Status Styling Colors
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Pending': 
        return {
          pill: 'bg-amber-100 text-amber-800 border-amber-300 ring-amber-400/20',
          dot: 'bg-amber-500 animate-pulse'
        };
      case 'Approved': 
        return {
          pill: 'bg-emerald-100 text-emerald-800 border-emerald-300 ring-emerald-400/20',
          dot: 'bg-emerald-500'
        };
      case 'Working On': 
        return {
          pill: 'bg-sky-100 text-sky-800 border-sky-300 ring-sky-400/20',
          dot: 'bg-sky-500 animate-spin'
        };
      case 'Remaining': 
        return {
          pill: 'bg-rose-100 text-rose-800 border-rose-300 ring-rose-400/20',
          dot: 'bg-rose-500'
        };
      default: 
        return {
          pill: 'bg-slate-100 text-slate-800 border-slate-300 ring-slate-400/20',
          dot: 'bg-slate-400'
        };
    }
  };

  // Calculated Metrics
  const stats = useMemo(() => {
    const total = quotes.length;
    const pending = quotes.filter(q => q.status === 'Pending').length;
    const working = quotes.filter(q => q.status === 'Working On').length;
    const approved = quotes.filter(q => q.status === 'Approved').length;
    const remaining = quotes.filter(q => q.status === 'Remaining').length;
    
    // Total Pipeline Value
    const totalPipelineValue = quotes.reduce((acc, q) => acc + (q.estimatedValue || 0), 0);
    const approvedValue = quotes
      .filter(q => q.status === 'Approved')
      .reduce((acc, q) => acc + (q.estimatedValue || 0), 0);

    const winRate = total > 0 ? Math.round((approved / total) * 100) : 0;

    return { total, pending, working, approved, remaining, totalPipelineValue, approvedValue, winRate };
  }, [quotes]);

  // Product category classifications for analytics & filtering
  const categoryCounts = useMemo(() => {
    const counts: { [key: string]: number } = {
      'Filtration Machines': 0,
      'Industrial Blowers': 0,
      'Transformer Services': 0,
      'Other': 0
    };

    quotes.forEach(q => {
      const text = (q.serviceOrProduct + ' ' + (q.message || '')).toLowerCase();
      if (text.includes('filtr') || text.includes('oil') || text.includes('vacuum') || text.includes('lph')) {
        counts['Filtration Machines']++;
      } else if (text.includes('blower') || text.includes('fan') || text.includes('cmh') || text.includes('centrifugal')) {
        counts['Industrial Blowers']++;
      } else if (text.includes('transformer') || text.includes('rewind') || text.includes('bdv') || text.includes('overhaul') || text.includes('substation')) {
        counts['Transformer Services']++;
      } else {
        counts['Other']++;
      }
    });

    return counts;
  }, [quotes]);

  // Filtering & Sorting
  const filteredQuotes = useMemo(() => {
    return quotes.filter(q => {
      // Status filter
      if (statusFilter !== 'All' && q.status !== statusFilter) return false;

      // Category filter
      if (categoryFilter !== 'All') {
        const text = (q.serviceOrProduct + ' ' + (q.message || '')).toLowerCase();
        if (categoryFilter === 'Filtration' && !(text.includes('filtr') || text.includes('oil') || text.includes('vacuum') || text.includes('lph'))) return false;
        if (categoryFilter === 'Blower' && !(text.includes('blower') || text.includes('fan') || text.includes('cmh') || text.includes('centrifugal'))) return false;
        if (categoryFilter === 'Services' && !(text.includes('transformer') || text.includes('rewind') || text.includes('bdv') || text.includes('substation'))) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const serialStr = String(q.serialNumber || '');
        const match = 
          serialStr.includes(query) ||
          `#${serialStr}`.includes(query) ||
          q.id.toLowerCase().includes(query) ||
          q.fullName.toLowerCase().includes(query) ||
          (q.companyName && q.companyName.toLowerCase().includes(query)) ||
          q.phone.toLowerCase().includes(query) ||
          q.serviceOrProduct.toLowerCase().includes(query) ||
          (q.message && q.message.toLowerCase().includes(query)) ||
          (q.notes && q.notes.toLowerCase().includes(query));
        if (!match) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'serial-desc') return (b.serialNumber || 0) - (a.serialNumber || 0);
      if (sortBy === 'serial-asc') return (a.serialNumber || 0) - (b.serialNumber || 0);
      if (sortBy === 'date-desc') return new Date(b.date).getTime() - new Date(a.date).getTime();
      if (sortBy === 'date-asc') return new Date(a.date).getTime() - new Date(b.date).getTime();
      if (sortBy === 'value-desc') return (b.estimatedValue || 0) - (a.estimatedValue || 0);
      return (b.serialNumber || 0) - (a.serialNumber || 0);
    });
  }, [quotes, statusFilter, categoryFilter, searchQuery, sortBy]);

  const formatINR = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} Lakh`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #print-section, #print-section * { visibility: visible; }
          #print-section { position: absolute; left: 0; top: 0; width: 100%; padding: 0px; background: white; color: black; }
          .no-print { display: none !important; }
        }
      `}</style>
      
      {/* Dynamic Executive Top Navigation */}
      <header className="bg-gradient-to-r from-[#061e0e] via-[#0d3819] to-[#0a2f14] border-b border-emerald-500/20 px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 shadow-xl sticky top-0 z-40 backdrop-blur-md">
        <div className="flex items-center gap-3.5">
          <div className="w-14 h-12 rounded-xl bg-white/95 flex items-center justify-center shadow-lg shadow-emerald-950/50 border border-emerald-300/40 p-1.5">
            <SrpLeafLogoIcon className="w-full h-full" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-black text-base sm:text-lg tracking-wider uppercase text-white drop-shadow">
                SRP MEGHA POWER
              </h1>
              <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Admin Portal
              </span>
            </div>
            <p className="text-[10px] text-amber-300 font-extrabold uppercase tracking-wider mt-0.5">
              Trusted for Power Quality and Reliability
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Cloud Sync Status Indicator */}
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-[10px] font-black uppercase text-emerald-300 shadow-sm" title="Realtime Cloud Sync active across all devices: Mobile, Tablet & Desktop">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Cloud Live Sync (Mobile • Tablet • Desktop)</span>
          </div>

          {/* Manual Refresh Button */}
          <button 
            onClick={fetchQuotes}
            disabled={isRefreshing}
            className="bg-slate-800 hover:bg-slate-700 text-emerald-300 hover:text-white border border-slate-700 hover:border-emerald-500/50 font-bold text-xs px-3 py-2 rounded-xl flex items-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer disabled:opacity-50"
            title="Refresh Leads from Cloud Database"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
            <span className="hidden sm:inline">{isRefreshing ? 'Syncing...' : 'Refresh'}</span>
          </button>

          <button 
            onClick={() => setIsAddLeadOpen(true)}
            className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span className="hidden sm:inline">New Lead / RFQ</span>
            <span className="sm:hidden">Add</span>
          </button>

          <button 
            onClick={goHome} 
            className="text-emerald-100 hover:text-white flex items-center gap-1.5 text-xs font-bold transition-all bg-white/10 hover:bg-white/15 px-3 py-2 rounded-xl border border-white/10 shadow-sm"
          >
            <Home className="w-4 h-4" /> 
            <span className="hidden md:inline">Live Website</span>
          </button>
          
          <button 
            onClick={onLogout} 
            className="text-rose-200 hover:text-white flex items-center gap-1.5 text-xs font-bold transition-all bg-rose-500/20 hover:bg-rose-500/35 px-3 py-2 rounded-xl border border-rose-500/30 shadow-sm"
          >
            <LogOut className="w-4 h-4" /> 
            <span className="hidden md:inline">Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-grow flex flex-col md:flex-row max-w-[1600px] w-full mx-auto p-3 sm:p-5 gap-4">
        
        {/* Colorful Sidebar Navigation */}
        <aside className="w-full md:w-60 shrink-0 flex flex-col gap-2">
          <nav className="bg-slate-800/80 backdrop-blur-md rounded-2xl p-2.5 border border-slate-700/70 shadow-lg space-y-1.5">
            <button 
              onClick={() => setActiveTab('quotes')}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl font-black text-xs transition-all duration-200 ${
                activeTab === 'quotes' 
                  ? 'bg-gradient-to-r from-emerald-600 to-green-700 text-white shadow-lg shadow-emerald-950/40 translate-x-1 border-l-4 border-emerald-300' 
                  : 'text-slate-300 hover:bg-slate-700/60 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <FileText className="w-4 h-4 text-emerald-400" />
                <span>Lead Pipeline</span>
              </div>
              <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                activeTab === 'quotes' ? 'bg-white text-emerald-900' : 'bg-slate-700 text-slate-300'
              }`}>
                {quotes.length}
              </span>
            </button>

            <button 
              onClick={() => setActiveTab('analytics')}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl font-black text-xs transition-all duration-200 ${
                activeTab === 'analytics' 
                  ? 'bg-gradient-to-r from-emerald-600 to-green-700 text-white shadow-lg shadow-emerald-950/40 translate-x-1 border-l-4 border-emerald-300' 
                  : 'text-slate-300 hover:bg-slate-700/60 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <BarChart3 className="w-4 h-4 text-sky-400" />
                <span>Demand Analytics</span>
              </div>
              <span className="text-[10px] font-bold text-sky-400 uppercase tracking-widest">
                Charts
              </span>
            </button>

            <button 
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl font-black text-xs transition-all duration-200 ${
                activeTab === 'settings' 
                  ? 'bg-gradient-to-r from-emerald-600 to-green-700 text-white shadow-lg shadow-emerald-950/40 translate-x-1 border-l-4 border-emerald-300' 
                  : 'text-slate-300 hover:bg-slate-700/60 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Settings className="w-4 h-4 text-amber-400" />
                <span>Settings & Data</span>
              </div>
            </button>
          </nav>

          {/* Quick Value Indicator Box in Sidebar */}
          <div className="bg-gradient-to-br from-slate-800 to-slate-850 rounded-2xl p-4 border border-emerald-500/20 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                Pipeline Value
              </span>
              <span className="text-[10px] font-black text-emerald-300 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                INR
              </span>
            </div>
            <div className="text-xl font-black text-white">
              {formatINR(stats.totalPipelineValue)}
            </div>
            <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
              Approved Won: <span className="font-bold text-emerald-300">{formatINR(stats.approvedValue)}</span>
            </p>
          </div>

          {/* Connected Admin Email Indicator */}
          <div className="bg-gradient-to-br from-slate-800 to-slate-850 rounded-2xl p-3.5 border border-sky-500/20 shadow-md">
            <div className="flex items-center gap-2 text-sky-400 font-bold text-xs">
              <Mail className="w-4 h-4 shrink-0" />
              <span>Admin Email Link</span>
            </div>
            <p className="text-[11px] font-mono text-emerald-300 mt-1 font-bold truncate">
              riteshkr43jsr@gmail.com
            </p>
            <p className="text-[10px] text-slate-400 mt-0.5">
              1-click dispatch to your Gmail inbox.
            </p>
          </div>

          {/* Quick Shortcuts */}
          <div className="bg-slate-800/60 rounded-2xl p-3 border border-slate-700/60 space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-1">
              Quick Actions
            </span>
            <button 
              onClick={() => exportQuotesToCSV(filteredQuotes)}
              className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold text-slate-300 hover:bg-slate-700 hover:text-emerald-300 transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              Export to Excel (CSV)
            </button>
            <button 
              onClick={downloadAllAsPDF}
              className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold text-slate-300 hover:bg-slate-700 hover:text-sky-300 transition-colors"
            >
              <Download className="w-4 h-4 text-sky-400" />
              Download Master PDF
            </button>
          </div>
        </aside>

        {/* Dashboard Center Area */}
        <main className="flex-grow bg-slate-900 rounded-3xl border border-slate-800 overflow-hidden flex flex-col shadow-2xl relative">
          
          {/* TAB 1: QUOTES & PIPELINE */}
          {activeTab === 'quotes' && (
            <div className="flex flex-col h-full">
              
              {/* Vibrant Stats Row */}
              <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-slate-850/60">
                <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                  
                  {/* Total Inquiries (Indigo/Purple Card) */}
                  <div 
                    onClick={() => setStatusFilter('All')}
                    className={`cursor-pointer rounded-2xl p-3.5 border transition-all duration-200 relative overflow-hidden group ${
                      statusFilter === 'All' 
                        ? 'bg-gradient-to-br from-indigo-950/80 via-indigo-900/50 to-slate-900 border-indigo-400 shadow-lg shadow-indigo-950/60' 
                        : 'bg-slate-800/70 border-slate-700 hover:border-indigo-500/50 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400">Total Leads</span>
                      <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-300 flex items-center justify-center border border-indigo-400/30">
                        <Layers className="w-3.5 h-3.5" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-white mt-1.5">
                      {stats.total}
                    </div>
                    <p className="text-[10px] text-indigo-300/70 font-semibold mt-0.5">
                      All industrial requests
                    </p>
                  </div>

                  {/* Pending Inquiries (Amber/Gold Card) */}
                  <div 
                    onClick={() => setStatusFilter('Pending')}
                    className={`cursor-pointer rounded-2xl p-3.5 border transition-all duration-200 relative overflow-hidden group ${
                      statusFilter === 'Pending' 
                        ? 'bg-gradient-to-br from-amber-950/80 via-amber-900/50 to-slate-900 border-amber-400 shadow-lg shadow-amber-950/60' 
                        : 'bg-slate-800/70 border-slate-700 hover:border-amber-500/50 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-wider text-amber-400">Pending Action</span>
                      <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center border border-amber-400/30">
                        <Clock className="w-3.5 h-3.5" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-amber-300 mt-1.5 flex items-center gap-2">
                      {stats.pending}
                      {stats.pending > 0 && (
                        <span className="text-[9px] bg-amber-500/30 text-amber-200 px-2 py-0.5 rounded-full font-bold animate-pulse">
                          Needs Reply
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-amber-300/70 font-semibold mt-0.5">
                      Requires quotation
                    </p>
                  </div>

                  {/* Working On (Sky/Blue Card) */}
                  <div 
                    onClick={() => setStatusFilter('Working On')}
                    className={`cursor-pointer rounded-2xl p-3.5 border transition-all duration-200 relative overflow-hidden group ${
                      statusFilter === 'Working On' 
                        ? 'bg-gradient-to-br from-sky-950/80 via-sky-900/50 to-slate-900 border-sky-400 shadow-lg shadow-sky-950/60' 
                        : 'bg-slate-800/70 border-slate-700 hover:border-sky-500/50 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-wider text-sky-400">In Progress</span>
                      <div className="w-7 h-7 rounded-lg bg-sky-500/20 text-sky-300 flex items-center justify-center border border-sky-400/30">
                        <Briefcase className="w-3.5 h-3.5" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-sky-300 mt-1.5">
                      {stats.working}
                    </div>
                    <p className="text-[10px] text-sky-300/70 font-semibold mt-0.5">
                      Offer under review
                    </p>
                  </div>

                  {/* Approved (Emerald/Green Card) */}
                  <div 
                    onClick={() => setStatusFilter('Approved')}
                    className={`cursor-pointer rounded-2xl p-3.5 border transition-all duration-200 relative overflow-hidden group ${
                      statusFilter === 'Approved' 
                        ? 'bg-gradient-to-br from-emerald-950/80 via-emerald-900/50 to-slate-900 border-emerald-400 shadow-lg shadow-emerald-950/60' 
                        : 'bg-slate-800/70 border-slate-700 hover:border-emerald-500/50 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400">Approved Won</span>
                      <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center border border-emerald-400/30">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-emerald-300 mt-1.5 flex items-center gap-1.5">
                      {stats.approved}
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                        {stats.winRate}% Won
                      </span>
                    </div>
                    <p className="text-[10px] text-emerald-300/70 font-semibold mt-0.5">
                      PO / Work Awarded
                    </p>
                  </div>

                  {/* Remaining / High Priority (Rose/Coral Card) */}
                  <div 
                    onClick={() => setStatusFilter('Remaining')}
                    className={`cursor-pointer rounded-2xl p-3.5 border transition-all duration-200 relative overflow-hidden group ${
                      statusFilter === 'Remaining' 
                        ? 'bg-gradient-to-br from-rose-950/80 via-rose-900/50 to-slate-900 border-rose-400 shadow-lg shadow-rose-950/60' 
                        : 'bg-slate-800/70 border-slate-700 hover:border-rose-500/50 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-wider text-rose-400">Remaining</span>
                      <div className="w-7 h-7 rounded-lg bg-rose-500/20 text-rose-300 flex items-center justify-center border border-rose-400/30">
                        <AlertCircle className="w-3.5 h-3.5" />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-rose-300 mt-1.5">
                      {stats.remaining}
                    </div>
                    <p className="text-[10px] text-rose-300/70 font-semibold mt-0.5">
                      Follow-up pending
                    </p>
                  </div>

                </div>
              </div>

              {/* Colorful Search & Filter Bar */}
              <div className="p-3.5 sm:p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
                
                {/* Search Input */}
                <div className="relative flex-grow max-w-md">
                  <Search className="w-4 h-4 text-emerald-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by client, company, phone, RFQ ID..."
                    className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl pl-9 pr-8 py-2 text-xs text-white placeholder-slate-400 outline-none transition-colors shadow-inner"
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Filters Group */}
                <div className="flex flex-wrap items-center gap-2">
                  
                  {/* Status Dropdown */}
                  <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 shadow-sm text-xs">
                    <Filter className="w-3.5 h-3.5 text-emerald-400" />
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="bg-transparent text-xs font-bold text-slate-200 outline-none cursor-pointer"
                    >
                      <option value="All" className="bg-slate-800 text-white">All Statuses</option>
                      <option value="Pending" className="bg-slate-800 text-amber-300">Pending</option>
                      <option value="Working On" className="bg-slate-800 text-sky-300">Working On</option>
                      <option value="Approved" className="bg-slate-800 text-emerald-300">Approved</option>
                      <option value="Remaining" className="bg-slate-800 text-rose-300">Remaining</option>
                    </select>
                  </div>

                  {/* Category Dropdown */}
                  <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 shadow-sm text-xs">
                    <Tag className="w-3.5 h-3.5 text-sky-400" />
                    <select
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="bg-transparent text-xs font-bold text-slate-200 outline-none cursor-pointer"
                    >
                      <option value="All" className="bg-slate-800 text-white">All Categories</option>
                      <option value="Filtration" className="bg-slate-800 text-emerald-300">Oil Filtration</option>
                      <option value="Blower" className="bg-slate-800 text-sky-300">Industrial Blowers</option>
                      <option value="Services" className="bg-slate-800 text-amber-300">Substation Services</option>
                    </select>
                  </div>

                  {/* Sort Order */}
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-2 text-xs font-bold text-slate-300 outline-none cursor-pointer"
                  >
                    <option value="serial-desc" className="bg-slate-800 text-emerald-300 font-bold">🔢 Serial Wise (Newest #N to #1)</option>
                    <option value="serial-asc" className="bg-slate-800 text-emerald-300 font-bold">🔢 Serial Wise (Oldest #1 to #N)</option>
                    <option value="date-desc" className="bg-slate-800">📅 Date (Newest First)</option>
                    <option value="value-desc" className="bg-slate-800">💰 Highest Deal Value</option>
                  </select>

                </div>
              </div>

              {/* Table Area */}
              <div className="flex-grow overflow-x-auto p-3 sm:p-4 bg-slate-900/50">
                {filteredQuotes.length === 0 ? (
                  <div className="text-center py-16 bg-slate-850/50 rounded-2xl border border-dashed border-slate-800">
                    <div className="w-14 h-14 bg-slate-800 rounded-2xl flex items-center justify-center mx-auto mb-3 text-slate-500 shadow-inner">
                      <Search className="w-6 h-6 text-emerald-400/50" />
                    </div>
                    <p className="font-bold text-sm text-slate-300">No quotation requests match your filter.</p>
                    <p className="text-xs text-slate-500 mt-1">Try resetting search keywords or status filters.</p>
                    <button 
                      onClick={() => { setSearchQuery(''); setStatusFilter('All'); setCategoryFilter('All'); }}
                      className="mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors"
                    >
                      Reset All Filters
                    </button>
                  </div>
                ) : (
                  <div className="rounded-2xl border border-slate-800 bg-slate-850/80 shadow-xl overflow-hidden">
                    <table className="w-full min-w-[1040px] text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-800/90 border-b border-slate-700/80 text-[10px] text-emerald-300/80 font-black uppercase tracking-wider">
                          <th className="py-3 px-3 text-center w-20">Sr. No.</th>
                          <th className="py-3 px-4">Date & Ref</th>
                          <th className="py-3 px-4">Client & Company</th>
                          <th className="py-3 px-4">Requirement / Topic</th>
                          <th className="py-3 px-4">Est. Deal Value</th>
                          <th className="py-3 px-4">Current Status</th>
                          <th className="py-3 px-4 text-right">Quick Contact & Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 text-xs">
                        {filteredQuotes.map(q => {
                          const badge = getStatusBadge(q.status);
                          return (
                            <tr 
                              key={q.id}
                              onClick={() => setSelectedQuote(q)}
                              className="hover:bg-slate-800/60 transition-colors group cursor-pointer"
                            >
                              {/* Sr. No. Badge */}
                              <td className="py-3.5 px-3 align-middle text-center whitespace-nowrap">
                                <span className="font-mono text-xs font-black px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 inline-flex items-center gap-0.5 shadow-xs">
                                  <span className="text-[10px] text-emerald-400/70 font-sans">#</span>
                                  {String(q.serialNumber || 1).padStart(3, '0')}
                                </span>
                              </td>

                              {/* Date & Ref */}
                              <td className="py-3.5 px-4 align-middle whitespace-nowrap">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-mono text-emerald-400 font-bold text-[11px] bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                                    {q.id}
                                  </span>
                                  {q.priority === 'High' && (
                                    <span className="text-[9px] font-black uppercase bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded border border-rose-500/30">
                                      High
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-slate-400 mt-1 font-medium">
                                  {new Date(q.date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}
                                </div>
                              </td>

                              {/* Client & Org */}
                              <td className="py-3.5 px-4 align-middle">
                                <div className="font-black text-white text-sm group-hover:text-emerald-300 transition-colors flex items-center gap-1.5">
                                  <User className="w-3.5 h-3.5 text-slate-400" />
                                  {q.fullName}
                                </div>
                                <div className="text-[11px] text-slate-400 font-medium flex items-center gap-1 mt-0.5">
                                  <Building2 className="w-3 h-3 text-slate-500" />
                                  {q.companyName || 'Industrial Client'}
                                </div>
                              </td>

                              {/* Requirement */}
                              <td className="py-3.5 px-4 align-middle max-w-[280px]">
                                <div className="font-bold text-slate-200 text-xs truncate">
                                  {q.serviceOrProduct}
                                </div>
                                {q.message && (
                                  <div className="text-[10px] text-slate-400 truncate mt-0.5 italic">
                                    "{q.message}"
                                  </div>
                                )}
                              </td>

                              {/* Estimated Value */}
                              <td className="py-3.5 px-4 align-middle whitespace-nowrap">
                                {q.estimatedValue ? (
                                  <span className="font-bold text-emerald-300 bg-emerald-950/70 px-2.5 py-1 rounded-lg border border-emerald-500/30 text-xs">
                                    {formatINR(q.estimatedValue)}
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-slate-500 italic">
                                    Not estimated
                                  </span>
                                )}
                              </td>

                              {/* Status Dropdown */}
                              <td className="py-3.5 px-4 align-middle whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center gap-2">
                                  <select 
                                    value={q.status}
                                    onChange={(e) => handleStatusChange(q.id, e.target.value as any)}
                                    className={`text-[11px] font-black uppercase tracking-wider rounded-xl px-2.5 py-1.5 border outline-none cursor-pointer transition-all shadow-sm ${badge.pill}`}
                                  >
                                    <option value="Pending" className="bg-slate-800 text-amber-300">Pending</option>
                                    <option value="Working On" className="bg-slate-800 text-sky-300">Working On</option>
                                    <option value="Approved" className="bg-slate-800 text-emerald-300">Approved</option>
                                    <option value="Remaining" className="bg-slate-800 text-rose-300">Remaining</option>
                                  </select>
                                </div>
                              </td>

                              {/* Quick Contact & Action Buttons */}
                              <td className="py-3.5 px-4 align-middle text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center justify-end gap-1.5">
                                  
                                  {/* 1-Click Share Complete PDF on WhatsApp */}
                                  <button 
                                    onClick={(e) => handleSharePDFToWhatsApp(q, 'admin', e)}
                                    className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-black text-[11px] transition-all border border-emerald-400/40 shadow-sm flex items-center gap-1.5 cursor-pointer"
                                    title="Share Complete Official PDF on WhatsApp"
                                  >
                                    <FileText className="w-3.5 h-3.5" />
                                    <span>WhatsApp PDF</span>
                                  </button>

                                  {/* WhatsApp to Client */}
                                  <button 
                                    onClick={(e) => handleSharePDFToWhatsApp(q, 'customer', e)}
                                    className="p-2 rounded-xl bg-teal-500/15 text-teal-400 hover:bg-teal-500 hover:text-slate-950 transition-all border border-teal-500/30 shadow-sm"
                                    title="Send Full PDF to Customer on WhatsApp"
                                  >
                                    <MessageSquare className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Forward Quote to Admin Email */}
                                  <button 
                                    onClick={(e) => openEmailModal(q, e)}
                                    className="p-2 rounded-xl bg-amber-500/15 text-amber-400 hover:bg-amber-500 hover:text-slate-950 transition-all border border-amber-500/30 shadow-sm"
                                    title="Email Dispatch Options"
                                  >
                                    <Mail className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Direct Call Link */}
                                  <a 
                                    href={`tel:${q.phone}`}
                                    className="p-2 rounded-xl bg-sky-500/15 text-sky-400 hover:bg-sky-500 hover:text-slate-950 transition-all border border-sky-500/30 shadow-sm inline-flex items-center justify-center"
                                    title="Call Customer Phone"
                                  >
                                    <Phone className="w-3.5 h-3.5" />
                                  </a>

                                  {/* View / Edit Details */}
                                  <button 
                                    onClick={() => setSelectedQuote(q)}
                                    className="p-2 rounded-xl bg-indigo-500/15 text-indigo-400 hover:bg-indigo-500 hover:text-white transition-all border border-indigo-500/30 shadow-sm"
                                    title="View & Edit Details"
                                  >
                                    <Eye className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Download PDF */}
                                  <button 
                                    onClick={() => downloadPDF(q)}
                                    className="p-2 rounded-xl bg-slate-700/60 text-slate-300 hover:bg-slate-600 hover:text-white transition-all border border-slate-600 shadow-sm"
                                    title="Download Single PDF"
                                  >
                                    <Download className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Delete Quote */}
                                  <button 
                                    onClick={(e) => deleteQuote(q.id, e)}
                                    className="p-2 rounded-xl bg-rose-500/15 text-rose-400 hover:bg-rose-500 hover:text-white transition-all border border-rose-500/30 shadow-sm"
                                    title="Delete Inquiry"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>

                                </div>
                              </td>

                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB 2: DEMAND ANALYTICS & REPORTS */}
          {activeTab === 'analytics' && (
            <div className="p-5 sm:p-8 space-y-6 overflow-y-auto">
              <div>
                <h2 className="text-xl font-black text-white tracking-wide uppercase flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-emerald-400" />
                  Industrial Demand Analytics & Pipeline Performance
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Overview of customer inquiries, equipment demand, conversion rates, and revenue potential.
                </p>
              </div>

              {/* Metric Highlights */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 shadow-lg">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-bold uppercase">
                    <span>Quotation Conversion Rate</span>
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-3xl font-black text-emerald-400 mt-2">
                    {stats.winRate}%
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    {stats.approved} deals approved out of {stats.total} total inquiries
                  </p>
                </div>

                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 shadow-lg">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-bold uppercase">
                    <span>Estimated Pipeline Revenue</span>
                    <DollarSign className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="text-3xl font-black text-amber-300 mt-2">
                    {formatINR(stats.totalPipelineValue)}
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Cumulative estimated value across all active RFQs
                  </p>
                </div>

                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 shadow-lg">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-bold uppercase">
                    <span>Pending Workload</span>
                    <Clock className="w-4 h-4 text-sky-400" />
                  </div>
                  <div className="text-3xl font-black text-sky-300 mt-2">
                    {stats.pending + stats.working}
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Inquiries actively requiring engineering quotation
                  </p>
                </div>
              </div>

              {/* Demand Category Breakdown */}
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-5">
                <h3 className="font-bold text-sm text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  Equipment & Service Demand Distribution
                </h3>

                <div className="space-y-4">
                  {Object.entries(categoryCounts).map(([cat, count]) => {
                    const numCount = Number(count);
                    const percent = stats.total > 0 ? Math.round((numCount / stats.total) * 100) : 0;
                    return (
                      <div key={cat} className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-slate-200">{cat}</span>
                          <span className="font-mono text-emerald-400 font-bold">{numCount} inquiries ({percent}%)</span>
                        </div>
                        <div className="w-full bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-700">
                          <div 
                            className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Status Breakdown Bar */}
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-4">
                <h3 className="font-bold text-sm text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-400" />
                  Pipeline Health Distribution
                </h3>

                <div className="w-full bg-slate-900 rounded-xl h-6 overflow-hidden flex border border-slate-700 p-0.5">
                  <div 
                    title={`Pending: ${stats.pending}`}
                    style={{ width: `${(stats.pending / (stats.total || 1)) * 100}%` }} 
                    className="bg-amber-500 h-full first:rounded-l-lg last:rounded-r-lg transition-all"
                  />
                  <div 
                    title={`Working On: ${stats.working}`}
                    style={{ width: `${(stats.working / (stats.total || 1)) * 100}%` }} 
                    className="bg-sky-500 h-full first:rounded-l-lg last:rounded-r-lg transition-all"
                  />
                  <div 
                    title={`Approved: ${stats.approved}`}
                    style={{ width: `${(stats.approved / (stats.total || 1)) * 100}%` }} 
                    className="bg-emerald-500 h-full first:rounded-l-lg last:rounded-r-lg transition-all"
                  />
                  <div 
                    title={`Remaining: ${stats.remaining}`}
                    style={{ width: `${(stats.remaining / (stats.total || 1)) * 100}%` }} 
                    className="bg-rose-500 h-full first:rounded-l-lg last:rounded-r-lg transition-all"
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-2">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                    <span className="text-slate-300">Pending ({stats.pending})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-sky-500"></span>
                    <span className="text-slate-300">Working On ({stats.working})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                    <span className="text-slate-300">Approved ({stats.approved})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-500"></span>
                    <span className="text-slate-300">Remaining ({stats.remaining})</span>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: SETTINGS & DATA MANAGEMENT */}
          {activeTab === 'settings' && (
            <div className="p-5 sm:p-8 space-y-6 max-w-2xl overflow-y-auto">
              <div>
                <h2 className="text-xl font-black text-white tracking-wide uppercase flex items-center gap-2">
                  <Settings className="w-5 h-5 text-amber-400" />
                  System Configuration & Data Backup
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Manage website client download rules, export corporate leads, and reset demo datasets.
                </p>
              </div>

              {/* Public Downloads Toggle */}
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 shadow-lg flex items-start gap-4">
                <div className="pt-0.5">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={settings.allowPublicDownloads}
                      onChange={handleToggleSettings}
                    />
                    <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Enable Public Machine Specifications PDF Download</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    When active, prospective clients can download technical equipment specs and catalogs directly from the website without registering.
                  </p>
                </div>
              </div>

              {/* WhatsApp Notification Setting */}
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 shadow-lg space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <MessageCircle className="w-4 h-4 text-emerald-400" />
                    My WhatsApp Number for Quotations & PDF Alerts
                  </h3>
                  {settingsSaveSuccess && (
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Saved!
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Enter your WhatsApp number with country code (e.g. <code>919162484535</code> or <code>918603683851</code>). Clicking "WhatsApp & PDF" on any inquiry will automatically download the official PDF quotation document and open your WhatsApp chat with all details formatted!
                </p>
                <div className="flex gap-2 max-w-md">
                  <input 
                    type="text"
                    value={adminWhatsAppInput}
                    onChange={(e) => setAdminWhatsAppInput(e.target.value)}
                    placeholder="e.g. 919162484535"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white font-mono outline-none focus:border-emerald-400"
                  />
                  <button 
                    onClick={() => {
                      const clean = adminWhatsAppInput.replace(/[^0-9]/g, '');
                      const updated = updateAdminSettings({ adminWhatsApp: clean });
                      setSettings(updated);
                      setSettingsSaveSuccess(true);
                      setTimeout(() => setSettingsSaveSuccess(false), 3000);
                    }}
                    className="bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs px-4 py-2 rounded-xl transition-all cursor-pointer shadow"
                  >
                    Save Number
                  </button>
                </div>
              </div>

              {/* Backup & Export Options */}
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 shadow-lg space-y-4">
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  Database Export & Cloud Backup Operations
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Safely export all quotation inquiries, client phone numbers, messages, and commercial values. You can export as CSV for Excel, as a PDF Master Report, or as a full JSON Database Backup file.
                </p>
                <div className="flex flex-wrap gap-3 pt-1">
                  <button 
                    onClick={() => exportQuotesToCSV(quotes)}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center gap-2 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" /> Export CSV Spreadsheet
                  </button>
                  <button 
                    onClick={() => exportQuotesToJSON(quotes)}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center gap-2 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" /> Export JSON Backup
                  </button>
                  <button 
                    onClick={downloadAllAsPDF}
                    className="bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center gap-2 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" /> Export Master PDF
                  </button>
                </div>

                {/* JSON Restore / Import */}
                <div className="pt-3 border-t border-slate-700/60">
                  <span className="text-xs font-bold text-slate-300 block mb-1.5">
                    Restore Database from JSON Backup File:
                  </span>
                  <label className="inline-flex items-center gap-2 bg-slate-900 border border-slate-700 hover:border-slate-500 px-3.5 py-2 rounded-xl text-xs text-slate-300 font-medium cursor-pointer transition-all">
                    <Upload className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Upload & Merge JSON Backup</span>
                    <input 
                      type="file" 
                      accept=".json" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            const content = event.target?.result as string;
                            if (content) {
                              const ok = importQuotesFromJSON(content);
                              if (ok) {
                                fetchQuotes();
                                setImportStatus('Database successfully restored and merged!');
                              } else {
                                setImportStatus('Invalid JSON backup file.');
                              }
                              setTimeout(() => setImportStatus(null), 4000);
                            }
                          };
                          reader.readAsText(file);
                        }
                      }}
                    />
                  </label>
                  {importStatus && (
                    <span className="ml-3 text-xs font-bold text-emerald-400">{importStatus}</span>
                  )}
                </div>
              </div>

              {/* Reset to Seed Corporate Data */}
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5 shadow-lg space-y-3">
                <h3 className="font-bold text-sm text-white flex items-center gap-2 text-rose-400">
                  <RefreshCw className="w-4 h-4" />
                  Restore Sample Corporate Records
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Populate demo leads from Tata Steel, SAIL Rourkela, Jindal Steel, and DPL to demonstrate full dashboard functionality.
                </p>
                <button 
                  onClick={handleResetData}
                  className="bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/40 font-bold text-xs px-4 py-2.5 rounded-xl transition-all cursor-pointer"
                >
                  Reset Demo Dataset
                </button>
              </div>

            </div>
          )}

        </main>
      </div>

      {/* DETAIL & EDIT MODAL */}
      {selectedQuote && (
        <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 no-print">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-3xl w-full shadow-2xl relative text-left flex flex-col max-h-[92vh] overflow-hidden text-slate-200">
            
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-800 bg-slate-850 flex justify-between items-center sticky top-0 z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-black text-emerald-300 bg-emerald-950 px-2.5 py-0.5 rounded-lg border border-emerald-500/40">
                      Sr. No. #{String(selectedQuote.serialNumber || 1).padStart(3, '0')}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-slate-300 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      Ref: #{selectedQuote.id}
                    </span>
                    <span className="text-xs font-bold text-slate-400">
                      • {new Date(selectedQuote.date).toLocaleString('en-IN')}
                    </span>
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-white mt-0.5">
                    {selectedQuote.companyName || selectedQuote.fullName}
                  </h3>
                </div>
              </div>

              <button 
                onClick={() => setSelectedQuote(null)}
                className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-6 overflow-y-auto space-y-6" id="print-section">
              
              {/* Contact & Status Highlights */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Client Profile */}
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 space-y-3">
                  <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" /> Client Information
                  </span>
                  <div>
                    <h4 className="font-black text-white text-base">{selectedQuote.fullName}</h4>
                    <p className="text-xs text-slate-400 font-semibold">{selectedQuote.companyName || 'Industrial Substation Representative'}</p>
                  </div>
                  <div className="space-y-2 pt-1 text-xs">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Phone className="w-3.5 h-3.5 text-sky-400" />
                      <a href={`tel:${selectedQuote.phone}`} className="hover:underline font-mono">{selectedQuote.phone}</a>
                    </div>
                    {selectedQuote.email && (
                      <div className="flex items-center gap-2 text-slate-300">
                        <Mail className="w-3.5 h-3.5 text-amber-400" />
                        <a href={`mailto:${selectedQuote.email}`} className="hover:underline">{selectedQuote.email}</a>
                      </div>
                    )}
                  </div>
                  
                  {/* Quick Action Buttons */}
                  <div className="pt-2 flex flex-wrap gap-2">
                    <button 
                      onClick={() => openWhatsApp(selectedQuote)}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 shadow transition-colors cursor-pointer"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      WhatsApp Client
                    </button>
                    <a 
                      href={`tel:${selectedQuote.phone}`}
                      className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 shadow transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      Call
                    </a>
                  </div>

                  {/* 1-Click Forward to Admin Email */}
                  <button 
                    onClick={() => openEmailModal(selectedQuote)}
                    className="w-full bg-amber-600/20 hover:bg-amber-600 text-amber-300 hover:text-white border border-amber-500/40 font-bold text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>Send / Forward to srpmeghapower11@gmail.com</span>
                  </button>
                </div>

                {/* Status & Deal Value */}
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 space-y-3">
                  <span className="text-[10px] font-black uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5" /> Commercial Status
                  </span>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Quotation Lifecycle Status
                    </label>
                    <select 
                      value={selectedQuote.status}
                      onChange={(e) => handleStatusChange(selectedQuote.id, e.target.value as any)}
                      className={`w-full text-xs font-black uppercase tracking-wider rounded-xl px-3 py-2 border outline-none cursor-pointer transition-all ${getStatusBadge(selectedQuote.status).pill}`}
                    >
                      <option value="Pending" className="bg-slate-800 text-amber-300">Pending Quotation</option>
                      <option value="Working On" className="bg-slate-800 text-sky-300">Working On Proposal</option>
                      <option value="Approved" className="bg-slate-800 text-emerald-300">Approved / PO Issued</option>
                      <option value="Remaining" className="bg-slate-800 text-rose-300">Remaining Follow-up</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Est. Deal Value (₹)
                      </label>
                      <input 
                        type="number"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value === '' ? '' : Number(e.target.value))}
                        placeholder="e.g. 850000"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-emerald-300 font-bold outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Priority Level
                      </label>
                      <select 
                        value={editPriority}
                        onChange={(e) => setEditPriority(e.target.value as any)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-bold outline-none focus:border-emerald-500 cursor-pointer"
                      >
                        <option value="Normal">Normal</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High (Urgent)</option>
                      </select>
                    </div>
                  </div>
                </div>

              </div>

              {/* Requirement Details */}
              <div className="bg-slate-850 border border-slate-700/80 rounded-2xl p-5 space-y-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                  <Briefcase className="w-3.5 h-3.5" /> Technical Scope & Inquired Equipment
                </span>
                <div className="bg-slate-900/90 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Product / Service</p>
                  <p className="text-sm font-black text-white mt-0.5">{selectedQuote.serviceOrProduct}</p>
                </div>
                {selectedQuote.quantityOrCapacity && (
                  <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Required Capacity</p>
                    <p className="text-xs font-bold text-slate-200 mt-0.5">{selectedQuote.quantityOrCapacity}</p>
                  </div>
                )}
                <div className="bg-slate-900/90 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Customer Message / Specifications</p>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed italic">
                    "{selectedQuote.message || 'No additional specifications supplied.'}"
                  </p>
                </div>
              </div>

              {/* Internal Notes & Follow-up Log */}
              <div className="bg-slate-850 border border-slate-700/80 rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5" /> Internal Follow-up Notes & Dispatch Log
                  </span>
                  {saveSuccessMsg && (
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Saved to Database!
                    </span>
                  )}
                </div>
                <textarea 
                  rows={3}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="Record call discussions, techno-commercial quote sent date, mobilization plan, customer feedback..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none focus:border-amber-400"
                />
                <button 
                  onClick={handleSaveModalDetails}
                  disabled={isSavingDetails}
                  className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Check className="w-4 h-4" />
                  {isSavingDetails ? 'Saving...' : 'Save Notes & Commercial Details'}
                </button>
              </div>

              {/* Footer Actions */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800 no-print">
                <div className="flex flex-wrap items-center gap-2">
                  <button 
                    onClick={() => handleSharePDFToWhatsApp(selectedQuote, 'admin')}
                    className="bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-black text-xs py-2 px-3.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-md"
                  >
                    <FileText className="w-3.5 h-3.5 fill-slate-950" />
                    Share Full PDF on WhatsApp
                  </button>
                  <button 
                    onClick={() => handleSharePDFToWhatsApp(selectedQuote, 'customer')}
                    className="bg-teal-500/20 hover:bg-teal-500 text-teal-300 hover:text-slate-950 border border-teal-500/30 font-bold text-xs py-2 px-3.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    Send PDF to Client
                  </button>
                  <button 
                    onClick={() => openEmailModal(selectedQuote)}
                    className="bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 border border-amber-500/30 font-bold text-xs py-2 px-3.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    Email
                  </button>
                  <button 
                    onClick={() => downloadPDF(selectedQuote)}
                    className="bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs py-2 px-3.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-400" />
                    Download PDF
                  </button>
                  <button 
                    onClick={printQuote}
                    className="bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs py-2 px-3.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-sky-400" />
                    Print
                  </button>
                </div>

                <button 
                  onClick={() => deleteQuote(selectedQuote.id)}
                  className="bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 font-bold text-xs py-2 px-3.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete Inquiry
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* CREATE DIRECT LEAD MODAL */}
      {isAddLeadOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-xl w-full shadow-2xl relative text-left flex flex-col max-h-[92vh] overflow-hidden text-slate-200">
            
            <div className="px-6 py-4 border-b border-slate-800 bg-slate-850 flex justify-between items-center sticky top-0 z-10">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Log Direct Quotation / Lead</h3>
                  <p className="text-xs text-slate-400">Record inquiries received via Phone, WhatsApp, or Walk-in.</p>
                </div>
              </div>
              <button 
                onClick={() => setIsAddLeadOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateLead} className="p-6 overflow-y-auto space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Client Full Name *
                  </label>
                  <input 
                    type="text"
                    required
                    value={newLead.fullName}
                    onChange={(e) => setNewLead({ ...newLead, fullName: e.target.value })}
                    placeholder="e.g. Ramesh Chandra"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Company / Substation
                  </label>
                  <input 
                    type="text"
                    value={newLead.companyName}
                    onChange={(e) => setNewLead({ ...newLead, companyName: e.target.value })}
                    placeholder="e.g. SAIL Rourkela / JUSCO"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Phone Number *
                  </label>
                  <input 
                    type="tel"
                    required
                    value={newLead.phone}
                    onChange={(e) => setNewLead({ ...newLead, phone: e.target.value })}
                    placeholder="+91 94311 00000"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Email Address
                  </label>
                  <input 
                    type="email"
                    value={newLead.email}
                    onChange={(e) => setNewLead({ ...newLead, email: e.target.value })}
                    placeholder="client@company.com"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Product or Service Requested *
                </label>
                <select
                  value={newLead.serviceOrProduct}
                  onChange={(e) => setNewLead({ ...newLead, serviceOrProduct: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500 cursor-pointer"
                >
                  <option value="10,000 LPH High Vacuum Transformer Oil Filtration Machine (Max Capacity)">10,000 LPH High Vacuum Oil Filtration Machine (Max Capacity)</option>
                  <option value="6,000 LPH Mobile Trailer Oil Dehydration Machine">6,000 LPH Mobile Trailer Filtration Machine</option>
                  <option value="5,000 LPH High Vacuum Oil Filtration Machine">5,000 LPH High Vacuum Oil Filtration Machine</option>
                  <option value="1,000 to 3,000 LPH Compact Substation Filtration Unit">1,000 to 3,000 LPH Compact Substation Unit</option>
                  <option value="Heavy Industrial Centrifugal Blower (High CFM)">Heavy Industrial Centrifugal Blower</option>
                  <option value="Substation Transformer Oil Filtration & BDV Testing Service">Substation Oil Filtration & BDV Testing Service</option>
                  <option value="Transformer Rewinding & Overhauling (Up to 132kV)">Transformer Rewinding & Overhauling</option>
                  <option value="Hot Oil Circulation & Moisture Extraction">Hot Oil Circulation & Moisture Extraction</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Lead Source
                  </label>
                  <select
                    value={newLead.source}
                    onChange={(e) => setNewLead({ ...newLead, source: e.target.value as any })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-2 text-xs text-white outline-none"
                  >
                    <option value="Direct Call">Direct Call</option>
                    <option value="WhatsApp">WhatsApp</option>
                    <option value="Walk-in Workshop">Walk-in Workshop</option>
                    <option value="Website RFQ">Website RFQ</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Priority
                  </label>
                  <select
                    value={newLead.priority}
                    onChange={(e) => setNewLead({ ...newLead, priority: e.target.value as any })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-2 text-xs text-white outline-none"
                  >
                    <option value="Normal">Normal</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Est. Value (₹)
                  </label>
                  <input 
                    type="number"
                    value={newLead.estimatedValue}
                    onChange={(e) => setNewLead({ ...newLead, estimatedValue: e.target.value })}
                    placeholder="e.g. 500000"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-2 text-xs text-white outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Scope & Customer Requirements Note
                </label>
                <textarea 
                  rows={3}
                  value={newLead.message}
                  onChange={(e) => setNewLead({ ...newLead, message: e.target.value })}
                  placeholder="Details of transformer capacity, required flow rate, delivery timeframe, site address..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddLeadOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition-colors cursor-pointer"
                >
                  Save Lead to Pipeline
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* WHATSAPP COMPLETE PDF DISPATCH MODAL */}
      {whatsAppPDFModalQuote && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[130] flex items-center justify-center p-3 sm:p-5 no-print animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden text-left text-slate-200 flex flex-col max-h-[92vh]">
            
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-800 bg-slate-850 flex justify-between items-center sticky top-0 z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <FileText className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    WhatsApp Full PDF Share
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      Sr. #{String(whatsAppPDFModalQuote.serialNumber || 1).padStart(3, '0')}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">Share complete PDF quotation document on WhatsApp</p>
                </div>
              </div>
              <button 
                onClick={() => setWhatsAppPDFModalQuote(null)}
                className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto space-y-4">
              
              {/* Notification Banner */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-200 space-y-1">
                <div className="flex items-center gap-2 font-bold text-xs text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Official PDF Document Generated & Downloaded!</span>
                </div>
                <p className="text-[11px] text-emerald-300/80 font-mono break-all">
                  📄 {getQuotePDFFilename(whatsAppPDFModalQuote)}
                </p>
              </div>

              {/* Recipient Selection Toggle */}
              <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-3 flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-300">Send To:</span>
                <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-700">
                  <button
                    onClick={() => setWhatsAppModalTarget('admin')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      whatsAppModalTarget === 'admin'
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Admin (+91 {settings.adminWhatsApp || '9162484535'})
                  </button>
                  <button
                    onClick={() => setWhatsAppModalTarget('customer')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      whatsAppModalTarget === 'customer'
                        ? 'bg-teal-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Client ({whatsAppPDFModalQuote.fullName})
                  </button>
                </div>
              </div>

              {/* Inquiry Snapshot */}
              <div className="bg-slate-850 border border-slate-700/80 rounded-2xl p-4 space-y-2 text-xs">
                <div className="flex justify-between items-center text-slate-400 border-b border-slate-800 pb-2">
                  <span>Serial & Reference:</span>
                  <span className="font-mono font-bold text-emerald-400">
                    Sr. #{String(whatsAppPDFModalQuote.serialNumber || 1).padStart(3, '0')} ({whatsAppPDFModalQuote.id})
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-400">
                  <span>Client / Company:</span>
                  <span className="font-bold text-white text-right">
                    {whatsAppPDFModalQuote.fullName} {whatsAppPDFModalQuote.companyName ? `(${whatsAppPDFModalQuote.companyName})` : ''}
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-400">
                  <span>Inquired Scope:</span>
                  <span className="font-bold text-slate-200 text-right">{whatsAppPDFModalQuote.serviceOrProduct}</span>
                </div>
              </div>

              {/* Primary Direct Native File Share Button */}
              <button
                onClick={async () => {
                  const res = await tryNativeFileShare(whatsAppPDFModalQuote);
                  if (res.sharedNative) {
                    setShareSuccessNotice('PDF document opened in native share menu! Select WhatsApp to send.');
                  } else {
                    // Open chat directly with instructions
                    openWhatsAppChatWithInstructions();
                  }
                }}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-slate-950 font-black text-xs shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <FileText className="w-4 h-4 fill-slate-950" />
                <span>📲 Share Full PDF Directly on WhatsApp (Mobile / Native)</span>
              </button>

              {shareSuccessNotice && (
                <div className="p-2.5 bg-emerald-950 border border-emerald-500/50 text-emerald-300 text-xs rounded-xl text-center font-bold">
                  {shareSuccessNotice}
                </div>
              )}

              {/* Web / Desktop Send Guide & Chat Opener */}
              <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    WhatsApp Web / PC Direct Chat:
                  </span>
                  <button
                    onClick={() => openWhatsAppChatWithInstructions()}
                    className="px-3.5 py-1.5 bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white rounded-xl text-xs font-bold transition-colors cursor-pointer border border-emerald-500/40 flex items-center gap-1"
                  >
                    <span>Open WhatsApp Chat</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
                
                <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 text-[11px] text-slate-300 space-y-1.5 leading-relaxed">
                  <p className="font-bold text-amber-400 flex items-center gap-1">
                    <span>💡 WhatsApp Web में पूरा PDF भेजने के 3 आसान कदम:</span>
                  </p>
                  <p>1. <strong>PDF डाउनलोड:</strong> आधिकारिक PDF फ़ाइल आपके कंप्यूटर/फ़ोन में डाउनलोड हो चुकी है।</p>
                  <p>2. <strong>चैट खोलें:</strong> ऊपर <strong>'Open WhatsApp Chat'</strong> बटन दबाएं।</p>
                  <p>3. <strong>PDF अटैच करें:</strong> चैट में नीचे <strong>Paperclip 📎 (Attachment) ➔ 'Document' (दस्तावेज़)</strong> पर क्लिक करके डाउनलोड की गई PDF फ़ाइल भेजें।</p>
                </div>
              </div>

              {/* Quick Action Buttons: Download Again & Preview Full PDF */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => downloadQuotePDFFile(whatsAppPDFModalQuote)}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download PDF Again</span>
                </button>
                <button
                  onClick={() => {
                    const { blob } = getQuotePDFObjects(whatsAppPDFModalQuote);
                    const url = URL.createObjectURL(blob);
                    window.open(url, '_blank');
                  }}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                  <span>View Full PDF</span>
                </button>
              </div>

            </div>

            <div className="px-6 py-3 border-t border-slate-800 bg-slate-850 flex justify-end">
              <button 
                onClick={() => setWhatsAppPDFModalQuote(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* EMAIL FORWARDING & DISPATCH MODAL */}
      {emailModalQuote && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[120] flex items-center justify-center p-3 sm:p-5 no-print">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden text-left text-slate-200 flex flex-col max-h-[92vh]">
            
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-800 bg-slate-850 flex justify-between items-center sticky top-0 z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Send Quotation to Admin Email</h3>
                  <p className="text-xs text-slate-400">Target: <span className="text-amber-300 font-semibold">srpmeghapower11@gmail.com &amp; riteshkr43jsr@gmail.com</span></p>
                </div>
              </div>
              <button 
                onClick={() => setEmailModalQuote(null)}
                className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5">
              {/* Summary Card */}
              <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700/80 space-y-2 text-xs">
                <div className="flex justify-between items-center border-b border-slate-700 pb-2">
                  <span className="font-mono font-bold text-amber-400">#{emailModalQuote.id}</span>
                  <span className="text-slate-400">{new Date(emailModalQuote.date).toLocaleDateString()}</span>
                </div>
                <div className="text-slate-300">
                  <strong className="text-white">{emailModalQuote.fullName}</strong> {emailModalQuote.companyName ? `(${emailModalQuote.companyName})` : ''}
                </div>
                <div className="text-slate-400">
                  Phone: <strong className="text-slate-200">{emailModalQuote.phone}</strong> | Email: <strong className="text-slate-200">{emailModalQuote.email || 'N/A'}</strong>
                </div>
                <div className="text-emerald-400 font-medium">
                  {emailModalQuote.serviceOrProduct}
                </div>
              </div>

              {/* Status Message if Dispatched */}
              {emailResult && (
                <div className={`p-3.5 rounded-2xl text-xs font-medium border flex items-start gap-2.5 ${
                  emailResult.success 
                    ? 'bg-emerald-950/80 border-emerald-600 text-emerald-200' 
                    : 'bg-amber-950/80 border-amber-600 text-amber-200'
                }`}>
                  {emailResult.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <strong className="block">{emailResult.success ? 'Notification Sent!' : 'Activation Note:'}</strong>
                    <span>{emailResult.message}</span>
                  </div>
                </div>
              )}

              {/* Action options */}
              <div className="space-y-2.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                  Select Dispatch Method:
                </span>

                {/* Primary: Send to My WhatsApp & Download PDF */}
                <button 
                  onClick={() => {
                    sendQuoteToAdminWhatsApp(emailModalQuote);
                  }}
                  className="w-full bg-[#25D366] hover:bg-[#1fb855] text-slate-950 font-black text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4 fill-current" />
                  <span>Send to My WhatsApp & Download Quotation PDF</span>
                </button>

                <button 
                  onClick={handleSendViaFormSubmit}
                  disabled={emailSending}
                  className="w-full bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{emailSending ? 'Dispatching to Gmail...' : 'Send Cloud Email Alert to srpmeghapower11@gmail.com'}</span>
                </button>

                <button 
                  onClick={handleOpenGmailWeb}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4 text-rose-400" />
                  <span>2. Open in Gmail Web (Pre-composed 1-Click Send)</span>
                </button>

                <button 
                  onClick={handleCopyEmailText}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Copy className="w-4 h-4 text-sky-400" />
                  <span>{copiedNotification ? '✓ Copied to Clipboard!' : '3. Copy Formatted Inquiry Text'}</span>
                </button>

                <button 
                  onClick={handleOpenMailto}
                  className="w-full text-slate-400 hover:text-slate-200 text-[11px] py-1 transition-colors text-center block"
                >
                  Or click here to open in Desktop Mail App (mailto)
                </button>
              </div>

            </div>

            <div className="px-6 py-3 border-t border-slate-800 bg-slate-850 flex justify-end">
              <button 
                onClick={() => setEmailModalQuote(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {quoteToDelete && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[120] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden p-6 text-center text-slate-200">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-1.5">Delete Inquiry Record?</h3>
            <p className="text-xs text-slate-400 mb-5 leading-relaxed">
              Are you sure you want to permanently remove this inquiry from your database? This action cannot be reversed.
            </p>
            
            {deleteError && (
              <div className="mb-4 p-2.5 bg-rose-950/80 border border-rose-800 text-rose-300 text-xs rounded-xl">
                {deleteError}
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => setQuoteToDelete(null)}
                disabled={isDeleting}
                className="flex-1 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                disabled={isDeleting}
                className="flex-1 px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold text-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Delete Permanently'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
