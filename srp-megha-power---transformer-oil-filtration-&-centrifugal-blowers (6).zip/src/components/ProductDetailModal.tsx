import React from 'react';
import { X, CheckCircle2, ArrowRight, ShieldCheck, Droplet, Wind, FileText } from 'lucide-react';
import { ProductItem } from '../types';

interface ProductDetailModalProps {
  product: ProductItem | null;
  onClose: () => void;
  onOpenQuote: (productName: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose, onOpenQuote }) => {
  if (!product) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative border border-[#DDE5DC] text-left">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 bg-gray-100 hover:bg-gray-200 text-gray-700 p-2 rounded-full transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-6 sm:p-8">
          
          {/* Product Image / Spec Badge Column */}
          <div className="md:col-span-5 space-y-4">
            {product.category === 'filtration' || !product.image ? (
              <div className="relative rounded-xl overflow-hidden bg-gradient-to-br from-[#0D3F18] via-[#185C20] to-[#0B1E38] border border-emerald-700/50 p-6 h-56 md:h-64 flex flex-col justify-between text-white shadow-md">
                <div className="flex items-center justify-between">
                  <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300">
                    {product.category === 'blower' ? (
                      <Wind className="w-8 h-8 text-emerald-400" />
                    ) : (
                      <Droplet className="w-8 h-8 text-emerald-400" />
                    )}
                  </div>
                  {product.badge && (
                    <span className="bg-emerald-500/30 text-emerald-200 border border-emerald-400/40 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                      {product.badge}
                    </span>
                  )}
                </div>
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-emerald-300 block mb-1">
                    B2B HEAVY INDUSTRIAL EQUIPMENT
                  </span>
                  <h4 className="text-lg font-black tracking-tight text-white leading-snug">
                    {product.name}
                  </h4>
                  {product.capacity && (
                    <p className="text-xs font-extrabold text-emerald-200 mt-1">
                      Capacity: {product.capacity}
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <div className="relative rounded-xl overflow-hidden bg-gray-100 border border-[#DDE5DC] h-56 md:h-64">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                {product.badge && (
                  <span className="absolute top-3 left-3 bg-[#185C20] text-white text-[10px] font-bold px-2.5 py-1 rounded shadow-xs uppercase">
                    {product.badge}
                  </span>
                )}
              </div>
            )}

            <div className="p-3 bg-[#F7F9F6] rounded-xl border border-[#DDE5DC] space-y-1 text-xs">
              <span className="text-gray-500 font-medium block">Category:</span>
              <strong className="text-[#101A24] capitalize font-bold">
                {product.category === 'filtration' ? 'Transformer Oil Filtration Machine' : `Centrifugal Blower (${product.subcategory || 'Heavy Duty'})`}
              </strong>
            </div>
          </div>

          {/* Product Info Column */}
          <div className="md:col-span-7 space-y-5">
            <div>
              {product.capacity && (
                <span className="text-xs font-bold text-[#4D9B2A] uppercase tracking-wider block mb-1">
                  Capacity: {product.capacity}
                </span>
              )}
              <h3 className="text-xl sm:text-2xl font-extrabold text-[#101A24]">
                {product.name}
              </h3>
            </div>

            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
              {product.fullDesc || product.shortDesc}
            </p>

            {/* Technical Specifications */}
            <div>
              <h4 className="font-extrabold text-xs uppercase tracking-wider text-[#185C20] mb-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#4D9B2A]" />
                Key Technical Specifications
              </h4>
              <ul className="grid grid-cols-1 gap-1.5 text-xs text-gray-700 bg-[#F7F9F6] p-3 rounded-xl border border-[#DDE5DC]">
                {product.specs.map((spec, sIdx) => (
                  <li key={sIdx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#4D9B2A] mt-1.5 shrink-0" />
                    <span>{spec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Applications */}
            {product.applications && product.applications.length > 0 && (
              <div>
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-[#101A24] mb-2">
                  Target Industrial Applications
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {product.applications.map((app, aIdx) => (
                    <span key={aIdx} className="bg-[#EAF4E6] text-[#185C20] text-[11px] font-bold px-2.5 py-1 rounded">
                      {app}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="pt-2 flex gap-3">
              <button 
                onClick={() => {
                  onClose();
                  onOpenQuote(product.name);
                }}
                className="w-full bg-[#185C20] hover:bg-[#0D3F18] text-white py-3 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                <span>REQUEST PRICE & RFQ QUOTE</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
