import React, { useState } from 'react';
import { ShieldCheck, Pause, Play, ChevronsRight, Building2 } from 'lucide-react';
import { CLIENT_LOGOS } from '../data/companyData';
import { ClientLogo } from '../types';

/**
 * Component that renders the authentic corporate visual logo image or SVG
 */
const OfficialCompanyLogo: React.FC<{ client: ClientLogo }> = ({ client }) => {
  const [imgError, setImgError] = useState(false);

  // If logoUrl is available and image hasn't errored, render actual logo image
  if (client.logoUrl && !imgError) {
    return (
      <div className="h-12 flex items-center justify-center p-1 max-w-[180px]">
        <img 
          src={client.logoUrl} 
          alt={`${client.name} Official Logo`}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="max-h-10 max-w-full object-contain filter drop-shadow-xs group-hover:scale-105 transition-transform duration-200"
        />
      </div>
    );
  }

  // Exact Vector SVG Renderers for each company as fallback / direct graphic
  switch (client.logoType) {
    case 'tata-steel':
    case 'tata-motors':
    case 'tata-metaliks':
    case 'tinplate':
    case 'tata-growth':
    case 'iswp':
      return (
        <div className="flex items-center gap-2 h-10">
          {/* Authentic Tata Group Blue Oval & T Emblem */}
          <div className="w-8 h-8 rounded-full bg-[#00529C] flex items-center justify-center text-white shrink-0 shadow-xs">
            <svg className="w-5 h-5 fill-current text-white" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15h-2V9H5V7h10v2h-4v8zm7 0h-2V7h2v10z" />
            </svg>
          </div>
          <span className="font-black text-sm tracking-tight text-[#00529C] uppercase">
            {client.logoText}
          </span>
        </div>
      );

    case 'sail':
      return (
        <div className="flex items-center gap-2 h-10">
          {/* Authentic SAIL Logo Emblem */}
          <div className="w-9 h-8 bg-[#002B49] rounded flex items-center justify-center p-1 shrink-0">
            <svg className="w-full h-full" viewBox="0 0 40 30" fill="none">
              <path d="M5 22L18 8H25L12 22H5Z" fill="#2563EB" />
              <path d="M15 8L28 22H35L22 8H15Z" fill="#1D4ED8" />
              <circle cx="20" cy="15" r="4" fill="#E31837" />
            </svg>
          </div>
          <span className="font-black text-sm tracking-tight text-[#002B49]">
            SAIL
          </span>
        </div>
      );

    case 'timken':
      return (
        <div className="flex items-center gap-2 h-10">
          <span className="font-black text-lg tracking-wider text-[#E31837] font-serif uppercase">
            TIMKEN
          </span>
        </div>
      );

    case 'rungta':
      return (
        <div className="flex items-center gap-2 h-10">
          <div className="w-7 h-7 bg-[#C8102E] rounded flex items-center justify-center text-white font-black text-xs">
            R
          </div>
          <span className="font-black text-sm text-[#C8102E] tracking-tight uppercase">
            RUNGTA STEEL
          </span>
        </div>
      );

    case 'usha-martin':
      return (
        <div className="flex items-center gap-2.5 h-10">
          {/* Authentic Usha Martin ORANGE Side Crest */}
          <div className="w-9 h-9 bg-gradient-to-br from-[#FF5B00] to-[#D94800] rounded-lg flex items-center justify-center p-1 shrink-0 shadow-xs border border-orange-300/40">
            <svg className="w-full h-full" viewBox="0 0 32 32" fill="none">
              <path d="M16 2L30 16L16 30L2 16L16 2Z" fill="#FF5B00" stroke="#FFE8D6" strokeWidth="1.5" />
              <path d="M16 7L24 16L16 25L8 16L16 7Z" fill="#FFFFFF" />
              <path d="M16 11L20 16L16 21L12 16L16 11Z" fill="#FF5B00" />
            </svg>
          </div>
          <span className="font-black text-sm tracking-tight text-[#FF5B00] uppercase font-sans">
            USHA MARTIN
          </span>
        </div>
      );

    case 'linde':
      return (
        <div className="flex items-center gap-2.5 h-10">
          {/* Authentic Linde BLUE ROUND Circular Emblem */}
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#005596] to-[#003865] flex items-center justify-center p-1.5 shrink-0 shadow-xs border-2 border-sky-300/40">
            <svg className="w-full h-full" viewBox="0 0 32 32" fill="none">
              <path d="M4 22C12 8 22 8 28 22" stroke="#38BDF8" strokeWidth="3" strokeLinecap="round" />
              <path d="M7 24C13 13 21 13 25 24" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </div>
          <span className="font-black text-base tracking-wider text-[#005596] italic uppercase font-sans">
            LINDE
          </span>
        </div>
      );

    default:
      return (
        <div className="flex items-center gap-2 h-10">
          <Building2 className="w-6 h-6 text-[#185C20]" />
          <span className="font-black text-sm text-[#101A24]">{client.name}</span>
        </div>
      );
  }
};

export const ClientsCarousel: React.FC = () => {
  const [isPaused, setIsPaused] = useState(false);

  // Duplicate client logos array to create continuous infinite marquee
  const doubleLogos = [...CLIENT_LOGOS, ...CLIENT_LOGOS];

  return (
    <section id="clients" className="py-14 bg-gradient-to-b from-white via-[#F7F9F6] to-white border-b border-[#DDE5DC] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6">
        
        {/* Section Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#EAF4E6] text-[#185C20] font-black text-xs uppercase tracking-wider mb-2 border border-[#4D9B2A]/30">
              <ShieldCheck className="w-4 h-4 text-[#4D9B2A]" />
              TRUSTED INDUSTRIAL PARTNERS
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-[#101A24] tracking-tight">
              OUR CLIENTS & PARTNERS
            </h2>
          </div>

          {/* Interactive Controls */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-[#EAF4E6] text-[#185C20] px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-[#4D9B2A] animate-ping" />
              <span>CONTINUOUS FORWARD MOTION</span>
              <ChevronsRight className="w-4 h-4 animate-forward-arrow" />
            </div>

            <button 
              onClick={() => setIsPaused(!isPaused)}
              className="p-2 rounded-xl border border-[#DDE5DC] bg-white hover:bg-[#EAF4E6] hover:border-[#185C20] text-gray-700 transition-colors shadow-2xs flex items-center gap-1.5 text-xs font-bold"
              title={isPaused ? "Resume Continuous Motion" : "Pause Motion"}
            >
              {isPaused ? (
                <>
                  <Play className="w-4 h-4 text-[#185C20] fill-current" />
                  <span className="hidden sm:inline">RESUME</span>
                </>
              ) : (
                <>
                  <Pause className="w-4 h-4 text-[#185C20] fill-current" />
                  <span className="hidden sm:inline">PAUSE</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>

      {/* CONTINUOUS FORWARD-MOVING RIBBON */}
      <div className="relative w-full overflow-hidden py-4 bg-[#F7F9F6]/80 border-y border-[#DDE5DC]">
        
        {/* Side Gradient Fade Masks */}
        <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-28 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-28 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />

        <div className={`flex items-center gap-6 ${isPaused ? '' : 'animate-marquee-forward'}`}>
          {doubleLogos.map((client, idx) => (
            <div 
              key={idx}
              className="bg-white border-2 border-[#DDE5DC] hover:border-[#185C20] rounded-2xl p-4 sm:p-5 flex flex-col items-center justify-between text-center w-56 sm:w-64 h-36 shrink-0 shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-pointer relative overflow-hidden"
            >
              {/* Top Accent Color Bar */}
              <div 
                className="absolute top-0 left-0 right-0 h-1.5 transition-all duration-300 group-hover:h-2"
                style={{ backgroundColor: client.color || '#185C20' }}
              />

              {/* 1. OFFICIAL LOGO IMAGE / SVG MARK (TOP) */}
              <div className="pt-1 flex items-center justify-center h-14">
                <OfficialCompanyLogo client={client} />
              </div>

              {/* 2. COMPANY NAME & SUBTITLE (BELOW) */}
              <div className="w-full pt-1.5 pb-1 border-t border-gray-100">
                <h4 className="font-black text-sm text-[#101A24] tracking-tight group-hover:text-[#185C20] transition-colors line-clamp-1 uppercase">
                  {client.name}
                </h4>
                <p className="text-[11px] text-gray-500 font-bold line-clamp-1">
                  {client.subtitle}
                </p>
              </div>

              {/* Verified Partner Badge */}
              <div className="text-[9px] font-black uppercase tracking-wider text-[#185C20] bg-[#EAF4E6] px-2.5 py-0.5 rounded-full">
                APPROVED CLIENT
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
