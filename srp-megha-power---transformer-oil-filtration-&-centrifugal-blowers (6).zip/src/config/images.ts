import heavyDutyBlowerImg from '../assets/images/heavy_duty_blower_1786959069275.jpg';
import backwardCurvedBlowerImg from '../assets/images/backward_curved_blower_1786959083750.jpg';
import forwardCurvedBlowerImg from '../assets/images/forward_curved_blower_1786959095549.jpg';
import radialBladeBlowerImg from '../assets/images/radial_blade_blower_1786959109619.jpg';
import airfoilBladeBlowerImg from '../assets/images/airfoil_blade_blower_1786959120419.jpg';
import premiumFiltrationMachineImg from '../assets/images/truck_mounted_filtration_1786959930975.jpg';

/**
 * SRP MEGHA POWER - IMAGE ASSETS CONFIGURATION
 */
export const SITE_IMAGES = {
  // 5 Blower Type Photos
  heavyDutyBlower: heavyDutyBlowerImg,
  backwardCurvedBlower: backwardCurvedBlowerImg,
  forwardCurvedBlower: forwardCurvedBlowerImg,
  radialBladeBlower: radialBladeBlowerImg,
  airfoilBladeBlower: airfoilBladeBlowerImg,
  
  // Hero Filtration Machine Photo
  premiumFiltrationMachine: premiumFiltrationMachineImg,

  // Default fallback
  centrifugalBlower: heavyDutyBlowerImg,
};
