import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SavedQuote } from './storage';

export interface PDFFileResult {
  doc: jsPDF;
  blob: Blob;
  file: File;
  filename: string;
}

/**
 * Generates an official, high-resolution Commercial & Technical Quotation PDF
 * for SRP Megha Power with Serial Number and full technical breakdown.
 */
export const generateCompleteQuotePDF = (quote: SavedQuote): jsPDF => {
  const doc = new jsPDF();
  const serialText = String(quote.serialNumber || 1).padStart(3, '0');

  // Primary Header Banner (Dark Forest Green)
  doc.setFillColor(15, 60, 24); // #0F3C18
  doc.rect(0, 0, 210, 32, 'F');

  // Secondary Accent Line (Gold / Emerald)
  doc.setFillColor(77, 155, 42); // #4D9B2A
  doc.rect(0, 32, 210, 2, 'F');

  // Header Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('SRP MEGHA POWER - OFFICIAL QUOTATION INQUIRY', 14, 14);

  // Header Subtitle & Details
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(220, 245, 220);
  doc.text('Trusted for Power Quality and Reliability | ISO 9001:2015 Certified', 14, 20);
  doc.text('Office: 1st Floor, New Kalimati Road, Near Chandra Hotel, P.O. & P.S. Sakchi, Jamshedpur - 831001', 14, 25.5);
  doc.text('Call: +91 86036 83851 | WhatsApp: +91 91624 84535 | Email: srpmeghapower11@gmail.com', 14, 30);

  // Meta Section: Serial Number & Reference Badge
  doc.setFillColor(245, 249, 246);
  doc.rect(14, 38, 182, 22, 'F');
  doc.setDrawColor(200, 225, 205);
  doc.rect(14, 38, 182, 22, 'S');

  // Serial Number (Left)
  doc.setTextColor(15, 60, 24);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(`SERIAL NO:  #${serialText}`, 20, 48);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(70, 80, 75);
  doc.text(`Reference ID: ${quote.id}`, 20, 54);

  // Date & Status (Right)
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text(`Date Logged: ${new Date(quote.date).toLocaleString('en-IN')}`, 115, 48);

  doc.setFont('helvetica', 'normal');
  const estVal = quote.estimatedValue ? `₹${quote.estimatedValue.toLocaleString('en-IN')}` : 'To Be Estimated';
  doc.text(`Status: ${quote.status}   |   Est. Value: ${estVal}`, 115, 54);

  // Main Structured Table
  autoTable(doc, {
    startY: 65,
    head: [['Section / Parameter', 'Technical & Commercial Specification Details']],
    body: [
      ['Enquiry Serial Number', `Serial #${serialText} (Sequential ERP Order)`],
      ['Quotation Reference ID', quote.id],
      ['Customer Full Name', quote.fullName],
      ['Company / Substation', quote.companyName || 'Industrial Client (Individual / Walk-in)'],
      ['Direct Contact Phone', quote.phone],
      ['Official Email Address', quote.email || 'N/A'],
      ['Inquired Product / Service', quote.serviceOrProduct],
      ['Capacity / Scope', quote.quantityOrCapacity || 'Industrial Standard Specification'],
      ['Inquiry Source', quote.source || 'Website RFQ Portal'],
      ['Priority Level', quote.priority || 'Normal'],
      ['Customer Requirements / Note', quote.message || 'No additional note provided'],
      ['Commercial Value (INR)', estVal],
      ['Internal ERP / Follow-up Log', quote.notes || 'None logged yet']
    ],
    theme: 'grid',
    headStyles: {
      fillColor: [15, 60, 24],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 10
    },
    styles: {
      fontSize: 9,
      cellPadding: 4.5,
      textColor: [30, 41, 59],
      lineColor: [215, 225, 220]
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 55, fillColor: [248, 250, 248] },
      1: { cellWidth: 127 }
    }
  });

  // Verification & Signatory Box
  const finalY = (doc as any).lastAutoTable?.finalY || 200;
  const boxY = Math.min(finalY + 8, 245);

  doc.setFillColor(250, 252, 250);
  doc.rect(14, boxY, 182, 28, 'F');
  doc.setDrawColor(210, 225, 215);
  doc.rect(14, boxY, 182, 28, 'S');

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 60, 24);
  doc.text('SRP MEGHA POWER - COMMERCIAL & ENGINEERING DESK', 20, boxY + 7);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 95, 85);
  doc.text('This is an authentic commercial quotation dossier generated directly from the SRP Megha Power ERP system.', 20, boxY + 13);
  doc.text('Office: 1st Floor, New Kalimati Road, Near Chandra Hotel, Sakchi, Jamshedpur, East Singhbhum, Jharkhand - 831001', 20, boxY + 18);
  doc.text('Direct Helpdesk: +91 86036 83851 / +91 91624 84535 | Email: srpmeghapower11@gmail.com', 20, boxY + 23);

  // Footer Note
  doc.setFontSize(7.5);
  doc.setTextColor(120, 135, 125);
  doc.text(
    `Official ERP Record • Serial #${serialText} • Reference ID: ${quote.id} • Generated: ${new Date().toLocaleString('en-IN')}`,
    14,
    286
  );
  doc.text('Confidential - SRP Megha Power Jamshedpur Corporate Commercial Records', 14, 290);

  return doc;
};

/**
 * Gets a clean filename for the quotation PDF
 */
export const getQuotePDFFilename = (quote: SavedQuote): string => {
  const serialText = String(quote.serialNumber || 1).padStart(3, '0');
  const cleanName = quote.fullName.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 15);
  return `SRP_Quotation_SN${serialText}_${cleanName}_${quote.id}.pdf`;
};

/**
 * Downloads the PDF directly to the client's file system
 */
export const downloadQuotePDFFile = (quote: SavedQuote): void => {
  const doc = generateCompleteQuotePDF(quote);
  const filename = getQuotePDFFilename(quote);
  doc.save(filename);
};

/**
 * Prepares the PDF file as a Blob and File object for sharing or previewing
 */
export const getQuotePDFObjects = (quote: SavedQuote): PDFFileResult => {
  const doc = generateCompleteQuotePDF(quote);
  const blob = doc.output('blob');
  const filename = getQuotePDFFilename(quote);
  const file = new File([blob], filename, { type: 'application/pdf' });
  return { doc, blob, file, filename };
};

/**
 * Attempts to share the actual complete PDF file via the Web Share API (Level 2).
 * On mobile devices and compatible PCs, this sends the REAL .PDF FILE directly into WhatsApp!
 */
export const tryNativeFileShare = async (
  quote: SavedQuote
): Promise<{ success: boolean; sharedNative: boolean; reason?: string }> => {
  if (typeof navigator === 'undefined' || !navigator.share) {
    return { success: false, sharedNative: false, reason: 'Web Share API not supported on this browser' };
  }

  try {
    const { file, filename } = getQuotePDFObjects(quote);

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({
        files: [file],
        title: `SRP Quotation Dossier - #${quote.id}`,
        text: `SRP Megha Power Official Quotation PDF for ${quote.fullName} (${quote.serviceOrProduct}) - Serial #${quote.serialNumber || 1}`
      });
      return { success: true, sharedNative: true };
    } else {
      return { success: false, sharedNative: false, reason: 'File sharing not supported by browser' };
    }
  } catch (err: any) {
    if (err?.name === 'AbortError') {
      return { success: false, sharedNative: false, reason: 'User dismissed share dialog' };
    }
    return { success: false, sharedNative: false, reason: err?.message || 'Share failed' };
  }
};
