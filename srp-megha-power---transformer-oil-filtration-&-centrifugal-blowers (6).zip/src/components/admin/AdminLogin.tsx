import React, { useState } from 'react';
import { Lock, ArrowRight, Home, Eye, EyeOff } from 'lucide-react';
import { SrpLeafLogoIcon } from '../CompanyLogo';

interface AdminLoginProps {
  onLogin: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const isValidUser = username.trim().toLowerCase() === 'admin';
    const isValidPass = password === 'SRP@1977';

    if (isValidUser && isValidPass) {
      onLogin();
    } else {
      setError('Access Denied: Invalid admin username or password.');
    }
  };

  const goHome = () => {
    window.location.hash = '';
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-emerald-600/15 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-teal-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-md w-full bg-slate-900 rounded-3xl shadow-2xl overflow-hidden border border-emerald-500/20 relative z-10 backdrop-blur-xl">
        <div className="bg-gradient-to-br from-[#061e0e] via-[#0d3819] to-[#072511] p-8 text-center text-white relative border-b border-emerald-500/20">
          <button 
            onClick={goHome} 
            className="absolute top-4 right-4 text-emerald-300 hover:text-white transition-colors bg-white/10 hover:bg-white/20 p-2 rounded-xl"
            title="Return to Website"
          >
            <Home className="w-4 h-4" />
          </button>
          
          <div className="w-20 h-20 bg-white/95 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-950/60 border border-emerald-300/30 p-2">
            <SrpLeafLogoIcon className="w-full h-full" />
          </div>
          <h2 className="text-2xl font-black tracking-wider uppercase text-white drop-shadow">
            SRP Megha Power
          </h2>
          <p className="text-amber-300 text-[11px] font-extrabold uppercase tracking-wider mt-1">
            Trusted for Power Quality and Reliability
          </p>
          <p className="text-emerald-300/80 text-[10px] font-bold uppercase tracking-widest mt-1">
            Enterprise Admin &amp; Lead Portal
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-5 bg-slate-900/90">
          {error && (
            <div className="bg-rose-950/70 text-rose-300 text-xs font-bold p-3 rounded-xl border border-rose-500/40 text-center">
              {error}
            </div>
          )}

          <div>
            <label className="block text-[11px] font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
              Admin Username
            </label>
            <div className="relative">
              <input 
                type="text" 
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-800/90 border border-slate-700 rounded-xl p-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                placeholder="Enter admin username"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
              Admin Password
            </label>
            <div className="relative">
              <input 
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-800/90 border border-slate-700 rounded-xl p-3 pr-10 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 py-3.5 rounded-xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/20 cursor-pointer mt-4"
          >
            <Lock className="w-4 h-4" />
            <span>Secure Sign In</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
      
      <div className="mt-8 text-xs text-slate-500 font-medium text-center">
        &copy; {new Date().getFullYear()} SRP Megha Power. Sakchi, Jamshedpur – 831001.
      </div>
    </div>
  );
};
