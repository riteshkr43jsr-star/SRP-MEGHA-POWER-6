import React, { useState } from 'react';
import { 
  Star, 
  Quote, 
  Factory, 
  Zap, 
  Pickaxe, 
  FlaskConical, 
  Cog, 
  CheckCircle2, 
  MessageSquarePlus, 
  Sparkles, 
  X, 
  UserCheck, 
  MapPin, 
  Calendar,
  ThumbsUp
} from 'lucide-react';
import { TESTIMONIALS } from '../data/companyData';
import { TestimonialItem } from '../types';

export const Testimonials: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedId, setSelectedId] = useState<string>('test-1');
  const [showReviewModal, setShowReviewModal] = useState<boolean>(false);
  const [submittedReviewSuccess, setSubmittedReviewSuccess] = useState<boolean>(false);

  // New review form local state
  const [newAuthor, setNewAuthor] = useState('');
  const [newRole, setNewRole] = useState('');
  const [newOrg, setNewOrg] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newRating, setNewRating] = useState<number>(5);
  const [newQuote, setNewQuote] = useState('');
  const [newCategory, setNewCategory] = useState('steel');

  // Filtered testimonials
  const filteredTestimonials = activeCategory === 'all'
    ? TESTIMONIALS
    : TESTIMONIALS.filter(t => t.industryCategory === activeCategory);

  const categories = [
    { id: 'all', label: 'All Reviews', icon: Factory, color: 'from-[#185C20] to-[#0D3F18]', border: 'border-[#185C20]', text: 'text-[#185C20]' },
    { id: 'steel', label: 'Steel & Metals', icon: Factory, color: 'from-blue-600 to-indigo-700', border: 'border-blue-600', text: 'text-blue-600' },
    { id: 'power', label: 'Power Plants', icon: Zap, color: 'from-emerald-600 to-teal-700', border: 'border-emerald-600', text: 'text-emerald-600' },
    { id: 'mining', label: 'Mining & Substation', icon: Pickaxe, color: 'from-amber-600 to-orange-700', border: 'border-amber-600', text: 'text-amber-600' },
    { id: 'chemical', label: 'Chemical & Scrubbers', icon: FlaskConical, color: 'from-purple-600 to-pink-700', border: 'border-purple-600', text: 'text-purple-600' },
    { id: 'manufacturing', label: 'Heavy Engineering', icon: Cog, color: 'from-rose-600 to-red-700', border: 'border-rose-600', text: 'text-rose-600' },
  ];

  const handleAddReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor || !newQuote || !newOrg) return;

    setSubmittedReviewSuccess(true);
    setTimeout(() => {
      setShowReviewModal(false);
      setSubmittedReviewSuccess(false);
      // Reset form
      setNewAuthor('');
      setNewRole('');
      setNewOrg('');
      setNewLocation('');
      setNewQuote('');
    }, 2000);
  };

  return (
    <section id="testimonials-section" className="py-16 bg-gradient-to-b from-[#F8FAF8] via-[#F1F6F1] to-[#EAEFEA] border-b border-[#DDE5DC] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100/90 border border-emerald-300 text-[#185C20] font-black text-xs uppercase tracking-wider shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
            <span>CLIENT FEEDBACK & REVIEWS</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#101A24] tracking-tight uppercase">
            WHAT OUR INDUSTRIAL CLIENTS SAY
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 font-medium max-w-2xl mx-auto">
            Verified feedback from plant engineers, maintenance heads, and electrical operations leads across Eastern India. Click any feedback card to inspect details.
          </p>
        </div>

        {/* Industry Filter Tabs */}
        <div className="flex items-center justify-center flex-wrap gap-2 mb-10">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all duration-200 flex items-center gap-2 shadow-xs border ${
                  isActive
                    ? `bg-gradient-to-r ${cat.color} text-white ${cat.border} shadow-md scale-105 ring-2 ring-emerald-500/30`
                    : 'bg-white text-gray-700 border-gray-300 hover:border-emerald-600 hover:bg-emerald-50/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-300' : 'text-gray-500'}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Testimonials Interactive Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTestimonials.map((t: TestimonialItem) => {
            const isSelected = selectedId === t.id;

            // Generate initial avatar letters
            const author = t.authorName || t.role;
            const initials = author
              .split(' ')
              .filter(n => !['Er.', 'Dr.', 'Mr.', 'DGM'].includes(n))
              .slice(0, 2)
              .map(n => n[0])
              .join('') || 'SP';

            return (
              <div 
                key={t.id}
                onClick={() => setSelectedId(t.id)}
                className={`cursor-pointer rounded-2xl p-6 transition-all duration-300 relative flex flex-col justify-between border ${
                  isSelected
                    ? 'bg-gradient-to-b from-white via-emerald-50/40 to-emerald-100/30 border-emerald-500 shadow-xl ring-2 ring-emerald-500/40 translate-y-[-2px]'
                    : 'bg-white border-gray-200 hover:border-emerald-400 hover:shadow-lg hover:translate-y-[-1px]'
                }`}
              >
                {/* Selected Status Badge */}
                {isSelected && (
                  <div className="absolute -top-3 right-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-[10px] font-black uppercase px-3 py-0.5 rounded-full shadow-md flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-amber-300" />
                    <span>SELECTED REVIEW</span>
                  </div>
                )}

                <div>
                  {/* Top Bar: Rating & Verified Contract Badge */}
                  <div className="flex items-center justify-between mb-4 gap-2">
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(t.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current drop-shadow-xs" />
                      ))}
                      <span className="text-xs font-black text-gray-700 ml-1">5.0</span>
                    </div>

                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                      isSelected 
                        ? 'bg-emerald-100 text-[#185C20] border-emerald-300 font-black' 
                        : 'bg-gray-100 text-gray-600 border-gray-200'
                    }`}>
                      {t.verifiedContract || 'Verified Client'}
                    </span>
                  </div>

                  {/* Quote Text */}
                  <div className="relative mb-6">
                    <Quote className={`w-8 h-8 mb-2 transition-colors ${
                      isSelected ? 'text-emerald-600/30' : 'text-gray-300'
                    }`} />
                    <p className={`text-xs sm:text-sm italic leading-relaxed transition-colors ${
                      isSelected ? 'text-gray-900 font-semibold' : 'text-gray-700 font-normal'
                    }`}>
                      "{t.quote}"
                    </p>
                  </div>
                </div>

                {/* Bottom Profile Area with Dynamic Name Color Changes */}
                <div className={`pt-4 border-t transition-colors ${
                  isSelected ? 'border-emerald-300' : 'border-gray-100'
                }`}>
                  <div className="flex items-center gap-3">
                    {/* Colorful Avatar Circle */}
                    <div className={`w-11 h-11 rounded-full bg-gradient-to-tr ${
                      t.avatarColor || 'from-[#185C20] to-emerald-600'
                    } text-white font-black text-xs flex items-center justify-center shrink-0 shadow-md relative`}>
                      {initials}
                      <span className="w-3 h-3 rounded-full bg-emerald-400 border-2 border-white absolute -bottom-0.5 -right-0.5" />
                    </div>

                    <div className="overflow-hidden">
                      {/* COLOR-CHANGING AUTHOR NAME */}
                      <div className={`font-black text-sm transition-all duration-300 ${
                        isSelected 
                          ? 'text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-emerald-700 to-indigo-800 scale-102 font-extrabold' 
                          : 'text-[#101A24] group-hover:text-[#185C20]'
                      }`}>
                        {t.authorName || 'Industrial Client'}
                      </div>

                      <div className="text-xs font-extrabold text-[#185C20]">
                        {t.role}
                      </div>

                      <div className="text-[11px] font-medium text-gray-600 truncate flex items-center gap-1 mt-0.5">
                        <UserCheck className="w-3 h-3 text-emerald-600 shrink-0" />
                        <span className="truncate">{t.organization}</span>
                      </div>

                      <div className="flex items-center gap-2 text-[10px] text-gray-500 font-medium mt-1">
                        <span className="flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5 text-gray-400" />
                          {t.location}
                        </span>
                        {t.date && (
                          <span className="flex items-center gap-0.5">
                            • <Calendar className="w-2.5 h-2.5 text-gray-400" />
                            {t.date}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Bottom CTA Bar for Submitting Review */}
        <div className="mt-12 text-center bg-white rounded-2xl p-6 border border-[#DDE5DC] shadow-md max-w-2xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <div className="text-sm font-black text-[#101820] uppercase tracking-wide flex items-center gap-2">
              <ThumbsUp className="w-4 h-4 text-[#185C20]" />
              <span>Are you an existing client or partner?</span>
            </div>
            <p className="text-xs text-gray-600 font-medium mt-0.5">
              Share your project feedback regarding oil filtration, blowers, or transformer servicing.
            </p>
          </div>

          <button
            onClick={() => setShowReviewModal(true)}
            className="shrink-0 bg-gradient-to-r from-[#185C20] to-[#0D3F18] hover:from-[#21772B] hover:to-[#124D1E] text-white px-5 py-3 rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-md transition-all hover:scale-102"
          >
            <MessageSquarePlus className="w-4 h-4 text-emerald-300" />
            <span>SUBMIT CLIENT FEEDBACK</span>
          </button>
        </div>

      </div>

      {/* SUBMIT FEEDBACK MODAL */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-emerald-500/30 shadow-2xl relative">
            
            <button
              onClick={() => setShowReviewModal(false)}
              className="absolute top-5 right-5 text-gray-400 hover:text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-full p-2 transition-all"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-2xl bg-[#185C20] text-white flex items-center justify-center font-black">
                <MessageSquarePlus className="w-5 h-5 text-emerald-300" />
              </div>
              <div>
                <h3 className="text-lg font-black text-[#101820] uppercase">
                  Submit Plant Feedback
                </h3>
                <p className="text-xs text-gray-600 font-medium">
                  SRP Megha Power — Customer Experience Survey
                </p>
              </div>
            </div>

            {submittedReviewSuccess ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-[#185C20] mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                </div>
                <h4 className="text-lg font-black text-[#101820]">
                  Thank You for Your Feedback!
                </h4>
                <p className="text-xs text-gray-600 font-medium">
                  Your review has been submitted to our technical management team.
                </p>
              </div>
            ) : (
              <form onSubmit={handleAddReviewSubmit} className="space-y-4 text-left">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-extrabold text-gray-700 uppercase mb-1">
                      Your Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Er. Rajesh Sharma"
                      value={newAuthor}
                      onChange={(e) => setNewAuthor(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl p-2.5 text-xs font-bold focus:outline-none focus:border-[#185C20]"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-extrabold text-gray-700 uppercase mb-1">
                      Designation / Role *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Maintenance Head"
                      value={newRole}
                      onChange={(e) => setNewRole(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl p-2.5 text-xs font-bold focus:outline-none focus:border-[#185C20]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-extrabold text-gray-700 uppercase mb-1">
                      Organization / Company *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Steel Manufacturing Plant"
                      value={newOrg}
                      onChange={(e) => setNewOrg(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl p-2.5 text-xs font-bold focus:outline-none focus:border-[#185C20]"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-extrabold text-gray-700 uppercase mb-1">
                      Location / Region
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Jamshedpur, Jharkhand"
                      value={newLocation}
                      onChange={(e) => setNewLocation(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl p-2.5 text-xs font-bold focus:outline-none focus:border-[#185C20]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-gray-700 uppercase mb-1">
                    Industry Sector
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-300 rounded-xl p-2.5 text-xs font-bold focus:outline-none focus:border-[#185C20]"
                  >
                    <option value="steel">Steel & Metals</option>
                    <option value="power">Power Generation & Substation</option>
                    <option value="mining">Mining & Mineral Processing</option>
                    <option value="chemical">Chemical & Fume Extraction</option>
                    <option value="manufacturing">Heavy Engineering</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-gray-700 uppercase mb-1">
                    Overall Satisfaction Rating
                  </label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((starVal) => (
                      <button
                        type="button"
                        key={starVal}
                        onClick={() => setNewRating(starVal)}
                        className="p-1 hover:scale-110 transition-transform"
                      >
                        <Star className={`w-6 h-6 ${
                          starVal <= newRating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'
                        }`} />
                      </button>
                    ))}
                    <span className="text-xs font-black text-gray-700 ml-2">
                      {newRating}.0 / 5.0 Stars
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-gray-700 uppercase mb-1">
                    Your Feedback / Comments *
                  </label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Write your experience with SRP Megha Power equipment or service..."
                    value={newQuote}
                    onChange={(e) => setNewQuote(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-300 rounded-xl p-2.5 text-xs font-medium focus:outline-none focus:border-[#185C20]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#185C20] hover:bg-[#21772B] text-white py-3.5 rounded-xl font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all mt-2"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>SUBMIT FEEDBACK NOW</span>
                </button>

              </form>
            )}

          </div>
        </div>
      )}

    </section>
  );
};
