import React from 'react';
import { COMPANY_DETAILS } from '../data/companyData';
import { CompanyLogo } from './CompanyLogo';
import { Zap, Phone, Mail, MapPin, ShieldCheck, MessageSquare, Lock, Key } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0D3F18] text-white pt-16 pb-8 border-t-4 border-[#4D9B2A]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Four Column Desktop Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-white/10 text-left">
          
          {/* Column 1: Company Info */}
          <div className="space-y-4">
            <CompanyLogo variant="dark" size="md" />

            <p className="text-xs text-emerald-100/80 leading-relaxed">
              Industrial specialists in transformer oil filtration, oil purification, substation maintenance, and custom centrifugal blowers for steel, power, and manufacturing sectors.
            </p>

            <div className="pt-2 text-xs text-emerald-300 flex items-center gap-2 font-bold">
              <ShieldCheck className="w-4 h-4 text-[#4D9B2A]" />
              <span>Certified Industrial Contractor</span>
            </div>
          </div>

          {/* Column 2: Services Links */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-sm uppercase tracking-wider text-[#4D9B2A]">
              OUR SERVICES
            </h4>
            <ul className="space-y-2 text-xs text-emerald-100/90">
              <li>
                <button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">
                  Transformer Oil Filtration (On-site)
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">
                  Vacuum Oil Drying & Degassing
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">
                  Oil Purification & Restoration
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">
                  Transformer Oil Lab Testing & DGA
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">
                  Substation Transformer Maintenance
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('services')} className="hover:text-white transition-colors">
                  Onsite Commissioning & Support
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Products Catalog */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-sm uppercase tracking-wider text-[#4D9B2A]">
              OUR PRODUCTS
            </h4>
            <ul className="space-y-2 text-xs text-emerald-100/90">
              <li>
                <button onClick={() => scrollToSection('products')} className="hover:text-white transition-colors font-bold text-amber-300">
                  10,000 LPH Oil Filtration Machine (Max Capacity)
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('products')} className="hover:text-white transition-colors">
                  6,000 LPH &amp; 5,000 LPH Filtration Machines
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('products')} className="hover:text-white transition-colors">
                  3,000 LPH &amp; 1,000 LPH Plants
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('products')} className="hover:text-white transition-colors">
                  Portable Oil Filtration Trolley Units
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('blowers')} className="hover:text-white transition-colors">
                  Backward & Forward Curved Blowers
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('blowers')} className="hover:text-white transition-colors">
                  High Pressure & Industrial Process Fans
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('blowers')} className="hover:text-white transition-colors">
                  Corrosion Resistant FRP / SS Blowers
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact Details (Bold, Colorful & Prominent) */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-sm uppercase tracking-wider text-[#4D9B2A]">
              CONTACT OFFICE
            </h4>
            <div className="space-y-3 text-xs">
              <div className="flex items-start gap-2 text-emerald-100">
                <MapPin className="w-4 h-4 text-[#4D9B2A] shrink-0 mt-0.5" />
                <span>{COMPANY_DETAILS.address}</span>
              </div>

              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#4D9B2A] shrink-0" />
                <a href={`tel:${COMPANY_DETAILS.phonePrimary}`} className="font-black text-sm text-white hover:text-[#4D9B2A] transition-colors">
                  {COMPANY_DETAILS.phonePrimary}
                </a>
              </div>

              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#25D366] fill-current shrink-0" />
                <a 
                  href={`https://wa.me/${COMPANY_DETAILS.whatsappNumber}`} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="font-black text-sm text-[#25D366] hover:underline transition-colors"
                >
                  +91 91624 84535 (WhatsApp)
                </a>
              </div>

              <div className="flex items-center gap-2 pt-1 border-t border-white/10">
                <Mail className="w-4 h-4 text-[#4D9B2A] shrink-0" />
                <a href={`mailto:${COMPANY_DETAILS.email}`} className="font-bold text-xs text-white hover:text-[#4D9B2A] transition-colors break-all">
                  {COMPANY_DETAILS.email}
                </a>
              </div>
            </div>

            {/* Premium Location Map */}
            <div className="pt-4 mt-2 border-t border-white/5 space-y-2">
              <div className="relative rounded-xl overflow-hidden border border-white/20 shadow-[0_0_15px_rgba(255,255,255,0.05)] group hover:shadow-[0_0_25px_rgba(255,255,255,0.15)] transition-all duration-500 bg-white/5 p-1.5">
                <div className="rounded-lg overflow-hidden relative bg-slate-100">
                  <div className="absolute inset-0 ring-1 ring-inset ring-black/5 rounded-lg pointer-events-none z-20"></div>
                  <iframe
                    title="SRP Megha Power Office Location - New Kalimati Road, Sakchi, Jamshedpur"
                    src={`https://maps.google.com/maps?q=${encodeURIComponent('New Kalimati Road, Near Chandra Hotel, Sakchi, Jamshedpur, Jharkhand 831001')}&t=m&z=15&ie=UTF8&iwloc=&output=embed`}
                    width="100%"
                    height="160"
                    style={{ border: 0 }}
                    allowFullScreen={false}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="w-full opacity-95 group-hover:opacity-100 transition-all duration-700"
                  ></iframe>
                </div>
              </div>
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent('1st Floor, New Kalimati Road, Near Chandra Hotel, Sakchi, Jamshedpur, Jharkhand 831001')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-[11px] font-bold text-[#4D9B2A] hover:text-emerald-300 transition-colors"
              >
                <MapPin className="w-3.5 h-3.5" />
                <span>Open Sakchi Office in Google Maps →</span>
              </a>
            </div>
          </div>

        </div>

        {/* Bottom Strip */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-emerald-200/70">
          <div>
            © {new Date().getFullYear()} <strong>SRP Megha Power</strong>. All Rights Reserved.
          </div>
          <div className="flex flex-wrap items-center justify-center gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms & Conditions</a>
            <a href="#admin" className="flex items-center gap-2 text-amber-400 hover:text-amber-300 font-bold transition-colors border border-amber-500/30 px-3 py-1.5 rounded bg-amber-500/10 group">
              <Lock className="w-3.5 h-3.5 group-hover:hidden" />
              <Key className="w-3.5 h-3.5 hidden group-hover:block" />
              <span>Admin Panel</span>
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
};
