import React, { useState } from 'react';
import { X, Send, CheckCircle2, ShieldCheck, Mail, Clock, Phone, MessageSquare, ArrowRight, Building2, User, FileText, Download } from 'lucide-react';
import { QuoteFormData } from '../types';
import { saveQuote, SavedQuote, formatWhatsAppQuoteMessage, formatGmailComposeUrl } from '../utils/storage';
import { downloadQuotePDFFile, tryNativeFileShare, getQuotePDFFilename } from '../utils/pdfGenerator';
import { COMPANY_DETAILS } from '../data/companyData';

interface QuoteModalProps {
  isOpen: boolean;
  prefilledItem?: string;
  onClose: () => void;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({ isOpen, prefilledItem = '', onClose }) => {
  const [formData, setFormData] = useState<QuoteFormData>({
    fullName: '',
    companyName: '',
    phone: '',
    email: '',
    serviceOrProduct: prefilledItem || 'Transformer Oil Filtration Machine',
    message: prefilledItem ? `Requesting quotation and technical specification sheet for ${prefilledItem}.` : ''
  });

  const [submittedQuote, setSubmittedQuote] = useState<SavedQuote | null>(null);
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    if (isOpen) {
      setFormData(prev => ({
        ...prev,
        serviceOrProduct: prefilledItem || 'Transformer Oil Filtration Machine',
        message: prefilledItem ? `Requesting quotation and technical specification sheet for ${prefilledItem}.` : ''
      }));
      setSubmittedQuote(null);
    }
  }, [isOpen, prefilledItem]);

  if (!isOpen) return null;

  const downloadQuotePDF = (quote: SavedQuote) => {
    downloadQuotePDFFile(quote);
  };

  const handleShareQuoteWhatsApp = async (quote: SavedQuote) => {
    // 1. Download file to device
    downloadQuotePDFFile(quote);

    // 2. Try native file share for full PDF attachment in WhatsApp
    const nativeRes = await tryNativeFileShare(quote);
    if (!nativeRes.sharedNative) {
      const msg = formatWhatsAppQuoteMessage(quote, true);
      window.open(`https://wa.me/${COMPANY_DETAILS.whatsappNumber}?text=${encodeURIComponent(msg)}`, '_blank');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const saved = await saveQuote(formData);
      setSubmittedQuote(saved);
      // Reset form fields
      setFormData({
        fullName: '',
        companyName: '',
        phone: '',
        email: '',
        serviceOrProduct: prefilledItem || 'Transformer Oil Filtration Machine',
        message: ''
      });
    } catch (err) {
      console.error('Error submitting quote:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative border-2 border-emerald-600/20 text-left max-h-[92vh] overflow-y-auto">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 bg-slate-100 hover:bg-slate-200 text-slate-700 p-2 rounded-full transition-colors z-10"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {submittedQuote ? (
          /* Success Screen with Explicit 24-Hour Guarantee Message */
          <div className="py-4 space-y-5 text-center animate-in zoom-in-95 duration-200">
            {/* Top Success Badge */}
            <div className="w-16 h-16 bg-[#EAF4E6] text-[#185C20] rounded-full flex items-center justify-center mx-auto border-2 border-[#4D9B2A] shadow-md">
              <CheckCircle2 className="w-9 h-9 text-[#4D9B2A]" />
            </div>

            <div>
              <div className="flex items-center justify-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-[#185C20] bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full">
                  Sr. No. #{String(submittedQuote.serialNumber || 1).padStart(3, '0')}
                </span>
                <span className="text-[10px] font-bold text-slate-600 bg-slate-100 border border-slate-200 px-3 py-1 rounded-full">
                  Ref: #{submittedQuote.id}
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-2 tracking-tight">
                QUOTATION REQUEST RECEIVED!
              </h3>
              <p className="text-xs font-bold text-emerald-800 mt-0.5">
                Sequential enquiry logged in SRP ERP system.
              </p>
            </div>

            {/* Prominent 24-Hour Guarantee Response Box */}
            <div className="bg-gradient-to-br from-emerald-50 via-white to-slate-50 border-2 border-emerald-500/40 rounded-2xl p-4 sm:p-5 text-left shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-emerald-900 font-extrabold text-sm border-b border-emerald-100 pb-2">
                <Clock className="w-5 h-5 text-emerald-600 shrink-0 animate-pulse" />
                <span>Guaranteed 24-Hour Response Commitment</span>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed font-medium">
                Our engineering and estimation team at <strong>SRP Megha Power</strong> has received your inquiry for <strong className="text-emerald-800">{submittedQuote.serviceOrProduct}</strong>.
              </p>

              <div className="bg-white/80 p-3 rounded-xl border border-emerald-200/60 text-xs space-y-1 text-slate-600">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-500">Applicant:</span>
                  <strong className="text-slate-800">{submittedQuote.fullName} ({submittedQuote.companyName})</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-500">Contact:</span>
                  <strong className="text-slate-800">{submittedQuote.phone}</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-500">Proposal Email:</span>
                  <strong className="text-slate-800">{submittedQuote.email}</strong>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-100/60 border border-emerald-300/60 text-[11px] text-emerald-950 font-bold flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <span>
                  Our technical team will review your specifications and send an official commercial proposal & datasheet to your email within <strong>24 hours</strong>.
                </span>
              </div>
            </div>

            {/* Quick Urgent Actions */}
            <div className="space-y-2.5 pt-1">
              <div className="text-[11px] text-slate-500 font-medium">
                Instant Quotation Delivery & PDF Access:
              </div>

              {/* Primary 1-Click WhatsApp & PDF Button */}
              <button
                type="button"
                onClick={() => handleShareQuoteWhatsApp(submittedQuote)}
                className="w-full bg-[#25D366] hover:bg-[#1fb855] text-slate-950 font-black py-3 px-4 rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 fill-current" />
                <span>Share Full PDF on WhatsApp (+91 91624 84535)</span>
              </button>

              <a
                href={formatGmailComposeUrl(submittedQuote)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-amber-600 hover:bg-amber-500 text-white font-black py-3 px-4 rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all"
              >
                <Mail className="w-4 h-4" />
                <span>Send Direct Email via Gmail ({COMPANY_DETAILS.email})</span>
              </a>

              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={() => downloadQuotePDF(submittedQuote)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download PDF Document</span>
                </button>
                <a
                  href={`tel:${COMPANY_DETAILS.phonePrimary}`}
                  className="flex-1 bg-[#185C20] hover:bg-[#0D3F18] text-white py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call: {COMPANY_DETAILS.phonePrimary}</span>
                </a>
              </div>
            </div>

            {/* Close Button */}
            <button 
              onClick={onClose}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 py-2.5 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-colors"
            >
              CLOSE WINDOW
            </button>
          </div>
        ) : (
          /* Request Form */
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-[#4D9B2A] uppercase tracking-wider bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  SRP MEGHA POWER • INDUSTRIAL RFQ
                </span>
                <span className="text-[10px] text-slate-500 font-semibold flex items-center gap-1">
                  <Clock className="w-3 h-3 text-emerald-600" />
                  24h Response
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-[#101A24] mt-1.5">
                REQUEST AN OFFICIAL QUOTATION
              </h3>
              <p className="text-xs text-slate-500">
                Fill the details below to receive competitive pricing and technical specifications.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#101A24] mb-1">
                Full Name *
              </label>
              <input 
                type="text" 
                required
                placeholder="e.g. Rajesh Kumar"
                value={formData.fullName}
                onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-3 text-xs text-[#101A24] focus:outline-none focus:ring-2 focus:ring-[#185C20] focus:bg-white transition-all font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#101A24] mb-1">
                Company / Plant Unit *
              </label>
              <input 
                type="text" 
                required
                placeholder="e.g. Tata Steel / Jindal / Substation Unit"
                value={formData.companyName}
                onChange={(e) => setFormData({...formData, companyName: e.target.value})}
                className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-3 text-xs text-[#101A24] focus:outline-none focus:ring-2 focus:ring-[#185C20] focus:bg-white transition-all font-medium"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#101A24] mb-1">
                  Phone Number (Mobile) *
                </label>
                <input 
                  type="tel" 
                  required
                  placeholder="+91 98765 43210"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-3 text-xs text-[#101A24] focus:outline-none focus:ring-2 focus:ring-[#185C20] focus:bg-white transition-all font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#101A24] mb-1">
                  Email Address *
                </label>
                <input 
                  type="email" 
                  required
                  placeholder="contact@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-3 text-xs text-[#101A24] focus:outline-none focus:ring-2 focus:ring-[#185C20] focus:bg-white transition-all font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#101A24] mb-1">
                Requested Product / Service *
              </label>
              <input 
                type="text" 
                required
                value={formData.serviceOrProduct}
                onChange={(e) => setFormData({...formData, serviceOrProduct: e.target.value})}
                className="w-full bg-[#EAF4E6] border-2 border-[#4D9B2A]/50 font-bold rounded-xl p-3 text-xs text-[#185C20] focus:outline-none focus:ring-2 focus:ring-[#185C20]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#101A24] mb-1">
                Technical Requirements / Project Notes
              </label>
              <textarea 
                rows={3}
                placeholder="Mention oil volume (Liters), transformer voltage rating (kV/MVA), or blower CFM / static pressure..."
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-3 text-xs text-[#101A24] focus:outline-none focus:ring-2 focus:ring-[#185C20] focus:bg-white transition-all font-medium"
              />
            </div>

            <div className="pt-1">
              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-[#185C20] hover:bg-[#0D3F18] text-white py-3.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all"
              >
                {loading ? (
                  <span>RECORDING REQUEST...</span>
                ) : (
                  <>
                    <span>SUBMIT QUOTE REQUEST</span>
                    <Send className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>

            <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 font-semibold text-center pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>We guarantee response within 24 hours • Direct Engineering Review</span>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
