import fs from 'fs';
import path from 'path';
import {defineConfig, PluginOption} from 'vite';

const dynamicImport = new Function('specifier', 'return import(specifier)') as (
  specifier: string
) => Promise<any>;

export default defineConfig(async () => {
  const plugins: PluginOption[] = [];

  try {
    const reactModule = await dynamicImport('@vitejs/plugin-react');
    const reactPlugin = reactModule.default || reactModule;
    plugins.push(reactPlugin());
  } catch {
    console.warn('[@vitejs/plugin-react] Using Vite built-in esbuild JSX transform.');
  }

  try {
    const tailwindModule = await dynamicImport('@tailwindcss/vite');
    const tailwindPlugin = tailwindModule.default || tailwindModule;
    plugins.push(tailwindPlugin());
  } catch {
    console.warn('[@tailwindcss/vite] Native binding unavailable on this host, using pre-compiled CSS fallback.');
    plugins.push({
      name: 'tailwind-css-fallback',
      enforce: 'pre',
      load(id: string) {
        const normalized = id.replace(/\\/g, '/');
        if (normalized.endsWith('/src/index.css')) {
          const fallbackPath = path.resolve(__dirname, 'src/tailwind-fallback.css');
          if (fs.existsSync(fallbackPath)) {
            return fs.readFileSync(fallbackPath, 'utf-8');
          }
        }
        return null;
      },
    });
  }

  return {
    plugins,
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
