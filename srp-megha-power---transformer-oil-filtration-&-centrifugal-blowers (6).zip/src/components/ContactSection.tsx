import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle2, MessageSquare, ShieldCheck, Sparkles, Building2, User, FileText, Layers, Download } from 'lucide-react';
import { COMPANY_DETAILS } from '../data/companyData';
import { QuoteFormData } from '../types';
import { saveQuote, formatWhatsAppQuoteMessage, formatGmailComposeUrl, SavedQuote } from '../utils/storage';
import { downloadQuotePDFFile, tryNativeFileShare } from '../utils/pdfGenerator';

interface ContactSectionProps {
  initialSubject?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ initialSubject = '' }) => {
  const [formData, setFormData] = useState<QuoteFormData>({
    fullName: '',
    companyName: '',
    phone: '',
    email: '',
    serviceOrProduct: initialSubject || 'Transformer Oil Filtration',
    message: ''
  });

  const [submittedQuote, setSubmittedQuote] = useState<SavedQuote | null>(null);
  const [loading, setLoading] = useState(false);

  const downloadQuotePDF = (quote: SavedQuote) => {
    downloadQuotePDFFile(quote);
  };

  const handleShareQuoteWhatsApp = async (quote: SavedQuote) => {
    downloadQuotePDFFile(quote);
    const nativeRes = await tryNativeFileShare(quote);
    if (!nativeRes.sharedNative) {
      const msg = formatWhatsAppQuoteMessage(quote, true);
      window.open(`https://wa.me/${COMPANY_DETAILS.whatsappNumber}?text=${encodeURIComponent(msg)}`, '_blank');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const saved = await saveQuote(formData);
      setSubmittedQuote(saved);
      setFormData({
        fullName: '',
        companyName: '',
        phone: '',
        email: '',
        serviceOrProduct: initialSubject || 'Transformer Oil Filtration',
        message: ''
      });
    } catch(err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="contact" className="py-16 bg-gradient-to-b from-white via-[#F7F9F6] to-[#EAF4E6]/40 border-b border-[#DDE5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-[#185C20] to-[#4D9B2A] text-white font-black text-xs uppercase tracking-widest shadow-md">
            <Sparkles className="w-4 h-4 text-emerald-200" />
            DIRECT CORPORATE & TECHNICAL INQUIRY
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#101A24] tracking-tight">
            LET'S DISCUSS YOUR <span className="text-[#185C20] underline decoration-[#4D9B2A] decoration-4 underline-offset-4">REQUIREMENT</span>
          </h2>
          <p className="text-sm sm:text-base text-gray-700 font-medium">
            Reach out directly via phone, WhatsApp, or email. Our technical engineering team in Jamshedpur delivers rapid-response quotations and on-site field support.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Contact Details Column (5 cols) - All 5 Items Same Large Size & Rich Color Coding */}
          <div className="lg:col-span-5 bg-white rounded-3xl border-2 border-[#185C20]/20 p-6 sm:p-7 space-y-4 shadow-xl text-left relative overflow-hidden">
            
            {/* Top Corporate Directory Badge */}
            <div className="bg-gradient-to-r from-[#185C20] via-[#0D3F18] to-[#185C20] text-white p-4 sm:p-5 rounded-2xl shadow-md border-b-4 border-[#4D9B2A]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-widest text-[#4D9B2A] block">
                  OFFICIAL CONTACT DIRECTORY
                </span>
                <span className="bg-[#4D9B2A] text-white text-[9px] font-black uppercase px-2 py-0.5 rounded">
                  JAMSHEDPUR
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white mt-1">
                {COMPANY_DETAILS.fullName}
              </h3>
              <p className="text-xs text-emerald-100 font-medium mt-0.5">
                Industrial Electrical Engineering & Centrifugal Blower Specialists
              </p>
            </div>

            {/* ALL 5 ITEMS UNIFORM IN SIZE (text-xl sm:text-2xl font-black), PADDING AND CARD STRUCTURE */}
            <div className="space-y-3.5">
              
              {/* ITEM 1: Primary Phone & Support Line (Forest Green Theme) */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#EAF4E6] via-white to-white border-2 border-[#185C20]/40 shadow-xs hover:shadow-md transition-all">
                <div className="flex items-center gap-3 mb-1.5">
                  <div className="w-11 h-11 rounded-xl bg-[#185C20] text-white flex items-center justify-center shrink-0 shadow-sm border border-[#4D9B2A]/40">
                    <Phone className="w-5 h-5 text-[#4D9B2A]" />
                  </div>
                  <div>
                    <span className="text-[11px] font-black uppercase tracking-wider text-[#185C20]">
                      PRIMARY CALL & SUPPORT LINE
                    </span>
                    <h4 className="text-xs font-bold text-gray-500">Immediate Phone Assistance</h4>
                  </div>
                </div>
                <a 
                  href={`tel:${COMPANY_DETAILS.phonePrimary}`} 
                  className="block text-xl sm:text-2xl font-black text-[#101A24] hover:text-[#185C20] transition-colors tracking-tight pt-1"
                >
                  {COMPANY_DETAILS.phonePrimary}
                </a>
              </div>

              {/* ITEM 2: WhatsApp Support Line (Emerald WhatsApp Green Theme) */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#DCF8C6]/60 via-white to-white border-2 border-[#25D366]/50 shadow-xs hover:shadow-md transition-all">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-[#25D366] text-white flex items-center justify-center shrink-0 shadow-sm">
                      <MessageSquare className="w-5 h-5 fill-current" />
                    </div>
                    <div>
                      <span className="text-[11px] font-black uppercase tracking-wider text-[#128C7E]">
                        WHATSAPP SUPPORT LINE
                      </span>
                      <h4 className="text-xs font-bold text-gray-500">Instant Chat & Drawings</h4>
                    </div>
                  </div>
                  <a 
                    href={`https://wa.me/${COMPANY_DETAILS.whatsappNumber}?text=Hello%20SRP%20Megha%20Power,%20I%20have%20an%20industrial%20requirement.`} 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hidden sm:inline-block bg-[#25D366] hover:bg-[#128C7E] text-white text-[10px] font-black uppercase px-3 py-1.5 rounded-lg transition-colors shadow-xs"
                  >
                    CHAT NOW
                  </a>
                </div>
                <a 
                  href={`https://wa.me/${COMPANY_DETAILS.whatsappNumber}?text=Hello%20SRP%20Megha%20Power,%20I%20have%20an%20industrial%20requirement.`} 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-xl sm:text-2xl font-black text-[#101A24] hover:text-[#25D366] transition-colors tracking-tight pt-1"
                >
                  +91 91624 84535
                </a>
              </div>

              {/* ITEM 3: Official Email Address (Navy Blue Theme - SINGLE EMAIL ONLY) */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#EBF3FE] via-white to-white border-2 border-[#2563EB]/30 shadow-xs hover:shadow-md transition-all">
                <div className="flex items-center gap-3 mb-1.5">
                  <div className="w-11 h-11 rounded-xl bg-[#1E40AF] text-white flex items-center justify-center shrink-0 shadow-sm">
                    <Mail className="w-5 h-5 text-blue-300" />
                  </div>
                  <div>
                    <span className="text-[11px] font-black uppercase tracking-wider text-[#1E40AF]">
                      OFFICIAL EMAIL ADDRESS
                    </span>
                    <h4 className="text-xs font-bold text-gray-500">Purchase Orders & RFQ Docs</h4>
                  </div>
                </div>
                <a 
                  href={`mailto:${COMPANY_DETAILS.email}`} 
                  className="block text-lg sm:text-xl font-black text-[#185C20] hover:underline transition-colors break-all tracking-tight pt-1"
                >
                  {COMPANY_DETAILS.email}
                </a>
              </div>

              {/* ITEM 4: Works & Office Location (Ocean Teal Theme - MATCHED SIZE) */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#E0F2FE] via-white to-white border-2 border-[#0284C7]/40 shadow-xs hover:shadow-md transition-all space-y-3">
                <div className="flex items-center gap-3 mb-1.5">
                  <div className="w-11 h-11 rounded-xl bg-[#0284C7] text-white flex items-center justify-center shrink-0 shadow-sm">
                    <MapPin className="w-5 h-5 text-sky-200" />
                  </div>
                  <div>
                    <span className="text-[11px] font-black uppercase tracking-wider text-[#0369A1]">
                      OFFICE & REGISTERED LOCATION
                    </span>
                    <h4 className="text-xs font-bold text-gray-500">Sakchi Corporate Office, Jamshedpur</h4>
                  </div>
                </div>
                <div className="text-sm sm:text-base font-black text-[#101A24] tracking-tight pt-1 leading-snug">
                  {COMPANY_DETAILS.address}
                </div>
                <div className="rounded-xl overflow-hidden border border-[#0284C7]/30 shadow-inner bg-slate-100">
                  <iframe
                    title="SRP Megha Power Sakchi Office Map"
                    src={`https://maps.google.com/maps?q=${encodeURIComponent('New Kalimati Road, Near Chandra Hotel, Sakchi, Jamshedpur, Jharkhand 831001')}&t=m&z=15&ie=UTF8&iwloc=&output=embed`}
                    width="100%"
                    height="150"
                    style={{ border: 0 }}
                    allowFullScreen={false}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="w-full"
                  ></iframe>
                </div>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent('1st Floor, New Kalimati Road, Near Chandra Hotel, Sakchi, Jamshedpur, Jharkhand 831001')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-black text-[#0369A1] hover:text-[#185C20] transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Open Sakchi Office Location in Google Maps →</span>
                </a>
              </div>

              {/* ITEM 5: Field Response Hours (Golden Amber Theme - MATCHED SIZE) */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#FEF3C7] via-white to-white border-2 border-[#F59E0B]/50 shadow-xs hover:shadow-md transition-all">
                <div className="flex items-center gap-3 mb-1.5">
                  <div className="w-11 h-11 rounded-xl bg-[#D97706] text-white flex items-center justify-center shrink-0 shadow-sm">
                    <Clock className="w-5 h-5 text-amber-200" />
                  </div>
                  <div>
                    <span className="text-[11px] font-black uppercase tracking-wider text-[#B45309]">
                      FIELD RESPONSE HOURS
                    </span>
                    <h4 className="text-xs font-bold text-gray-500">Operational Field Schedule</h4>
                  </div>
                </div>
                <div className="text-lg sm:text-xl font-black text-[#101A24] tracking-tight pt-1 leading-snug">
                  {COMPANY_DETAILS.businessHours}
                </div>
              </div>

            </div>

            {/* Emergency Hotline Banner */}
            <div className="p-4 bg-gradient-to-r from-[#185C20] via-[#0D3F18] to-[#185C20] rounded-2xl text-white text-xs font-bold flex items-center gap-3 shadow-md border-t-2 border-[#4D9B2A]">
              <ShieldCheck className="w-6 h-6 text-[#4D9B2A] shrink-0" />
              <span>24/7 Field Shutdown Emergency Response active across Jharkhand, Bihar, Odisha & West Bengal</span>
            </div>

          </div>

          {/* Form Column (7 cols) - Colorful, Vibrant & Attractive Technical Inquiry Form */}
          <div className="lg:col-span-7 bg-gradient-to-br from-white via-[#F7F9F6] to-[#EAF4E6]/50 rounded-3xl border-2 border-[#185C20]/25 p-6 sm:p-8 shadow-xl text-left relative overflow-hidden">
            
            {/* Header Badge */}
            <div className="bg-gradient-to-r from-[#185C20] via-[#0D3F18] to-[#185C20] text-white p-5 rounded-2xl shadow-md mb-6 border-b-4 border-[#4D9B2A] flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black text-[#4D9B2A] uppercase tracking-widest block">
                  ONLINE SPECIFICATION SUBMISSION
                </span>
                <h3 className="text-2xl font-black text-white">
                  SEND TECHNICAL INQUIRY
                </h3>
              </div>
              <div className="hidden sm:flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg border border-white/20 text-xs font-bold text-emerald-200">
                <Sparkles className="w-4 h-4 text-[#4D9B2A]" />
                <span>Rapid Proposal</span>
              </div>
            </div>

            {submittedQuote ? (
              <div className="py-8 text-center space-y-4 animate-in fade-in duration-300">
                <div className="w-16 h-16 rounded-full bg-[#EAF4E6] text-[#185C20] flex items-center justify-center mx-auto border-2 border-[#4D9B2A] shadow-md">
                  <CheckCircle2 className="w-10 h-10 text-[#4D9B2A]" />
                </div>
                <div>
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-widest text-[#185C20] bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full">
                      Sr. No. #{String(submittedQuote.serialNumber || 1).padStart(3, '0')}
                    </span>
                    <span className="text-[10px] font-bold text-slate-600 bg-slate-100 border border-slate-200 px-3 py-1 rounded-full">
                      Ref: #{submittedQuote.id}
                    </span>
                  </div>
                  <h3 className="text-2xl font-black text-[#101A24] mt-2">
                    ENQUIRY SUBMITTED SUCCESSFULLY!
                  </h3>
                  <p className="text-xs font-bold text-emerald-800">
                    Sequential enquiry registered in SRP Megha Power ERP.
                  </p>
                </div>

                <div className="bg-gradient-to-br from-emerald-50 via-white to-slate-50 border-2 border-emerald-500/40 rounded-2xl p-4 text-left shadow-xs space-y-2 max-w-lg mx-auto">
                  <div className="flex items-center gap-2 text-emerald-900 font-extrabold text-sm border-b border-emerald-100 pb-2">
                    <Clock className="w-4 h-4 text-emerald-600 shrink-0 animate-pulse" />
                    <span>Guaranteed 24-Hour Reply Commitment</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed font-medium">
                    Thank you, <strong>{submittedQuote.fullName}</strong>. Our engineering team at <strong>SRP Megha Power</strong> has received your inquiry for <strong className="text-emerald-800">{submittedQuote.serviceOrProduct}</strong>.
                  </p>
                  <p className="text-[11px] text-emerald-950 font-bold bg-emerald-100/70 p-2.5 rounded-xl border border-emerald-300/50">
                    ✓ We will review your technical specifications and send an official commercial proposal to <strong>{submittedQuote.email}</strong> and contact you at <strong>{submittedQuote.phone}</strong> within 24 hours.
                  </p>
                </div>

                {/* 1-Click WhatsApp, Gmail & PDF Buttons */}
                <div className="space-y-2.5 max-w-lg mx-auto pt-1">
                  <button
                    type="button"
                    onClick={() => handleShareQuoteWhatsApp(submittedQuote)}
                    className="w-full bg-[#25D366] hover:bg-[#1fb855] text-slate-950 font-black py-3 px-4 rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4 fill-current" />
                    <span>Share Full PDF on WhatsApp (+91 91624 84535)</span>
                  </button>

                  <a
                    href={formatGmailComposeUrl(submittedQuote)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-amber-600 hover:bg-amber-500 text-white font-black py-3 px-4 rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all"
                  >
                    <Mail className="w-4 h-4" />
                    <span>Send Direct Email via Gmail ({COMPANY_DETAILS.email})</span>
                  </a>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={() => downloadQuotePDF(submittedQuote)}
                      className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Download PDF Document</span>
                    </button>
                    <a
                      href={`tel:${COMPANY_DETAILS.phonePrimary}`}
                      className="flex-1 bg-[#185C20] hover:bg-[#0D3F18] text-white py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call Desk: {COMPANY_DETAILS.phonePrimary}</span>
                    </a>
                  </div>
                </div>

                <div className="pt-2">
                  <button 
                    onClick={() => {
                      setSubmittedQuote(null);
                      setFormData({ fullName: '', companyName: '', phone: '', email: '', serviceOrProduct: 'Transformer Oil Filtration', message: '' });
                    }}
                    className="bg-slate-200 text-slate-800 px-6 py-2 rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-slate-300 transition-colors"
                  >
                    SUBMIT ANOTHER ENQUIRY
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                
                {/* Full Name & Company */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-white p-3.5 rounded-2xl border-2 border-[#DDE5DC] hover:border-[#185C20] transition-colors shadow-2xs">
                    <label className="block text-xs font-black text-[#185C20] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#4D9B2A]" />
                      Full Name *
                    </label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Rajesh Kumar"
                      value={formData.fullName}
                      onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                      className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-2.5 text-xs text-[#101A24] font-bold focus:outline-none focus:border-[#185C20] focus:bg-white transition-colors"
                    />
                  </div>

                  <div className="bg-white p-3.5 rounded-2xl border-2 border-[#DDE5DC] hover:border-[#185C20] transition-colors shadow-2xs">
                    <label className="block text-xs font-black text-[#185C20] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-[#4D9B2A]" />
                      Company / Plant Unit *
                    </label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Steel Plant / Substation"
                      value={formData.companyName}
                      onChange={(e) => setFormData({...formData, companyName: e.target.value})}
                      className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-2.5 text-xs text-[#101A24] font-bold focus:outline-none focus:border-[#185C20] focus:bg-white transition-colors"
                    />
                  </div>
                </div>

                {/* Phone & Email */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-white p-3.5 rounded-2xl border-2 border-[#DDE5DC] hover:border-[#185C20] transition-colors shadow-2xs">
                    <label className="block text-xs font-black text-[#185C20] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#4D9B2A]" />
                      Phone Number *
                    </label>
                    <input 
                      type="tel" 
                      required
                      placeholder="+91 86036 83851"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-2.5 text-xs text-[#101A24] font-bold focus:outline-none focus:border-[#185C20] focus:bg-white transition-colors"
                    />
                  </div>

                  <div className="bg-white p-3.5 rounded-2xl border-2 border-[#DDE5DC] hover:border-[#185C20] transition-colors shadow-2xs">
                    <label className="block text-xs font-black text-[#185C20] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-[#4D9B2A]" />
                      Email Address *
                    </label>
                    <input 
                      type="email" 
                      required
                      placeholder="name@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-2.5 text-xs text-[#101A24] font-bold focus:outline-none focus:border-[#185C20] focus:bg-white transition-colors"
                    />
                  </div>
                </div>

                {/* Service/Product Selection */}
                <div className="bg-gradient-to-r from-[#EAF4E6] to-white p-4 rounded-2xl border-2 border-[#185C20]/30 shadow-2xs">
                  <label className="block text-xs font-black text-[#185C20] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-[#4D9B2A]" />
                    Select Product or Service Category *
                  </label>
                  <select 
                    value={formData.serviceOrProduct}
                    onChange={(e) => setFormData({...formData, serviceOrProduct: e.target.value})}
                    className="w-full bg-white border-2 border-[#185C20]/40 rounded-xl p-3 text-xs font-extrabold text-[#185C20] focus:outline-none focus:border-[#185C20] transition-colors shadow-2xs"
                  >
                    <option value="Transformer Oil Filtration">Transformer Oil Filtration Services (On-site)</option>
                    <option value="10,000 LPH Oil Filtration Machine">10,000 LPH Oil Filtration Machine Supply (Max Capacity)</option>
                    <option value="6,000 LPH Oil Filtration Machine">6,000 LPH Oil Filtration Machine Supply</option>
                    <option value="5,000 LPH Oil Filtration Machine">5,000 LPH Oil Filtration Machine Supply</option>
                    <option value="Portable Oil Filtration Unit">Portable Oil Filtration Unit</option>
                    <option value="Centrifugal Blower - Backward Curved">Centrifugal Blower - Backward Curved Series</option>
                    <option value="Centrifugal Blower - High Pressure">Centrifugal Blower - High Pressure Series</option>
                    <option value="Centrifugal Blower - FRP / SS Acid Proof">Corrosion Resistant FRP / SS Blowers</option>
                    <option value="Boiler ID / FD Fans">Boiler ID / FD Draft Fans</option>
                    <option value="Transformer Maintenance & Overhaul">Transformer Maintenance & Substation Overhaul</option>
                    <option value="General Technical Consultation">General Technical Inquiry</option>
                  </select>
                </div>

                {/* Requirement Message */}
                <div className="bg-white p-4 rounded-2xl border-2 border-[#DDE5DC] hover:border-[#185C20] transition-colors shadow-2xs">
                  <label className="block text-xs font-black text-[#185C20] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-[#4D9B2A]" />
                    Requirement / Specification Details *
                  </label>
                  <textarea 
                    required
                    rows={4}
                    placeholder="Describe your requirement (e.g. Transformer MVA rating, oil volume in Litres, or Blower CFM / Static Pressure requirement)..."
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="w-full bg-[#F7F9F6] border border-[#DDE5DC] rounded-xl p-3 text-xs text-[#101A24] font-medium focus:outline-none focus:border-[#185C20] focus:bg-white transition-colors"
                  />
                </div>

                {/* Submit Button */}
                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-[#185C20] via-[#0D3F18] to-[#185C20] hover:from-[#0D3F18] hover:to-[#185C20] text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl hover:shadow-2xl transition-all duration-200 border border-[#4D9B2A]/40"
                >
                  {loading ? (
                    <span>PROCESSING SUBMISSION...</span>
                  ) : (
                    <>
                      <span>SUBMIT DIRECT TECHNICAL INQUIRY</span>
                      <Send className="w-4 h-4 text-[#4D9B2A]" />
                    </>
                  )}
                </button>

              </form>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
