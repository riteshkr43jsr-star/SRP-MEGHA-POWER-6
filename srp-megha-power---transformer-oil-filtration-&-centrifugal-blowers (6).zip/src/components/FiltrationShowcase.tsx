import React from 'react';
import { Droplet, Check, ArrowRight, ShieldCheck, Cpu, Sliders, Eye } from 'lucide-react';
import { FILTRATION_PRODUCTS } from '../data/companyData';
import { ProductItem } from '../types';

interface FiltrationShowcaseProps {
  onSelectProduct: (product: ProductItem) => void;
  onOpenQuote: (productName: string) => void;
}

export const FiltrationShowcase: React.FC<FiltrationShowcaseProps> = ({ onSelectProduct, onOpenQuote }) => {
  return (
    <section id="products" className="py-16 bg-white border-b border-[#DDE5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAF4E6] text-[#185C20] font-bold text-xs uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-[#4D9B2A]" />
            PRODUCT RANGE A
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#101A24] tracking-tight">
            TRANSFORMER OIL FILTRATION MACHINES
          </h2>
          <p className="text-sm sm:text-base text-gray-600">
            Engineered and manufactured to restore insulating oil dielectric strength, remove dissolved moisture, gases, and sludge in high-voltage industrial transformers.
          </p>
        </div>

        {/* Main Category Box Container */}
        <div className="bg-[#F7F9F6] rounded-2xl border-2 border-[#185C20]/20 p-6 sm:p-8 shadow-sm">
          
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 mb-8 border-b border-[#DDE5DC]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#185C20] text-white flex items-center justify-center font-bold">
                <Droplet className="w-5 h-5 text-[#4D9B2A]" />
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-[#101A24]">
                  High Vacuum Oil Purification Systems
                </h3>
                <p className="text-xs text-gray-600">
                  Capacities ranging from 1,000 LPH to 10,000 LPH (Max Filtration Capacity: 10,000 LPH) • Single & Double Stage Options
                </p>
              </div>
            </div>

            <button 
              onClick={() => onOpenQuote('Transformer Oil Filtration Machine')}
              className="bg-[#185C20] hover:bg-[#0D3F18] text-white px-5 py-2.5 rounded-lg font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors"
            >
              <span>REQUEST FILTRATION MACHINE QUOTE</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Machine Models Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
            {FILTRATION_PRODUCTS.map((machine: ProductItem) => (
              <div 
                key={machine.id}
                id={`filtration-${machine.id.replace('oil-filter-', '')}`}
                className="bg-white rounded-xl border border-[#DDE5DC] p-4 shadow-2xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  {/* Technical Graphic Badge Box (Photo Removed) */}
                  <div className="relative rounded-lg overflow-hidden mb-3 bg-gradient-to-br from-[#0D3F18] via-[#185C20] to-[#0A2E12] h-32 p-4 flex flex-col justify-between border border-emerald-800/40 shadow-inner group-hover:from-[#185C20] group-hover:to-[#0D3F18] transition-all">
                    <div className="flex items-center justify-between">
                      <div className="w-9 h-9 rounded-lg bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 flex items-center justify-center font-bold shadow-xs">
                        <Droplet className="w-5 h-5 text-emerald-400" />
                      </div>
                      {machine.badge && (
                        <span className="bg-emerald-500/30 text-emerald-200 border border-emerald-400/40 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                          {machine.badge}
                        </span>
                      )}
                    </div>
                    <div>
                      <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-300/80 block">
                        TRANSFORMER OIL FILTRATION
                      </span>
                      <span className="text-sm font-black text-white tracking-tight">
                        {machine.capacity}
                      </span>
                    </div>
                  </div>

                  <div className="text-[11px] font-bold text-[#4D9B2A] uppercase tracking-wider mb-1">
                    {machine.capacity}
                  </div>

                  <h4 className="font-bold text-sm text-[#101A24] line-clamp-2 mb-2 group-hover:text-[#185C20] transition-colors">
                    {machine.name}
                  </h4>

                  <p className="text-xs text-gray-500 line-clamp-2 mb-4">
                    {machine.shortDesc}
                  </p>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-gray-100">
                  <button 
                    onClick={() => onOpenQuote(machine.name)}
                    className="w-full bg-[#185C20] hover:bg-[#0D3F18] text-white py-2 rounded-lg text-xs font-black uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <span>Get a Quote</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button 
                    onClick={() => onSelectProduct(machine)}
                    className="w-full bg-[#EAF4E6] hover:bg-slate-200 text-[#185C20] py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Specifications</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Technical Specifications Checklist Panel */}
          <div className="relative bg-white rounded-2xl border-2 border-slate-200 p-6 sm:p-8 shadow-md hover:shadow-xl transition-all duration-300 space-y-6 overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-600 via-teal-500 via-blue-500 to-indigo-600" />

            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
              <h4 className="font-black text-base sm:text-lg uppercase tracking-tight text-[#0B1E38] flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-600/20">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <span>STANDARD TECHNICAL SPECIFICATIONS — TRANSFORMER OIL FILTRATION MACHINES</span>
              </h4>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100/90 text-emerald-900 text-xs font-extrabold uppercase tracking-wider border border-emerald-300">
                <Check className="w-3.5 h-3.5 text-emerald-700" />
                B2B Industrial Grade
              </span>
            </div>

            {/* Specification Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 text-xs sm:text-sm text-slate-800">
              
              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Filtration Capacity:</strong> 1,000 LPH to 10,000 LPH (Max Capacity: 10,000 LPH)</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Vacuum System:</strong> High-Vacuum Dehydration &amp; Degassing Chamber</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Moisture Removal:</strong> High-Efficiency Vacuum Dehydration</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Dissolved Gas Removal:</strong> High-Efficiency Vacuum Degassing</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Particle Filtration:</strong> Fine Filtration up to 1 Micron</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Oil Heating:</strong> Controlled Electric Oil Heating System</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Temperature Control:</strong> Automatic Temperature Monitoring &amp; Control</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Instrumentation:</strong> Flow Meter, Vacuum Gauge &amp; Temperature Monitoring</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Control System:</strong> Automatic PLC-Based Control Panel</span>
              </div>

              <div className="flex items-center gap-3 bg-gradient-to-r from-slate-50 to-emerald-50/30 p-3.5 rounded-xl border border-slate-200 hover:border-emerald-500/70 hover:shadow-md transition-all duration-200 group col-span-1 sm:col-span-2 lg:col-span-3">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-110 transition-transform">
                  <Check className="w-4 h-4 font-black" />
                </div>
                <span><strong className="text-slate-900">Mounting Options:</strong> Stationary / Skid-Mounted / Trailer-Mounted / Truck-Mounted</span>
              </div>

            </div>

            {/* Highlighted Available Capacities Line */}
            <div className="bg-gradient-to-r from-[#EAF4E6] via-emerald-100/70 to-[#EAF4E6] p-4 rounded-xl border-2 border-emerald-500/40 text-center shadow-xs">
              <p className="text-xs sm:text-sm font-black text-[#185C20] tracking-wide uppercase flex flex-wrap items-center justify-center gap-1.5">
                <span>Available Capacities:</span>
                <span className="text-emerald-950 font-black">500 LPH</span> &bull;
                <span className="text-emerald-950 font-black">1,000 LPH</span> &bull;
                <span className="text-emerald-950 font-black">3,000 LPH</span> &bull;
                <span className="text-emerald-950 font-black">5,000 LPH</span> &bull;
                <span className="text-emerald-950 font-black">6,000 LPH</span> &bull;
                <span className="text-white font-black bg-[#185C20] px-2.5 py-1 rounded-md shadow-xs ml-1 inline-block">MAX 10,000 LPH CAPACITY</span>
              </p>
            </div>

            {/* Professional Customization Note */}
            <div className="bg-slate-900 text-slate-100 p-4 rounded-xl border border-slate-800 text-xs sm:text-sm font-medium text-center shadow-inner flex items-center justify-center gap-2">
              <span className="text-emerald-400 font-bold text-base">&ldquo;</span>
              <span>Filtration capacity and machine configuration can be customized according to transformer oil condition, transformer capacity and site requirements.</span>
              <span className="text-emerald-400 font-bold text-base">&rdquo;</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
