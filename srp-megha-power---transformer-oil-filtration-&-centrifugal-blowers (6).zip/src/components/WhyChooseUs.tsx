import React from 'react';
import { 
  MapPin, 
  Cpu, 
  Users, 
  Zap, 
  Clock, 
  Target, 
  CheckCircle2, 
  ArrowRight,
  Sparkles,
  Layers
} from 'lucide-react';

interface WhyChooseUsProps {
  onOpenQuote: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onOpenQuote }) => {
  // 5 Operational States
  const statesCovered = [
    { 
      name: 'Jharkhand', 
      detail: 'HQ & Manufacturing Base (Jamshedpur)', 
      primary: true 
    },
    { 
      name: 'West Bengal', 
      detail: 'Industrial Belts & Power Utilities', 
      primary: false 
    },
    { 
      name: 'Odisha', 
      detail: 'Steel, Mining & Metallurgical Hubs', 
      primary: false 
    },
    { 
      name: 'Chhattisgarh', 
      detail: 'Thermal Power & Heavy Foundries', 
      primary: false 
    },
    { 
      name: 'Bihar', 
      detail: 'Grid Substations & Utility Networks', 
      primary: false 
    }
  ];

  // Core Pillars & Strengths
  const coreStrengths = [
    {
      icon: Cpu,
      title: 'Advanced Filtration Technology',
      desc: 'High-vacuum 2-stage transformer oil dehydration, degasification, and BDV restoration systems engineered for EHV substations up to 400kV.',
      gradient: 'from-[#185C20] via-emerald-600 to-[#0F3814]',
      accentBg: 'bg-emerald-500/10 text-[#185C20] border-emerald-500/30',
      badgeColor: 'from-amber-500 to-orange-500',
      highlightTag: 'Primary Tech Advantage',
      highlight: true
    },
    {
      icon: Users,
      title: 'Experienced Technical Team',
      desc: '10+ years of certified field engineers, transformer specialists, and shutdown execution experts providing round-the-clock technical support.',
      gradient: 'from-[#004B87] via-sky-600 to-[#002D54]',
      accentBg: 'bg-sky-500/10 text-[#004B87] border-sky-500/30',
      badgeColor: 'from-cyan-500 to-blue-600',
      highlightTag: '10+ Yrs Expertise',
      highlight: true
    },
    {
      icon: Zap,
      title: 'High Performance & Efficiency',
      desc: 'Heavy-duty industrial blowers and filtration units designed for maximum throughput, low energy consumption, and continuous 24x7 plant operation.',
      gradient: 'from-[#D94800] via-amber-600 to-[#A33200]',
      accentBg: 'bg-orange-500/10 text-[#D94800] border-orange-500/30',
      badgeColor: 'from-amber-500 to-red-500',
      highlightTag: 'Maximum Throughput',
      highlight: false
    },
    {
      icon: Layers,
      title: 'Industrial-Grade Equipment',
      desc: 'Heavy-gauge steel construction, dynamic impeller balancing, and corrosion-resistant coatings built for extreme industrial plant environments.',
      gradient: 'from-teal-700 via-emerald-700 to-slate-900',
      accentBg: 'bg-teal-500/10 text-teal-800 border-teal-500/30',
      badgeColor: 'from-teal-500 to-emerald-600',
      highlightTag: 'Heavy-Gauge Build',
      highlight: false
    },
    {
      icon: Clock,
      title: 'Timely Delivery & Service Execution',
      desc: 'On-time project dispatch, zero-delay shutdown execution, and rapid mobile oil filtration unit deployment across all 5 states.',
      gradient: 'from-indigo-700 via-purple-700 to-slate-900',
      accentBg: 'bg-purple-500/10 text-purple-800 border-purple-500/30',
      badgeColor: 'from-indigo-500 to-purple-600',
      highlightTag: 'Rapid Field Deploy',
      highlight: false
    },
    {
      icon: Target,
      title: 'Application-Based Engineering Solutions',
      desc: 'Custom-engineered equipment tailored specifically for steel mills, mines, power stations, chemical plants, and cement works.',
      gradient: 'from-blue-700 via-indigo-700 to-slate-900',
      accentBg: 'bg-blue-500/10 text-blue-800 border-blue-500/30',
      badgeColor: 'from-blue-500 to-indigo-600',
      highlightTag: 'Custom Plant Specs',
      highlight: false
    }
  ];

  return (
    <section id="why-choose-us" className="py-16 sm:py-20 bg-[#F8FAF8] border-b border-[#DDE5DC]">
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header with Multi-Color Title */}
        <div className="text-center max-w-4xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-3 mb-3">
            <span className="h-[2.5px] w-12 sm:w-20 bg-[#2B7337] rounded-full" />
            <span className="w-3 h-3 rounded-full bg-[#2B7337] shrink-0 shadow-xs" />
            <span className="font-extrabold text-xs sm:text-sm tracking-widest text-[#2B7337] uppercase">
              ENGINEERING & SERVICE EXCELLENCE
            </span>
            <span className="w-3 h-3 rounded-full bg-[#2B7337] shrink-0 shadow-xs" />
            <span className="h-[2.5px] w-12 sm:w-20 bg-[#2B7337] rounded-full" />
          </div>

          {/* Multi-Color Title Shades */}
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight uppercase leading-tight">
            <span className="text-[#101820]">WHY CHOOSE </span>
            <span className="bg-gradient-to-r from-[#185C20] via-[#FF5B00] to-[#005596] bg-clip-text text-transparent drop-shadow-xs">
              SRP MEGHA POWER?
            </span>
          </h2>

          <p className="mt-3 text-sm sm:text-base text-gray-600 font-semibold max-w-2xl mx-auto">
            Advanced Filtration Technology, Certified Technical Experts & Premier Regional Fieldwork Support
          </p>
        </div>

        {/* 5 States Regional Reach Banner with Clean Equal-Width Grid */}
        <div className="mb-14 bg-gradient-to-br from-[#0A220F] via-[#12481A] to-[#0B2C11] rounded-3xl p-6 sm:p-8 lg:p-10 text-white shadow-2xl border border-emerald-700/40 relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-emerald-500/10 to-transparent blur-3xl pointer-events-none" />
          
          <div className="relative z-10 space-y-6">
            
            {/* Header / Intro inside banner */}
            <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-emerald-500/30 pb-5">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-bold text-xs uppercase tracking-wider shadow-inner">
                  <MapPin className="w-4 h-4 text-amber-400" />
                  <span>Regional Industrial Coverage</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-black tracking-tight text-white leading-tight">
                  Serving Key Industrial Hubs Across 5 Major States
                </h3>
              </div>

              <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed font-normal max-w-lg">
                Deploying rapid-response transformer oil filtration services, shutdown engineering, and heavy equipment maintenance across Eastern and Central India.
              </p>
            </div>

            {/* Equal-Width 5-State Cards Grid (Ensuring Chhattisgarh fits cleanly) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 w-full">
              {statesCovered.map((st, idx) => (
                <div 
                  key={idx} 
                  className={`p-4 rounded-2xl border flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] shadow-md min-w-0 ${
                    st.primary 
                      ? 'bg-gradient-to-b from-emerald-500/30 to-emerald-900/50 border-amber-400/70 text-white ring-1 ring-amber-400/30' 
                      : 'bg-white/10 border-white/20 text-emerald-50 hover:bg-white/20'
                  }`}
                >
                  <div>
                    {/* State Name & Map Pin */}
                    <div className="flex items-center justify-between gap-1 mb-2">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <MapPin className={`w-4 h-4 shrink-0 ${st.primary ? 'text-amber-300' : 'text-emerald-300'}`} />
                        <span className="font-extrabold text-sm sm:text-base tracking-wide text-white truncate">{st.name}</span>
                      </div>
                      {st.primary && (
                        <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-amber-400 text-black shrink-0">
                          HQ
                        </span>
                      )}
                    </div>

                    {/* Detail Description */}
                    <p className="text-xs text-emerald-100/80 leading-snug font-medium">
                      {st.detail}
                    </p>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>

        {/* Broadened Core Strengths Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-14">
          {coreStrengths.map((item, idx) => {
            const IconComp = item.icon;
            return (
              <div 
                key={idx}
                className={`rounded-3xl p-7 sm:p-8 border transition-all duration-300 flex flex-col justify-between group ${
                  item.highlight 
                    ? 'bg-gradient-to-br from-white via-slate-50 to-[#F2F8F0] border-[#185C20]/40 shadow-lg hover:shadow-2xl hover:-translate-y-1.5' 
                    : 'bg-white border-[#DDE5DC] shadow-xs hover:shadow-xl hover:-translate-y-1.5'
                }`}
              >
                <div>
                  {/* Top Row: Colorful Dual-Tone Badge & Icon */}
                  <div className="flex items-center justify-between mb-6">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${item.gradient} text-white flex items-center justify-center shrink-0 shadow-md transition-transform group-hover:scale-110`}>
                      <IconComp className="w-7 h-7" />
                    </div>

                    <span className={`inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider px-3 py-1.5 rounded-full border ${item.accentBg}`}>
                      <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      <span>{item.highlightTag}</span>
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg sm:text-xl font-black text-[#101820] tracking-tight mb-3 group-hover:text-[#185C20] transition-colors leading-snug">
                    {item.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-gray-600 leading-relaxed font-normal">
                    {item.desc}
                  </p>
                </div>

                {/* Bottom Verification Accent */}
                <div className="mt-8 pt-4 border-t border-gray-100 flex items-center justify-between text-xs font-bold text-[#185C20]">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#2B7337] shrink-0" />
                    <span>Certified Quality Standard</span>
                  </div>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Broadened Bottom Stats Strip */}
        <div className="bg-white rounded-3xl border border-[#DDE5DC] p-7 sm:p-10 shadow-md flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 w-full lg:w-auto text-center lg:text-left">
            <div>
              <span className="block text-3xl sm:text-4xl font-black text-[#185C20]">10+</span>
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Years Experience</span>
            </div>
            <div>
              <span className="block text-3xl sm:text-4xl font-black text-[#185C20]">500+</span>
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Projects Executed</span>
            </div>
            <div>
              <span className="block text-3xl sm:text-4xl font-black text-[#185C20]">5</span>
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">States Covered</span>
            </div>
            <div>
              <span className="block text-3xl sm:text-4xl font-black text-[#185C20]">24/7</span>
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Emergency Field Support</span>
            </div>
          </div>

          <button 
            onClick={onOpenQuote}
            className="w-full lg:w-auto shrink-0 bg-gradient-to-r from-[#185C20] via-[#104016] to-[#0A290E] hover:from-[#0F3B14] hover:to-[#051A08] text-white px-8 py-4.5 rounded-2xl font-extrabold text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-3 transition-all shadow-lg hover:shadow-xl hover:scale-102"
          >
            <span>DISCUSS YOUR REQUIREMENT</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};


