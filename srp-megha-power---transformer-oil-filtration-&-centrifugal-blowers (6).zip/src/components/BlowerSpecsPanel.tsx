import React from 'react';
import { Sliders, ArrowRight, ShieldCheck, Wind, Gauge, Layers, Thermometer, Settings, Wrench, ShieldAlert } from 'lucide-react';

interface BlowerSpecsPanelProps {
  onOpenQuote: (subject?: string) => void;
}

export const BlowerSpecsPanel: React.FC<BlowerSpecsPanelProps> = ({ onOpenQuote }) => {
  const specsList = [
    {
      title: 'Airflow Capacity',
      value: 'Up to 25,000 CMH',
      desc: 'Higher capacities available on application basis.',
      icon: Wind,
      accent: 'from-blue-500 to-indigo-600',
    },
    {
      title: 'Static Pressure',
      value: 'Up to 500 mmWG',
      desc: 'Higher pressure configurations subject to application requirements.',
      icon: Gauge,
      accent: 'from-amber-500 to-orange-600',
    },
    {
      title: 'Drive Arrangement',
      value: 'Direct Drive / Belt Drive / Coupled Drive',
      desc: 'Selected according to airflow, pressure and application requirements.',
      icon: Settings,
      accent: 'from-purple-500 to-violet-600',
    },
    {
      title: 'Construction Material',
      value: 'MS / SS304 / SS316 / FRP',
      desc: 'Material selected according to application and operating conditions.',
      icon: Layers,
      accent: 'from-teal-500 to-emerald-600',
    },
    {
      title: 'Operating Temperature',
      value: 'Application Dependent',
      desc: 'Blower configuration selected according to actual process temperature.',
      icon: Thermometer,
      accent: 'from-rose-500 to-red-600',
    },
    {
      title: 'Impeller',
      value: 'Application & Performance Based',
      desc: 'Impeller design selected according to airflow, pressure, RPM and system requirements.',
      icon: Wrench,
      accent: 'from-cyan-500 to-blue-600',
    },
    {
      title: 'Custom Engineering',
      value: 'Custom Engineering',
      desc: 'Blower configuration can be customized according to process requirements and actual site conditions.',
      icon: ShieldCheck,
      accent: 'from-amber-400 to-yellow-500',
    },
  ];

  return (
    <section className="py-12 bg-white border-b border-[#DDE5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="bg-gradient-to-br from-[#F4F7F4] via-white to-[#EBF3EC] text-gray-900 rounded-3xl p-6 sm:p-8 md:p-10 shadow-lg border border-emerald-200/80 relative overflow-hidden">
          {/* Subtle background ambient light */}
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-6 pb-6 mb-8 border-b border-gray-200 relative z-10">
            <div>
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-[#185C20] font-black text-xs uppercase tracking-wider mb-2 border border-emerald-300">
                <Sliders className="w-4 h-4 text-[#185C20]" />
                <span>TECHNICAL SPECIFICATION PARAMETERS</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-black tracking-tight text-[#101820] uppercase">
                CENTRIFUGAL BLOWER SPECIFICATIONS
              </h3>
            </div>

            <button 
              onClick={() => onOpenQuote('Custom Technical Consultation for Blower')}
              className="bg-[#185C20] hover:bg-emerald-800 text-white px-6 py-3.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-2 transition-all shadow-md hover:scale-102 cursor-pointer"
            >
              <span>REQUEST TECHNICAL CONSULTATION</span>
              <ArrowRight className="w-4 h-4 text-white shrink-0" />
            </button>
          </div>

          {/* Specs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs relative z-10">
            {specsList.map((spec, idx) => {
              const IconComp = spec.icon;
              return (
                <div 
                  key={idx} 
                  className={`bg-white p-5 rounded-2xl border border-gray-200/90 hover:border-emerald-500/80 hover:shadow-md transition-all duration-200 flex flex-col justify-between space-y-3 group ${
                    spec.title === 'Custom Engineering' ? 'sm:col-span-2 lg:col-span-1 bg-gradient-to-br from-amber-50/80 via-white to-white border-amber-300' : ''
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[#185C20] font-extrabold uppercase text-[11px] tracking-wider block">
                        {spec.title}
                      </span>
                      <div className={`p-2 rounded-xl bg-gradient-to-br ${spec.accent} text-white shadow-xs group-hover:scale-110 transition-transform`}>
                        <IconComp className="w-4 h-4" />
                      </div>
                    </div>
                    <p className="text-[#101820] font-extrabold text-base leading-snug">
                      {spec.value}
                    </p>
                  </div>
                  <p className="text-gray-600 text-[11px] leading-relaxed font-medium">
                    {spec.desc}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Professional Note at Bottom */}
          <div className="mt-8 pt-5 border-t border-gray-200 flex items-start gap-3 text-xs text-gray-700 relative z-10 bg-amber-50/90 p-4 rounded-2xl border border-amber-200">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <p className="text-[12px] leading-relaxed text-amber-950 font-medium">
              <strong className="text-amber-900 uppercase font-black">Note: </strong>
              Final blower selection, performance, motor power, RPM, material and construction will be confirmed based on actual system requirements, operating conditions and site parameters.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};

