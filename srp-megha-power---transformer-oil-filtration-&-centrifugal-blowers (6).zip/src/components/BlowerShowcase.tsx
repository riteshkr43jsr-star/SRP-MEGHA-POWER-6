import React, { useState } from 'react';
import { Wind, ArrowRight, Shield, CheckCircle2, Eye, Cpu } from 'lucide-react';
import { CENTRIFUGAL_BLOWERS } from '../data/companyData';
import { ProductItem } from '../types';
import { SITE_IMAGES } from '../config/images';
const featureBlowerImg = SITE_IMAGES.centrifugalBlower;

interface BlowerShowcaseProps {
  onSelectProduct: (product: ProductItem) => void;
  onOpenQuote: (productName: string) => void;
}

export const BlowerShowcase: React.FC<BlowerShowcaseProps> = ({ onSelectProduct, onOpenQuote }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All 16 Blowers' },
    { id: 'Heavy Duty', label: 'Heavy Duty & Draft' },
    { id: 'Process Air', label: 'Process & Furnace' },
    { id: 'High Pressure', label: 'High Pressure' },
    { id: 'Corrosion Resistant', label: 'Corrosion Resistant (FRP/SS)' },
    { id: 'Material Handling', label: 'Dust & Material' },
    { id: 'Ventilation', label: 'Ventilation & Cooling' }
  ];

  const filteredBlowers = activeCategory === 'all' 
    ? CENTRIFUGAL_BLOWERS 
    : CENTRIFUGAL_BLOWERS.filter(b => b.subcategory === activeCategory);

  return (
    <section id="blowers" className="py-16 bg-[#F7F9F6] border-b border-[#DDE5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAF4E6] text-[#185C20] font-bold text-xs uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-[#4D9B2A]" />
            PRODUCT RANGE B
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#101A24] tracking-tight">
            HEAVY-DUTY CENTRIFUGAL BLOWERS
          </h2>
          <p className="text-sm sm:text-base text-gray-600">
            High-Performance Air & Gas Handling Solutions Engineered for Steel Plants, Power Utilities, Cement Facilities, and Chemical Operations across India.
          </p>
        </div>

        {/* Main Spotlight Feature Area */}
        <div className="bg-white rounded-2xl border-2 border-[#185C20]/20 p-6 lg:p-8 shadow-md mb-12 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Spotlight Image */}
            <div className="lg:col-span-6 relative rounded-xl overflow-hidden group shadow-lg border border-[#DDE5DC]">
              <img 
                src={featureBlowerImg} 
                alt="Heavy Industrial Centrifugal Blower SRP Megha Power" 
                className="w-full h-[320px] sm:h-[380px] object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 left-4 bg-[#185C20] text-white text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wider shadow-sm">
                Industrial Heavy Duty Series
              </div>
            </div>

            {/* Right Spotlight Content */}
            <div className="lg:col-span-6 space-y-5 text-left">
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#4D9B2A] uppercase tracking-wider">
                <Wind className="w-4 h-4" />
                Air & Gas Handling Technology
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-[#101A24] tracking-tight leading-tight">
                ENGINEERED FOR INDUSTRIAL PERFORMANCE
              </h3>

              <p className="text-sm text-gray-600 leading-relaxed font-medium">
                High-efficiency centrifugal blower solutions designed for demanding industrial air movement, furnace combustion, process gas recirculation, dust collection, exhaust, and heavy material-handling applications.
              </p>

              {/* Specs Summary Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs pt-2">
                <div className="p-2.5 rounded-lg bg-[#F7F9F6] border border-[#DDE5DC]">
                  <span className="text-gray-500 block">Air Flow Capacity:</span>
                  <strong className="text-[#185C20] text-sm">Up to 25,000 CMH</strong>
                </div>
                <div className="p-2.5 rounded-lg bg-[#F7F9F6] border border-[#DDE5DC]">
                  <span className="text-gray-500 block">Static Pressure:</span>
                  <strong className="text-[#185C20] text-sm">Up to 500 mmWG</strong>
                </div>
                <div className="p-2.5 rounded-lg bg-[#F7F9F6] border border-[#DDE5DC]">
                  <span className="text-gray-500 block">Impeller Design:</span>
                  <strong className="text-[#101A24] text-sm">Application Based</strong>
                </div>
                <div className="p-2.5 rounded-lg bg-[#F7F9F6] border border-[#DDE5DC]">
                  <span className="text-gray-500 block">Construction MOC:</span>
                  <strong className="text-[#101A24] text-sm">MS / SS304 / SS316 / FRP</strong>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 pt-2">
                <button 
                  onClick={() => onOpenQuote('Centrifugal Blower Solution')}
                  className="bg-[#185C20] hover:bg-[#0D3F18] text-white px-6 py-3 rounded-lg font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors shadow-sm"
                >
                  <span>REQUEST BLOWER SELECTION</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>
        </div>



        {/* Complete 16 Blower Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
          {filteredBlowers.map((blower: ProductItem) => (
            <div 
              key={blower.id}
              className="bg-white rounded-xl border border-[#DDE5DC] p-5 shadow-2xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <div className="relative rounded-lg overflow-hidden mb-4 h-44">
                  {blower.image ? (
                    <>
                      <img 
                        src={blower.image} 
                        alt={blower.name} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      {blower.badge && (
                        <span className="absolute top-2 right-2 bg-[#185C20] text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs uppercase tracking-wider">
                          {blower.badge}
                        </span>
                      )}
                    </>
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-[#0D3F18] via-[#185C20] to-[#101A24] p-4 flex flex-col justify-between text-white border border-emerald-800/40">
                      <div className="flex items-center justify-between">
                        <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 flex items-center justify-center font-bold">
                          <Wind className="w-4 h-4 text-emerald-400" />
                        </div>
                        {blower.badge && (
                          <span className="bg-emerald-500/30 text-emerald-200 border border-emerald-400/40 text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                            {blower.badge}
                          </span>
                        )}
                      </div>
                      <div>
                        <span className="text-[9px] font-extrabold uppercase tracking-widest text-emerald-300/80 block">
                          CENTRIFUGAL BLOWER SERIES
                        </span>
                        <span className="text-xs font-black text-white tracking-tight line-clamp-1">
                          {blower.subcategory || 'Heavy Industrial'}
                        </span>
                      </div>
                    </div>
                  )}
                  <span className="absolute bottom-2 left-2 bg-black/70 text-white text-[10px] px-2 py-0.5 rounded font-mono">
                    {blower.subcategory || 'Centrifugal'}
                  </span>
                </div>

                <h4 className="font-bold text-base text-[#101A24] group-hover:text-[#185C20] transition-colors mb-2 line-clamp-2">
                  {blower.name}
                </h4>

                <p className="text-xs text-gray-600 line-clamp-2 mb-4 leading-relaxed">
                  {blower.shortDesc}
                </p>

                {/* Key Specs Preview */}
                <div className="bg-[#F7F9F6] p-2.5 rounded-lg border border-[#DDE5DC] mb-4 text-[11px] space-y-1 text-gray-700">
                  {blower.specs.slice(0, 2).map((spec, sIdx) => (
                    <div key={sIdx} className="flex items-center gap-1.5 truncate">
                      <CheckCircle2 className="w-3 h-3 text-[#4D9B2A] shrink-0" />
                      <span className="truncate">{spec}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-gray-100">
                <button 
                  onClick={() => onOpenQuote(blower.name)}
                  className="w-full bg-[#185C20] hover:bg-[#0D3F18] text-white py-2 rounded-lg text-xs font-black uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <span>Get a Quote</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={() => onSelectProduct(blower)}
                  className="w-full bg-[#EAF4E6] hover:bg-slate-200 text-[#185C20] py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Details</span>
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
