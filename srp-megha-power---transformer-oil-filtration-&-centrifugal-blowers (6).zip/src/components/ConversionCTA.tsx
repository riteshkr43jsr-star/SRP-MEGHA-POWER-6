import React from 'react';
import { ArrowRight, PhoneCall, ShieldCheck, Mail, MessageSquare } from 'lucide-react';
import { COMPANY_DETAILS } from '../data/companyData';

interface ConversionCTAProps {
  onOpenQuote: () => void;
}

export const ConversionCTA: React.FC<ConversionCTAProps> = ({ onOpenQuote }) => {
  const scrollToContact = () => {
    const el = document.getElementById('contact');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative bg-[#0D3F18] text-white py-16 overflow-hidden">
      {/* Industrial Engineering Pattern Overlay */}
      <div className="absolute inset-0 z-0 bg-grid-pattern opacity-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-6">
        
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#4D9B2A]/30 border border-[#4D9B2A] text-emerald-200 font-bold text-xs uppercase tracking-wider">
          <ShieldCheck className="w-4 h-4 text-[#4D9B2A]" />
          READY TO ELEVATE YOUR PLANT RELIABILITY?
        </div>

        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight max-w-4xl mx-auto leading-tight">
          NEED A RELIABLE INDUSTRIAL SOLUTION?
        </h2>

        <p className="text-sm sm:text-base text-gray-200 max-w-2xl mx-auto leading-relaxed font-medium">
          Talk to our technical team about transformer oil filtration machines, on-site oil conditioning services, and high-efficiency centrifugal blowers today.
        </p>

        {/* Highlighted Direct Contact Badges */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <a 
            href={`tel:${COMPANY_DETAILS.phonePrimary}`} 
            className="bg-white/10 hover:bg-white/20 border border-white/20 px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold text-white flex items-center gap-2 transition-all shadow-md"
          >
            <PhoneCall className="w-4 h-4 text-[#4D9B2A]" />
            <span>Call: <strong>{COMPANY_DETAILS.phonePrimary}</strong></span>
          </a>

          <a 
            href={`https://wa.me/${COMPANY_DETAILS.whatsappNumber}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/40 px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold text-white flex items-center gap-2 transition-all shadow-md"
          >
            <MessageSquare className="w-4 h-4 text-[#25D366] fill-current" />
            <span>WhatsApp: <strong>+91 91624 84535</strong></span>
          </a>

          <a 
            href={`mailto:${COMPANY_DETAILS.email}`} 
            className="bg-white/10 hover:bg-white/20 border border-white/20 px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold text-white flex items-center gap-2 transition-all shadow-md"
          >
            <Mail className="w-4 h-4 text-[#4D9B2A]" />
            <span>Email: <strong>{COMPANY_DETAILS.email}</strong></span>
          </a>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          <button 
            onClick={onOpenQuote}
            className="bg-[#4D9B2A] hover:bg-[#185C20] text-white px-8 py-4 rounded-xl font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 shadow-xl hover:shadow-2xl transition-all duration-200 group"
          >
            <span>GET A QUOTE</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button 
            onClick={scrollToContact}
            className="bg-white/10 hover:bg-white/20 text-white border-2 border-white/30 px-8 py-3.5 rounded-xl font-extrabold text-xs uppercase tracking-wider transition-colors flex items-center gap-2"
          >
            <PhoneCall className="w-4 h-4" />
            <span>DIRECT CONTACT FORM</span>
          </button>
        </div>

      </div>
    </section>
  );
};
