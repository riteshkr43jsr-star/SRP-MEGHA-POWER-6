import React from 'react';
import { 
  Factory, 
  Pickaxe, 
  Cog, 
  Zap, 
  Building2, 
  Car, 
  FlaskConical, 
  Briefcase,
  ArrowRight
} from 'lucide-react';
import { INDUSTRIES_SERVED } from '../data/companyData';

interface IndustriesWeServeProps {
  onOpenQuote: (industryName: string) => void;
}

export const IndustriesWeServe: React.FC<IndustriesWeServeProps> = ({ onOpenQuote }) => {
  const getIndustryStyle = (id: string) => {
    switch (id) {
      case 'ind-steel':
        return {
          gradient: 'from-amber-600 via-orange-600 to-red-700',
          accent: 'text-amber-300',
          badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-400/30',
          iconBg: 'bg-gradient-to-br from-amber-500 to-orange-600',
          tag: 'Primary Steel Mill'
        };
      case 'ind-mining':
        return {
          gradient: 'from-amber-700 via-yellow-700 to-emerald-800',
          accent: 'text-yellow-300',
          badgeBg: 'bg-yellow-500/20 text-yellow-300 border-yellow-400/30',
          iconBg: 'bg-gradient-to-br from-yellow-500 to-amber-700',
          tag: 'Heavy Mining'
        };
      case 'ind-manufacturing':
        return {
          gradient: 'from-blue-600 via-indigo-600 to-violet-800',
          accent: 'text-cyan-300',
          badgeBg: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/30',
          iconBg: 'bg-gradient-to-br from-cyan-500 to-blue-600',
          tag: 'Industrial Plant'
        };
      case 'ind-power':
        return {
          gradient: 'from-red-600 via-rose-600 to-orange-700',
          accent: 'text-orange-300',
          badgeBg: 'bg-orange-500/20 text-orange-300 border-orange-400/30',
          iconBg: 'bg-gradient-to-br from-red-500 to-rose-600',
          tag: 'Thermal & Utility'
        };
      case 'ind-cement':
        return {
          gradient: 'from-emerald-600 via-teal-700 to-slate-800',
          accent: 'text-emerald-300',
          badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30',
          iconBg: 'bg-gradient-to-br from-emerald-500 to-teal-700',
          tag: 'Kiln & Clinker'
        };
      case 'ind-automotive':
        return {
          gradient: 'from-sky-600 via-blue-600 to-indigo-800',
          accent: 'text-sky-300',
          badgeBg: 'bg-sky-500/20 text-sky-300 border-sky-400/30',
          iconBg: 'bg-gradient-to-br from-sky-500 to-blue-600',
          tag: 'Assembly Plant'
        };
      case 'ind-chemical':
        return {
          gradient: 'from-purple-600 via-fuchsia-600 to-indigo-800',
          accent: 'text-fuchsia-300',
          badgeBg: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-400/30',
          iconBg: 'bg-gradient-to-br from-purple-500 to-fuchsia-600',
          tag: 'Process Utility'
        };
      case 'ind-infrastructure':
      default:
        return {
          gradient: 'from-teal-600 via-emerald-600 to-slate-900',
          accent: 'text-teal-300',
          badgeBg: 'bg-teal-500/20 text-teal-300 border-teal-400/30',
          iconBg: 'bg-gradient-to-br from-teal-500 to-emerald-700',
          tag: 'Heavy Civil'
        };
    }
  };

  const getIndustryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Factory':
        return <Factory className="w-6 h-6 text-white" />;
      case 'Pickaxe':
        return <Pickaxe className="w-6 h-6 text-white" />;
      case 'Cog':
        return <Cog className="w-6 h-6 text-white" />;
      case 'Zap':
        return <Zap className="w-6 h-6 text-white" />;
      case 'Building':
      case 'Building2':
        return <Building2 className="w-6 h-6 text-white" />;
      case 'Car':
        return <Car className="w-6 h-6 text-white" />;
      case 'FlaskConical':
        return <FlaskConical className="w-6 h-6 text-white" />;
      case 'Briefcase':
      default:
        return <Briefcase className="w-6 h-6 text-white" />;
    }
  };

  return (
    <section id="industries" className="py-16 bg-[#F8FAF8] border-b border-[#DDE5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-3 mb-2">
            <span className="h-[2px] w-10 sm:w-16 bg-[#2B7337] rounded-full" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#2B7337] shrink-0" />
            <h2 className="text-2xl sm:text-3xl font-black text-[#101820] tracking-tight uppercase px-1">
              INDUSTRIES WE SERVE
            </h2>
            <span className="w-2.5 h-2.5 rounded-full bg-[#2B7337] shrink-0" />
            <span className="h-[2px] w-10 sm:w-16 bg-[#2B7337] rounded-full" />
          </div>
          <p className="text-sm sm:text-base text-gray-600 font-medium">
            Reliable Solutions for Critical Industries
          </p>
        </div>

        {/* 8 Items Colorful Card Grid - Pure Typographic & Graphic Design (NO IMAGES / PHOTOS) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {INDUSTRIES_SERVED.map((ind) => {
            const style = getIndustryStyle(ind.id);
            return (
              <div 
                key={ind.id}
                onClick={() => onOpenQuote(`Solutions for ${ind.name}`)}
                className={`bg-[#0D151D] rounded-2xl overflow-hidden border shadow-md hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 flex flex-col cursor-pointer group ${
                  ind.id === 'ind-steel'
                    ? 'border-orange-500/50 hover:border-orange-400 hover:ring-4 hover:ring-orange-500/30 hover:shadow-orange-500/20'
                    : ind.id === 'ind-mining'
                    ? 'border-yellow-500/50 hover:border-yellow-300 hover:ring-4 hover:ring-yellow-400/30 hover:shadow-yellow-500/20'
                    : 'border-gray-800 hover:border-emerald-500/60 hover:ring-2 hover:ring-emerald-500/20'
                }`}
              >
                {/* Vibrant Graphic Header Banner (No Photos/Images) */}
                <div className={`relative h-44 sm:h-48 w-full bg-gradient-to-br ${style.gradient} p-5 flex flex-col justify-between overflow-hidden shadow-inner`}>
                  {/* Background Geometric Accent Circle */}
                  <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none" />
                  <div className="absolute -left-6 -top-6 w-28 h-28 rounded-full bg-black/20 blur-lg pointer-events-none" />
                  
                  {/* Top Row Badge & Icon */}
                  <div className="relative z-10 flex items-center justify-between">
                    <span className={`text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-1 rounded-full border backdrop-blur-md ${style.badgeBg}`}>
                      {style.tag}
                    </span>
                    <div className={`w-11 h-11 rounded-xl ${style.iconBg} p-2.5 shadow-lg border border-white/20 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}>
                      {getIndustryIcon(ind.icon)}
                    </div>
                  </div>

                  {/* Header Title Text */}
                  <div className="relative z-10 mt-auto">
                    <h3 className="font-black text-lg sm:text-xl text-white tracking-wide uppercase leading-tight drop-shadow-md">
                      {ind.name}
                    </h3>
                  </div>
                </div>

                {/* Dark Content Body */}
                <div className="p-5 bg-[#0D151D] flex-1 flex flex-col justify-between gap-4 border-t border-gray-800/80">
                  <p className="text-xs text-gray-300 leading-relaxed font-normal">
                    {ind.description}
                  </p>

                  <div className="pt-2 flex items-center justify-between text-xs font-bold text-emerald-400 group-hover:text-emerald-300 transition-colors border-t border-gray-800/50">
                    <span>Inquire for {ind.name}</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

