import React from 'react';
import { 
  Droplets, 
  Flame, 
  Sparkles, 
  FlaskConical, 
  Wrench, 
  Headset, 
  Zap,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { SERVICES } from '../data/companyData';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onOpenQuote: (serviceTitle: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenQuote }) => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Zap': return <Zap className="w-6 h-6 text-[#185C20]" />;
      case 'Droplets': return <Droplets className="w-6 h-6 text-[#185C20]" />;
      case 'Flame': return <Flame className="w-6 h-6 text-[#185C20]" />;
      case 'Sparkles': return <Sparkles className="w-6 h-6 text-[#185C20]" />;
      case 'FlaskConical': return <FlaskConical className="w-6 h-6 text-[#185C20]" />;
      case 'Wrench': return <Wrench className="w-6 h-6 text-[#185C20]" />;
      case 'Headset': return <Headset className="w-6 h-6 text-[#185C20]" />;
      default: return <Droplets className="w-6 h-6 text-[#185C20]" />;
    }
  };

  return (
    <section id="services" className="py-16 bg-[#F7F9F6] border-b border-[#DDE5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAF4E6] text-[#185C20] font-bold text-xs uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-[#4D9B2A]" />
            OUR SERVICES
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#101A24] tracking-tight">
            Reliable Engineering Services for Critical Industrial Equipment
          </h2>
          <p className="text-sm sm:text-base text-gray-600">
            From high-vacuum transformer oil purification to preventive substation maintenance and commissioning, SRP Megha Power delivers certified technical excellence.
          </p>
        </div>

        {/* 6 Service Cards Grid with Unique Distinct Color Identities */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((service: ServiceItem, idx: number) => {
            // Assign non-repeating unique color schemes for each card
            const themes = [
              {
                borderHover: 'hover:border-emerald-500 hover:shadow-emerald-500/15',
                topBar: 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600',
                iconBg: 'bg-gradient-to-br from-[#0B1E38] to-[#133A20] text-emerald-400 border-emerald-500/30',
                badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-200',
                checkColor: 'text-emerald-600',
                btnBg: 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-600 hover:text-white',
                titleHover: 'group-hover:text-emerald-700'
              },
              {
                borderHover: 'hover:border-blue-500 hover:shadow-blue-500/15',
                topBar: 'bg-gradient-to-r from-blue-600 via-cyan-400 to-indigo-600',
                iconBg: 'bg-gradient-to-br from-[#0B1E38] to-[#0A2540] text-cyan-400 border-cyan-500/30',
                badgeBg: 'bg-blue-100 text-blue-900 border-blue-200',
                checkColor: 'text-blue-600',
                btnBg: 'bg-blue-50 text-blue-800 border border-blue-200 hover:bg-blue-600 hover:text-white',
                titleHover: 'group-hover:text-blue-700'
              },
              {
                borderHover: 'hover:border-amber-500 hover:shadow-amber-500/15',
                topBar: 'bg-gradient-to-r from-amber-500 via-orange-400 to-rose-500',
                iconBg: 'bg-gradient-to-br from-[#0B1E38] to-[#2E1800] text-amber-400 border-amber-500/30',
                badgeBg: 'bg-amber-100 text-amber-900 border-amber-200',
                checkColor: 'text-amber-600',
                btnBg: 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-600 hover:text-white',
                titleHover: 'group-hover:text-amber-700'
              },
              {
                borderHover: 'hover:border-purple-500 hover:shadow-purple-500/15',
                topBar: 'bg-gradient-to-r from-purple-600 via-fuchsia-400 to-indigo-600',
                iconBg: 'bg-gradient-to-br from-[#0B1E38] to-[#210D38] text-purple-300 border-purple-500/30',
                badgeBg: 'bg-purple-100 text-purple-900 border-purple-200',
                checkColor: 'text-purple-600',
                btnBg: 'bg-purple-50 text-purple-900 border border-purple-200 hover:bg-purple-600 hover:text-white',
                titleHover: 'group-hover:text-purple-700'
              },
              {
                borderHover: 'hover:border-rose-500 hover:shadow-rose-500/15',
                topBar: 'bg-gradient-to-r from-rose-600 via-pink-400 to-red-600',
                iconBg: 'bg-gradient-to-br from-[#0B1E38] to-[#360B18] text-rose-300 border-rose-500/30',
                badgeBg: 'bg-rose-100 text-rose-900 border-rose-200',
                checkColor: 'text-rose-600',
                btnBg: 'bg-rose-50 text-rose-900 border border-rose-200 hover:bg-rose-600 hover:text-white',
                titleHover: 'group-hover:text-rose-700'
              },
              {
                borderHover: 'hover:border-teal-500 hover:shadow-teal-500/15',
                topBar: 'bg-gradient-to-r from-teal-500 via-emerald-400 to-cyan-600',
                iconBg: 'bg-gradient-to-br from-[#0B1E38] to-[#0D2E28] text-teal-300 border-teal-500/30',
                badgeBg: 'bg-teal-100 text-teal-900 border-teal-200',
                checkColor: 'text-teal-600',
                btnBg: 'bg-teal-50 text-teal-900 border border-teal-200 hover:bg-teal-600 hover:text-white',
                titleHover: 'group-hover:text-teal-700'
              }
            ];

            const theme = themes[idx % themes.length];

            return (
              <div 
                key={service.id}
                className={`relative bg-white rounded-2xl border-2 border-slate-200 p-6 shadow-sm hover:shadow-2xl hover:-translate-y-1.5 ${theme.borderHover} transition-all duration-300 flex flex-col justify-between group overflow-hidden`}
              >
                <div className={`absolute top-0 left-0 right-0 h-1.5 ${theme.topBar}`} />
                
                <div>
                  {/* Icon & Title Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-13 h-13 rounded-2xl ${theme.iconBg} flex items-center justify-center shadow-md border group-hover:scale-110 transition-transform duration-300`}>
                      {getIcon(service.iconName)}
                    </div>
                    <span className={`text-[11px] font-extrabold uppercase px-2.5 py-1 rounded-full border ${theme.badgeBg}`}>
                      Certified Service
                    </span>
                  </div>

                  <h3 className={`text-lg font-black text-[#0B1E38] ${theme.titleHover} transition-colors mb-2`}>
                    {service.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-600 mb-4 leading-relaxed font-medium">
                    {service.description}
                  </p>

                  {/* Features Checklist */}
                  <ul className="space-y-2 mb-6 border-t border-slate-100 pt-4">
                    {service.features.map((feat, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-2 text-xs font-bold text-slate-700">
                        <CheckCircle2 className={`w-4 h-4 ${theme.checkColor} shrink-0 mt-0.5`} />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Button */}
                <button 
                  onClick={() => onOpenQuote(service.title)}
                  className={`w-full ${theme.btnBg} py-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all duration-200 shadow-2xs group-hover:shadow-md`}
                >
                  <span>REQUEST SERVICE</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                </button>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
