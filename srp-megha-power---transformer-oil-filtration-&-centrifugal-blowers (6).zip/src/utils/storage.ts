import { QuoteFormData } from '../types';
import { supabase } from '../supabase';

export interface SavedQuote extends QuoteFormData {
  id: string;
  serialNumber?: number; // Sequential ERP serial number: 1, 2, 3...
  date: string;
  status: 'Pending' | 'Approved' | 'Working On' | 'Remaining' | 'Received';
  notes?: string;
  estimatedValue?: number; // Estimated deal value in INR
  priority?: 'High' | 'Medium' | 'Normal';
  followUpDate?: string;
  source?: 'Website RFQ' | 'Direct Call' | 'WhatsApp' | 'Walk-in Workshop';
}

const STORAGE_KEY = 'srp_megha_quotes_db';
const SETTINGS_KEY = 'srp_admin_settings';

// Initial seed quotes so the admin panel has representative real-world data if opened fresh
const INITIAL_SEED_QUOTES: SavedQuote[] = [
  {
    serialNumber: 1,
    id: 'ENQ-2026-001',
    fullName: 'Rajesh Sharma',
    companyName: 'Tata Steel Substation Division',
    phone: '+91 94311 25480',
    email: 'r.sharma@tatasteel.com',
    serviceOrProduct: '10,000 LPH High Vacuum Transformer Oil Filtration Machine',
    quantityOrCapacity: '1 Unit (10,000 LPH)',
    message: 'Urgent requirement for high-vacuum oil dehydration machine for 400kV transformer overhauling at Jamshedpur plant.',
    date: new Date(Date.now() - 3600000 * 4).toISOString(), // 4 hours ago
    status: 'Pending',
    priority: 'High',
    estimatedValue: 1850000,
    source: 'Website RFQ',
    notes: 'Urgent requirement for upcoming maintenance shutdown. Need technical brochure with BDV warranty.'
  },
  {
    serialNumber: 2,
    id: 'ENQ-2026-002',
    fullName: 'Amitava Mukherjee',
    companyName: 'Durgapur Projects Limited',
    phone: '+91 98320 44120',
    email: 'amukherjee@dpl.gov.in',
    serviceOrProduct: 'Heavy Centrifugal Blower (25,000 CMH)',
    quantityOrCapacity: '2 Sets',
    message: 'Quotation needed for 2 sets of high-pressure centrifugal induced draft fans with MS casing and dynamic balancing.',
    date: new Date(Date.now() - 3600000 * 18).toISOString(), // 18 hours ago
    status: 'Working On',
    priority: 'Medium',
    estimatedValue: 620000,
    source: 'Direct Call',
    notes: 'Initial drawing discussed. Technical team calculating static pressure requirements.'
  },
  {
    serialNumber: 3,
    id: 'ENQ-2026-003',
    fullName: 'Subhashish Panda',
    companyName: 'Rourkela Steel Plant (SAIL)',
    phone: '+91 94370 89115',
    email: 'spanda@sail-rsp.co.in',
    serviceOrProduct: 'Substation Transformer Oil Filtration & BDV Testing',
    quantityOrCapacity: '2x 50MVA Transformers',
    message: 'Require mobile on-site oil filtration trolley for 2x 50MVA generator transformers during annual shutdown.',
    date: new Date(Date.now() - 3600000 * 36).toISOString(), // 36 hours ago
    status: 'Approved',
    priority: 'High',
    estimatedValue: 380000,
    source: 'Website RFQ',
    notes: 'Purchase Order issued! Mobilization date scheduled for 10th of next month.'
  },
  {
    serialNumber: 4,
    id: 'ENQ-2026-004',
    fullName: 'Rameshwar Verma',
    companyName: 'Jindal Steel & Power Ltd, Raigarh',
    phone: '+91 97555 12890',
    email: 'r.verma@jspl.com',
    serviceOrProduct: 'Transformer Rewinding & Hot Oil Circulation',
    quantityOrCapacity: '33kV Substation Unit',
    message: 'Insulation resistance degraded after monsoon moisture ingress. Need complete dehydration & filtration service.',
    date: new Date(Date.now() - 3600000 * 72).toISOString(),
    status: 'Remaining',
    priority: 'Normal',
    estimatedValue: 290000,
    source: 'WhatsApp',
    notes: 'Customer requested inspection visit to Raigarh substation.'
  }
];

// Metadata packing into Supabase quotes table 'message' column
export const serializeMessageWithMeta = (quote: { 
  message?: string; 
  serialNumber?: number; 
  quantityOrCapacity?: string; 
  notes?: string; 
  priority?: string; 
  estimatedValue?: number; 
  source?: string; 
  followUpDate?: string 
}): string => {
  const meta: any = {};
  if (typeof quote.serialNumber === 'number' && quote.serialNumber > 0) meta.serialNumber = quote.serialNumber;
  if (quote.quantityOrCapacity) meta.quantityOrCapacity = quote.quantityOrCapacity;
  if (quote.notes) meta.notes = quote.notes;
  if (quote.priority) meta.priority = quote.priority;
  if (typeof quote.estimatedValue === 'number') meta.estimatedValue = quote.estimatedValue;
  if (quote.source) meta.source = quote.source;
  if (quote.followUpDate) meta.followUpDate = quote.followUpDate;

  const baseMessage = quote.message || '';
  if (Object.keys(meta).length === 0) return baseMessage;
  return `${baseMessage}\n\n<!--SRP_META:${JSON.stringify(meta)}-->`;
};

export const deserializeMessageWithMeta = (rawMessage: string | null | undefined): { message: string; meta: any } => {
  if (!rawMessage) return { message: '', meta: {} };
  const match = rawMessage.match(/<!--SRP_META:(.*?)-->/s);
  if (match) {
    try {
      const meta = JSON.parse(match[1]);
      const cleanMessage = rawMessage.replace(/<!--SRP_META:.*?-->/s, '').trim();
      return { message: cleanMessage, meta };
    } catch (e) {
      return { message: rawMessage, meta: {} };
    }
  }
  return { message: rawMessage, meta: {} };
};

// Helper to get raw quotes from localStorage with guaranteed serial ordering
const getStoredQuotesRaw = (): SavedQuote[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_SEED_QUOTES));
      return INITIAL_SEED_QUOTES;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return INITIAL_SEED_QUOTES;
    }

    // Ensure every record has a valid serial number and migrate any legacy 50,000 LPH references to 10,000 LPH
    let modified = false;
    parsed.forEach((q: any) => {
      if (typeof q.serviceOrProduct === 'string' && /50,?000\s*LPH/i.test(q.serviceOrProduct)) {
        q.serviceOrProduct = q.serviceOrProduct.replace(/50,?000\s*LPH/gi, '10,000 LPH');
        modified = true;
      }
      if (typeof q.quantityOrCapacity === 'string' && /50,?000\s*LPH/i.test(q.quantityOrCapacity)) {
        q.quantityOrCapacity = q.quantityOrCapacity.replace(/50,?000\s*LPH/gi, '10,000 LPH');
        modified = true;
      }
      if (typeof q.message === 'string' && /50,?000\s*LPH/i.test(q.message)) {
        q.message = q.message.replace(/50,?000\s*LPH/gi, '10,000 LPH');
        modified = true;
      }
    });
    const hasMissingSerial = parsed.some(q => typeof q.serialNumber !== 'number' || q.serialNumber <= 0);
    if (hasMissingSerial) {
      // Sort oldest to newest to assign sequential serial numbers
      const sortedByDate = [...parsed].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      sortedByDate.forEach((q, idx) => {
        if (typeof q.serialNumber !== 'number' || q.serialNumber <= 0) {
          q.serialNumber = idx + 1;
          modified = true;
        }
      });
      if (modified) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sortedByDate));
        return sortedByDate;
      }
    }
    if (modified) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
    }
    return parsed;
  } catch (e) {
    console.warn('Error reading from localStorage, using fallback', e);
    return INITIAL_SEED_QUOTES;
  }
};

// Helper to write raw quotes to localStorage and notify listeners
const setStoredQuotesRaw = (quotes: SavedQuote[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(quotes));
    // Dispatch events for immediate UI update in any open component / tab
    window.dispatchEvent(new CustomEvent('srp_quotes_updated', { detail: quotes }));
    window.dispatchEvent(new Event('storage'));
  } catch (e) {
    console.error('Error saving quotes to localStorage', e);
  }
};

export const sendQuoteEmailNotification = async (quote: SavedQuote): Promise<{ success: boolean; message: string }> => {
  try {
    const payload = {
      _subject: `[SRP RFQ Alert #${quote.id}] ${quote.serviceOrProduct} - ${quote.fullName}`,
      _cc: 'srpmeghapower11@gmail.com,riteshkr43jsr@gmail.com',
      _template: 'table',
      _captcha: 'false',
      RFQ_ID: quote.id,
      Serial_Number: `#${String(quote.serialNumber || 1).padStart(3, '0')}`,
      Submission_Date: new Date(quote.date).toLocaleString('en-IN'),
      Customer_Name: quote.fullName,
      Company: quote.companyName || 'Not specified',
      Phone_Number: quote.phone,
      Customer_Email: quote.email || 'Not specified',
      Service_Or_Product: quote.serviceOrProduct,
      Quantity_Or_Capacity: quote.quantityOrCapacity || 'Industrial Standard',
      Customer_Message: quote.message || 'No additional note',
      Estimated_Value: quote.estimatedValue ? `₹${quote.estimatedValue.toLocaleString('en-IN')}` : 'To Be Estimated',
      Status: quote.status,
      Priority: quote.priority || 'Normal',
      Office_Address: '1st Floor, New Kalimati Road, Near Chandra Hotel, P.O. & P.S. Sakchi, Jamshedpur, East Singhbhum, Jharkhand – 831001',
      Admin_Portal: `${window.location.origin}/#admin`
    };

    const [primaryRes, secondaryRes] = await Promise.allSettled([
      fetch('https://formsubmit.co/ajax/srpmeghapower11@gmail.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload)
      }),
      fetch('https://formsubmit.co/ajax/riteshkr43jsr@gmail.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload)
      })
    ]);

    let isSuccess = false;
    for (const r of [primaryRes, secondaryRes]) {
      if (r.status === 'fulfilled' && r.value.ok) {
        const data = await r.value.json().catch(() => ({}));
        if (data.success === 'true' || data.success === true) {
          isSuccess = true;
        }
      }
    }

    if (isSuccess) {
      return { success: true, message: 'Notification delivered to srpmeghapower11@gmail.com & riteshkr43jsr@gmail.com' };
    } else {
      return { success: false, message: 'FormSubmit activation link sent to Gmail inbox — click Activate once in Gmail' };
    }
  } catch (err: any) {
    console.warn('Background email dispatch error:', err);
    return { success: false, message: err?.message || 'Network request failed' };
  }
};

export const saveQuote = async (quote: QuoteFormData): Promise<SavedQuote> => {
  // Query all quotes from cloud or local cache to calculate next serial
  let existing: SavedQuote[] = [];
  try {
    const { data: cloudQuotes } = await supabase
      .from('quotes')
      .select('id, date, message')
      .order('date', { ascending: false });
    
    if (cloudQuotes && cloudQuotes.length > 0) {
      existing = cloudQuotes.map((r, idx) => {
        const { meta } = deserializeMessageWithMeta(r.message);
        return {
          id: r.id,
          serialNumber: meta?.serialNumber || (cloudQuotes.length - idx),
          date: r.date
        } as SavedQuote;
      });
    } else {
      existing = getStoredQuotesRaw();
    }
  } catch (err) {
    existing = getStoredQuotesRaw();
  }

  const maxSerial = existing.reduce((max, q) => Math.max(max, q.serialNumber || 0), 0);
  const nextSerial = maxSerial > 0 ? maxSerial + 1 : existing.length + 1;
  const year = new Date().getFullYear();
  const serialId = `ENQ-${year}-${String(nextSerial).padStart(3, '0')}`;

  const newQuote: SavedQuote = {
    ...quote,
    serialNumber: nextSerial,
    id: serialId,
    date: new Date().toISOString(),
    status: 'Pending',
    priority: 'High',
    source: 'Website RFQ'
  };

  // 1. Pack metadata into Supabase message column
  const messageWithMeta = serializeMessageWithMeta(newQuote);

  // 2. Insert into cloud Supabase database (Universal: Mobile, Tablet, Desktop)
  try {
    const { error: insertError } = await supabase.from('quotes').insert([{
      id: serialId,
      date: newQuote.date,
      status: newQuote.status,
      fullName: newQuote.fullName,
      companyName: newQuote.companyName || '',
      phone: newQuote.phone,
      email: newQuote.email || '',
      serviceOrProduct: newQuote.serviceOrProduct,
      message: messageWithMeta
    }]);

    if (insertError) {
      console.warn('Supabase insert warning, saved locally:', insertError);
    } else {
      console.log(`☁️ Quote #${nextSerial} successfully saved to Cloud Supabase:`, serialId);
    }
  } catch (err) {
    console.warn('Supabase network error, fallback to local storage:', err);
  }

  // 3. Cache in local storage for instant offline capability
  const localExisting = getStoredQuotesRaw();
  const updated = [newQuote, ...localExisting.filter(q => q.id !== serialId)];
  setStoredQuotesRaw(updated);

  // 4. Automatically dispatch background notification to admin email
  sendQuoteEmailNotification(newQuote).catch(err => {
    console.warn('Auto-forward to admin email failed silently:', err);
  });

  return newQuote;
};

export const getQuotes = async (): Promise<SavedQuote[]> => {
  try {
    const { data, error } = await supabase
      .from('quotes')
      .select('*')
      .order('date', { ascending: false });

    if (error || !data || data.length === 0) {
      console.warn('Using local quotes fallback (Supabase returned empty or error):', error);
      return getStoredQuotesRaw();
    }

    // Convert Supabase rows to SavedQuote models
    const quotesFromCloud: SavedQuote[] = data.map((row: any, index: number) => {
      const { message, meta } = deserializeMessageWithMeta(row.message);
      // Determine serial: from metadata or fallback to index from bottom
      const assignedSerial = typeof meta?.serialNumber === 'number' && meta.serialNumber > 0 
        ? meta.serialNumber 
        : (data.length - index);

      const rawService = (row.serviceOrProduct || 'Industrial Equipment').replace(/50,?000\s*LPH/gi, '10,000 LPH');
      const rawCapacity = (meta?.quantityOrCapacity || '').replace(/50,?000\s*LPH/gi, '10,000 LPH');
      const rawMsg = (message || '').replace(/50,?000\s*LPH/gi, '10,000 LPH');

      return {
        id: row.id,
        serialNumber: assignedSerial,
        date: row.date || new Date().toISOString(),
        status: (row.status as SavedQuote['status']) || 'Pending',
        fullName: row.fullName || 'Industrial Client',
        companyName: row.companyName || '',
        phone: row.phone || '',
        email: row.email || '',
        serviceOrProduct: rawService,
        quantityOrCapacity: rawCapacity,
        message: rawMsg,
        notes: meta?.notes || '',
        priority: (meta?.priority as SavedQuote['priority']) || 'Normal',
        estimatedValue: typeof meta?.estimatedValue === 'number' ? meta.estimatedValue : undefined,
        source: meta?.source || 'Website RFQ',
        followUpDate: meta?.followUpDate
      };
    });

    // Sort descending by serialNumber (newest / highest serial number first)
    quotesFromCloud.sort((a, b) => {
      if (typeof b.serialNumber === 'number' && typeof a.serialNumber === 'number') {
        return b.serialNumber - a.serialNumber;
      }
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    });

    // Sync into local storage cache
    setStoredQuotesRaw(quotesFromCloud);

    return quotesFromCloud;
  } catch (err) {
    console.error('getQuotes exception, returning local cache:', err);
    return getStoredQuotesRaw();
  }
};

export const updateQuoteStatus = async (id: string, status: SavedQuote['status']): Promise<void> => {
  try {
    await supabase.from('quotes').update({ status }).eq('id', id);
  } catch (err) {
    console.warn('Supabase status update error:', err);
  }
  const existing = getStoredQuotesRaw();
  const updated = existing.map(q => q.id === id ? { ...q, status } : q);
  setStoredQuotesRaw(updated);
};

export const updateQuoteDetails = async (id: string, updates: Partial<SavedQuote>): Promise<void> => {
  try {
    const { data } = await supabase.from('quotes').select('message, status').eq('id', id).maybeSingle();
    const existingRaw = data?.message || '';
    const { message: cleanMessage, meta: existingMeta } = deserializeMessageWithMeta(existingRaw);

    const mergedMeta = {
      ...existingMeta,
      ...(updates.serialNumber !== undefined ? { serialNumber: updates.serialNumber } : {}),
      ...(updates.quantityOrCapacity !== undefined ? { quantityOrCapacity: updates.quantityOrCapacity } : {}),
      ...(updates.notes !== undefined ? { notes: updates.notes } : {}),
      ...(updates.priority !== undefined ? { priority: updates.priority } : {}),
      ...(updates.estimatedValue !== undefined ? { estimatedValue: updates.estimatedValue } : {}),
      ...(updates.source !== undefined ? { source: updates.source } : {}),
      ...(updates.followUpDate !== undefined ? { followUpDate: updates.followUpDate } : {})
    };

    const newPackedMessage = `${cleanMessage}\n\n<!--SRP_META:${JSON.stringify(mergedMeta)}-->`;
    const payload: any = { message: newPackedMessage };
    if (updates.status) {
      payload.status = updates.status;
    }

    await supabase.from('quotes').update(payload).eq('id', id);
  } catch (err) {
    console.warn('Supabase detail update error:', err);
  }

  const existing = getStoredQuotesRaw();
  const updated = existing.map(q => q.id === id ? { ...q, ...updates } : q);
  setStoredQuotesRaw(updated);
};

export const createManualLead = async (leadData: Omit<SavedQuote, 'id' | 'date'> & { date?: string }): Promise<SavedQuote> => {
  const allQuotes = await getQuotes();
  const maxSerial = allQuotes.reduce((max, q) => Math.max(max, q.serialNumber || 0), 0);
  const nextSerial = maxSerial > 0 ? maxSerial + 1 : allQuotes.length + 1;
  const year = new Date().getFullYear();
  const serialId = `DIR-${year}-${String(nextSerial).padStart(3, '0')}`;

  const newLead: SavedQuote = {
    ...leadData,
    serialNumber: nextSerial,
    id: serialId,
    date: leadData.date || new Date().toISOString(),
    status: leadData.status || 'Pending',
    source: leadData.source || 'Direct Call'
  };

  const messageWithMeta = serializeMessageWithMeta(newLead);

  try {
    await supabase.from('quotes').insert([{
      id: serialId,
      date: newLead.date,
      status: newLead.status,
      fullName: newLead.fullName,
      companyName: newLead.companyName || '',
      phone: newLead.phone,
      email: newLead.email || '',
      serviceOrProduct: newLead.serviceOrProduct,
      message: messageWithMeta
    }]);
  } catch (err) {
    console.warn('Supabase manual lead insert warning:', err);
  }

  const existing = getStoredQuotesRaw();
  const updated = [newLead, ...existing];
  setStoredQuotesRaw(updated);
  return newLead;
};

// Realtime Cloud Subscription for instant cross-device sync
export const subscribeToQuotes = (onUpdate: () => void): (() => void) => {
  try {
    const channel = supabase
      .channel('quotes-realtime-sync')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'quotes' },
        (payload) => {
          console.log('⚡ Live Supabase update received from device:', payload.eventType);
          onUpdate();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  } catch (err) {
    console.warn('Supabase subscription error:', err);
    return () => {};
  }
};

export const resetQuotesToSeed = async (): Promise<void> => {
  setStoredQuotesRaw(INITIAL_SEED_QUOTES);
};

export const exportQuotesToCSV = (quotes: SavedQuote[]): void => {
  const headers = ['RFQ ID', 'Date', 'Full Name', 'Company', 'Phone', 'Email', 'Product/Service', 'Status', 'Priority', 'Est Value (INR)', 'Source', 'Message', 'Notes'];
  
  const escapeCsv = (val: string | number | undefined) => {
    if (val === undefined || val === null) return '""';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = quotes.map(q => [
    escapeCsv(q.id),
    escapeCsv(new Date(q.date).toLocaleString()),
    escapeCsv(q.fullName),
    escapeCsv(q.companyName),
    escapeCsv(q.phone),
    escapeCsv(q.email),
    escapeCsv(q.serviceOrProduct),
    escapeCsv(q.status),
    escapeCsv(q.priority || 'Normal'),
    escapeCsv(q.estimatedValue || 0),
    escapeCsv(q.source || 'Website RFQ'),
    escapeCsv(q.message),
    escapeCsv(q.notes || '')
  ].join(','));

  const csvContent = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `SRP_Megha_Power_Leads_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const deleteQuoteRecord = async (id: string): Promise<boolean> => {
  try {
    try {
      await supabase.from('quotes').delete().eq('id', id);
    } catch (err) {
      console.warn('Supabase delete error:', err);
    }
    const existing = getStoredQuotesRaw();
    const updated = existing.filter(q => q.id !== id);
    setStoredQuotesRaw(updated);
    return true;
  } catch (e) {
    console.error('Error deleting quote', e);
    return false;
  }
};

export const exportQuotesToJSON = (quotes: SavedQuote[]): void => {
  const jsonContent = JSON.stringify(quotes, null, 2);
  const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `SRP_Megha_Power_Database_Backup_${new Date().toISOString().split('T')[0]}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const importQuotesFromJSON = (jsonString: string): boolean => {
  try {
    const parsed = JSON.parse(jsonString);
    if (Array.isArray(parsed) && parsed.length > 0) {
      const existing = getStoredQuotesRaw();
      // Merge unique by ID
      const existingIds = new Set(existing.map(q => q.id));
      const newItems = parsed.filter(item => item && item.id && !existingIds.has(item.id));
      const merged = [...newItems, ...existing];
      setStoredQuotesRaw(merged);
      return true;
    }
    return false;
  } catch (e) {
    console.error('Failed to import JSON', e);
    return false;
  }
};

export interface AdminSettings {
  allowPublicDownloads: boolean;
  adminWhatsApp: string;
  adminEmail: string;
  adminUsername?: string;
  adminPassword?: string;
}

const DEFAULT_SETTINGS: AdminSettings = {
  allowPublicDownloads: true,
  adminWhatsApp: '919162484535',
  adminEmail: 'srpmeghapower11@gmail.com',
  adminUsername: 'admin',
  adminPassword: 'SRP@1977'
};

export const formatWhatsAppQuoteMessage = (quote: SavedQuote, isForAdmin = true): string => {
  const serialText = String(quote.serialNumber || 1).padStart(3, '0');
  if (isForAdmin) {
    return `⚡ *SRP MEGHA POWER - OFFICIAL QUOTATION INQUIRY* ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🔢 *Serial Number:* #${serialText} (Sequential Enquiry)\n` +
      `📄 *Reference ID:* #${quote.id}\n` +
      `📅 *Date Logged:* ${new Date(quote.date).toLocaleString('en-IN')}\n` +
      `📌 *Status:* ${quote.status} | Priority: ${quote.priority || 'Normal'}\n\n` +
      `👤 *CUSTOMER PROFILE:*\n` +
      `• *Name:* ${quote.fullName}\n` +
      `• *Company:* ${quote.companyName || 'Industrial Client'}\n` +
      `• *Phone:* ${quote.phone}\n` +
      `• *Email:* ${quote.email || 'N/A'}\n\n` +
      `⚙️ *REQUIREMENT:*\n` +
      `• *Product / Service:* ${quote.serviceOrProduct}\n` +
      `• *Capacity / Qty:* ${quote.quantityOrCapacity || 'Standard Industrial'}\n` +
      `• *Details / Message:* ${quote.message || 'No additional note'}\n\n` +
      `💰 *Estimated Value:* ${quote.estimatedValue ? '₹' + quote.estimatedValue.toLocaleString('en-IN') : 'To Be Estimated'}\n` +
      `📍 *Office:* 1st Floor, New Kalimati Road, Near Chandra Hotel, Sakchi, Jamshedpur – 831001\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🌐 *Admin Portal:* ${window.location.origin}/#admin`;
  } else {
    return `Hello ${quote.fullName}, greetings from SRP Megha Power (Jamshedpur)!\n` +
      `This is regarding your quotation inquiry (#${quote.id}, Serial #${serialText}) for "${quote.serviceOrProduct}".\n` +
      `We have received your technical specifications and our engineering team is reviewing them.\n` +
      `📍 Office: 1st Floor, New Kalimati Road, Near Chandra Hotel, P.O. & P.S. Sakchi, Jamshedpur, East Singhbhum, Jharkhand – 831001\n` +
      `📞 Contact: +91 86036 83851 | WhatsApp: +91 91624 84535`;
  }
};

export const formatGmailComposeUrl = (quote: SavedQuote): string => {
  const serialText = String(quote.serialNumber || 1).padStart(3, '0');
  const subject = `[SRP RFQ #${quote.id} | Sr. #${serialText}] ${quote.serviceOrProduct} - ${quote.fullName}`;
  const body =
    `SRP MEGHA POWER - OFFICIAL QUOTATION INQUIRY\n` +
    `==================================================\n` +
    `Serial Number: #${serialText}\n` +
    `Reference ID: #${quote.id}\n` +
    `Date Logged: ${new Date(quote.date).toLocaleString('en-IN')}\n\n` +
    `CUSTOMER DETAILS:\n` +
    `Name: ${quote.fullName}\n` +
    `Company / Plant: ${quote.companyName || 'Industrial Client'}\n` +
    `Phone: ${quote.phone}\n` +
    `Email: ${quote.email || 'N/A'}\n\n` +
    `REQUIREMENT DETAILS:\n` +
    `Product / Service: ${quote.serviceOrProduct}\n` +
    `Capacity / Scope: ${quote.quantityOrCapacity || 'Standard Industrial'}\n` +
    `Message: ${quote.message || 'No additional note'}\n\n` +
    `---\n` +
    `SRP Megha Power Pvt. Ltd.\n` +
    `Office: 1st Floor, New Kalimati Road, Near Chandra Hotel, P.O. & P.S. Sakchi, Jamshedpur, East Singhbhum, Jharkhand – 831001\n` +
    `Call: +91 86036 83851 | WhatsApp: +91 91624 84535 | Email: srpmeghapower11@gmail.com`;
  return `https://mail.google.com/mail/?view=cm&fs=1&to=srpmeghapower11@gmail.com,riteshkr43jsr@gmail.com&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
};

export const getAdminSettings = (): AdminSettings => {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    // fallback
  }
  return DEFAULT_SETTINGS;
};

export const updateAdminSettings = (settings: Partial<AdminSettings>): AdminSettings => {
  try {
    const current = getAdminSettings();
    const updated = { ...current, ...settings };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Error saving admin settings', e);
    return getAdminSettings();
  }
};
